import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react'
import { toast } from 'sonner'
import { hydrateSession, loginWithGoogle, loginWithPassword, logoutSession, registerAccount, selectGoogleRole as saveGoogleRole } from '@/api/auth'
import { getAdminUsers, moderateRemoteListing, setRemoteUserBlocked } from '@/api/admin'
import { ApiError, resolveApiUrl } from '@/api/client'
import { addDiscarded, addFavorite, clearDiscarded, createSavedSearch, deleteSavedSearch, getDiscarded, getFavorites, getSavedSearches, importGuestState, removeFavorite, updateSavedSearch } from '@/api/user-state'
import { deleteCurrentUser, type RemoteUser, updateCurrentAvatar, updateCurrentUser } from '@/api/users'
import { addSearchHistory as addRemoteSearchHistory, clearSearchHistory as clearRemoteSearchHistory, getSearchHistory } from '@/api/search-history'
import { createRemoteListing, deleteRemoteListing, getCatalogVersion, getOwnedListings, renewRemoteListing, setRemoteListingStatus, updateRemoteListing } from '@/api/listings'
import { cleanupPreparedListingMedia, prepareListingMedia, syncListingImages, type PreparedListingMedia } from '@/api/media'
import { createRemoteReport, getRemoteReports } from '@/api/reports'
import { MockAppProvider } from '@/contexts/mock-app-provider'
import { defaultFilters } from '@/data/listings'
import { applySharedListingLocation, ownerListingLocationChanged, sharesPrivateAddressGroup } from '@/lib/listing-address-group'
import { getActiveFilterKeys, normalizeFilters } from '@/lib/search'
import { isSupportedTenerifeQuery, resolveTenerifeLocation, sanitizeTenerifeHistory } from '@/lib/tenerife'
import { isMediaReference, removeUnusedMediaReferences } from '@/lib/media-storage'
import { parseJson, persistJson, persistVersioned, readJson, readVersioned, type StorageFailure } from '@/lib/storage'
import { currentLocale } from '@/lib/i18n-locale'
import type { DemoUser, Filters, Listing, ListingStatus, LocalListingComment, MapPolygonPoint, RentalMode, ReportRecord, UserRole } from '@/types'

export interface SavedSearch {
  id: string
  query: string
  rentalMode: RentalMode
  filters: Filters
  alerts: boolean
  createdAt: string
  polygon: MapPolygonPoint[]
}

type RegisterInput = { name: string; email: string; password: string; role: UserRole }
type ProfileUpdate = Partial<Omit<DemoUser, 'id' | 'email' | 'password' | 'role'>>
type UserScopedState<T> = Record<string, T>
export interface PartialPublicationRecovery {
  listingId: string
  publicationKey: string
  ownerUserId: string
}

export type OwnedListingsHydrationStatus = 'idle' | 'loading' | 'ready' | 'error'

export interface AppState {
  rentalMode: RentalMode
  setRentalMode: (mode: RentalMode) => void
  query: string
  setQuery: (query: string) => void
  favorites: Set<string>
  toggleFavorite: (id: string) => void
  discarded: Set<string>
  discardListing: (id: string) => void
  restoreDiscarded: () => void
  filters: Filters
  setFilters: (filters: Filters) => void
  resetFilters: () => void
  activeFilterCount: number
  searchHistory: string[]
  addSearchHistory: (query: string) => void
  clearSearchHistory: () => void
  savedSearches: SavedSearch[]
  saveCurrentSearch: () => void
  restoreSavedSearch: (id: string) => SavedSearch | undefined
  removeSavedSearch: (id: string) => void
  toggleSearchAlerts: (id: string) => void
  mapPolygon: MapPolygonPoint[]
  setMapPolygon: (points: MapPolygonPoint[]) => void
  clearMapPolygon: () => void
  allListings: Listing[]
  ownedListings: Listing[]
  ownedListingsHydrationStatus: OwnedListingsHydrationStatus
  refreshOwnedListings: () => Promise<void>
  acceptListingSnapshot: (listing: Listing) => void
  partialPublication: PartialPublicationRecovery | null
  createListing: (listing: Listing) => Promise<boolean>
  updateListing: (id: string, listing: Listing) => Promise<boolean>
  deleteListing: (id: string) => Promise<boolean>
  setListingStatus: (id: string, status: ListingStatus) => Promise<ListingStatus | null>
  renewListing: (id: string) => Promise<ListingStatus | null>
  closeListing: (id: string) => Promise<ListingStatus | null>
  refreshListingLifecycle: () => void
  canManageListing: (listing: Listing) => boolean
  reports: ReportRecord[]
  addReport: (listingId: string, reason: string, comment: string) => void
  localComments: LocalListingComment[]
  addLocalComment: (listingId: string, text: string) => void
  updateLocalComment: (id: string, text: string) => void
  deleteLocalComment: (id: string) => void
  users: DemoUser[]
  currentUser: DemoUser | null
  login: (email: string, password: string) => Promise<string | null>
  loginGoogle: (credential: string) => Promise<string | null>
  selectGoogleRole: (role: 'tenant' | 'host') => Promise<string | null>
  register: (input: RegisterInput) => Promise<string | null>
  logout: () => void
  updateProfile: (changes: ProfileUpdate) => void
  deleteAccount: () => Promise<boolean>
  toggleUserBlocked: (id: string) => void
  storageError: string | null
  clearStorageError: () => void
}

export const AppContext = createContext<AppState | null>(null)
const DRAFT_KEY = '112233:listing-draft:v3'
const LEGACY_DRAFT_KEY = '112233:listing-draft:v2'
const PARTIAL_PUBLICATION_KEY = '112233:listing-publication-recovery:v1'
const PENDING_MEDIA_KEY = '112233:listing-pending-media:v1'
const mockMode = import.meta.env.VITE_ENABLE_MOCK_MODE === '1'

const publicationFieldLabels: Record<string, string> = {
  title: 'el título', city: 'el municipio', area: 'la zona', roomType: 'el tipo de habitación',
  monthlyPrice: 'el precio mensual', nightlyPrice: 'el precio por noche', weeklyPrice: 'el precio semanal',
  availableFrom: 'la fecha de inicio', availableUntil: 'la fecha final', minimumStayMonths: 'la estancia mínima',
  minimumNights: 'la estancia mínima', roomSizeM2: 'la superficie de la habitación', homeSizeM2: 'la superficie de la vivienda',
  roomCapacity: 'la capacidad', currentRoomResidents: 'las personas que viven en la habitación', bedType: 'el tipo de cama',
  bedCount: 'el número de camas', acceptedTenantTypes: 'los perfiles admitidos', exactLatitude: 'la ubicación exacta',
  exactLongitude: 'la ubicación exacta', contactName: 'el nombre público', contactPhone: 'el teléfono',
  contactWhatsapp: 'WhatsApp', assetIds: 'las fotografías', videoAssetId: 'el vídeo',
}

function duplicateListingMessage() {
  const locale = currentLocale()
  if (locale === 'ru-RU') return 'Такое объявление уже существует. Замените фотографии.'
  if (locale === 'en-GB') return 'This listing already exists. Replace the photos.'
  return 'Este anuncio ya existe. Sustituye las fotografías.'
}

function publicationErrorMessage(error: unknown) {
  if (!(error instanceof ApiError)) return 'Se produjo un error inesperado al publicar. Inténtalo de nuevo.'
  if (error.code === 'EMAIL_VERIFICATION_REQUIRED') return 'Confirma tu email antes de publicar el anuncio.'
  if (error.code === 'PUBLISHING_RESTRICTED' || error.code === 'ACCOUNT_RESTRICTED') return 'Tu cuenta tiene restringida la publicación de anuncios. Revisa el aviso de moderación.'
  if (error.code === 'ACTIVE_LISTING_LIMIT_REACHED') return 'Has alcanzado el límite de anuncios activos.'
  if (error.code === 'DUPLICATE_LISTING_IMAGES') return duplicateListingMessage()
  if (error.code === 'HOST_ACCOUNT_REQUIRED' || error.status === 403) return 'Necesitas una cuenta de anfitrión autorizada para publicar.'
  if (error.status === 401) return 'Tu sesión ha caducado. Inicia sesión de nuevo para publicar.'
  if (error.code === 'REQUEST_TIMEOUT') return 'La publicación está tardando más de lo esperado. Comprobaremos el mismo intento para evitar duplicados.'
  if (error.code === 'NETWORK_ERROR' || error.status === 0) return 'No se pudo conectar con el servidor. Revisa tu conexión e inténtalo de nuevo.'
  if (error.code === 'VALIDATION_ERROR' || error.status === 422) {
    const field = Object.keys(error.fieldErrors)[0]
    return field ? `Revisa ${publicationFieldLabels[field] ?? 'los datos del anuncio'}.` : 'Revisa los datos del anuncio antes de publicarlo.'
  }
  return error.status >= 500
    ? 'El servidor no pudo completar la publicación. Inténtalo de nuevo más tarde.'
    : 'No se pudo publicar el anuncio. Revisa los datos e inténtalo de nuevo.'
}

const listingUpdateFieldLabels: Record<'ru-RU' | 'en-GB', Record<string, string>> = {
  'ru-RU': {
    title: 'заголовок', city: 'муниципалитет', area: 'район', roomType: 'тип комнаты',
    monthlyPrice: 'цена за месяц', nightlyPrice: 'цена за ночь', weeklyPrice: 'цена за неделю',
    availableFrom: 'дата начала', availableUntil: 'дата окончания', minimumStayMonths: 'минимальный срок',
    minimumNights: 'минимальный срок', depositAmount: 'залог', roomSizeM2: 'площадь комнаты',
    homeSizeM2: 'площадь жилья', roomCapacity: 'вместимость', currentRoomResidents: 'жильцы комнаты',
    bedType: 'тип кровати', bedCount: 'количество кроватей', acceptedTenantTypes: 'допустимые жильцы',
    exactLatitude: 'точное местоположение', exactLongitude: 'точное местоположение',
    contactName: 'имя', contactPhone: 'телефон', contactWhatsapp: 'WhatsApp',
    assetIds: 'фотографии', videoAssetId: 'видео',
  },
  'en-GB': {
    title: 'title', city: 'municipality', area: 'area', roomType: 'room type',
    monthlyPrice: 'monthly price', nightlyPrice: 'nightly price', weeklyPrice: 'weekly price',
    availableFrom: 'start date', availableUntil: 'end date', minimumStayMonths: 'minimum stay',
    minimumNights: 'minimum stay', depositAmount: 'deposit', roomSizeM2: 'room size',
    homeSizeM2: 'home size', roomCapacity: 'capacity', currentRoomResidents: 'room residents',
    bedType: 'bed type', bedCount: 'bed count', acceptedTenantTypes: 'accepted tenants',
    exactLatitude: 'exact location', exactLongitude: 'exact location',
    contactName: 'name', contactPhone: 'phone', contactWhatsapp: 'WhatsApp',
    assetIds: 'photos', videoAssetId: 'video',
  },
}

function listingUpdateErrorMessage(error: unknown) {
  const locale = currentLocale()
  if (!(error instanceof ApiError)) {
    if (error instanceof Error && error.message.trim()) return error.message
    if (locale === 'ru-RU') return 'Не удалось сохранить изменения объявления.'
    if (locale === 'en-GB') return 'The listing changes could not be saved.'
    return 'No se pudieron guardar los cambios del anuncio.'
  }
  if (error.code === 'DUPLICATE_LISTING_IMAGES') return duplicateListingMessage()
  if (error.status === 401) {
    if (locale === 'ru-RU') return 'Сессия истекла. Войдите снова и повторите сохранение.'
    if (locale === 'en-GB') return 'Your session has expired. Sign in again and retry the save.'
    return 'Tu sesión ha caducado. Inicia sesión de nuevo y vuelve a guardar.'
  }
  if (error.status === 403) {
    if (locale === 'ru-RU') return 'У вас нет доступа к редактированию этого объявления.'
    if (locale === 'en-GB') return 'You do not have permission to edit this listing.'
    return 'No tienes permiso para editar este anuncio.'
  }
  if (error.code === 'REQUEST_TIMEOUT') {
    if (locale === 'ru-RU') return 'Сохранение заняло слишком много времени. Повторите попытку.'
    if (locale === 'en-GB') return 'Saving took too long. Please try again.'
    return 'El guardado ha tardado demasiado. Inténtalo de nuevo.'
  }
  if (error.code === 'NETWORK_ERROR' || error.status === 0) {
    if (locale === 'ru-RU') return 'Не удалось подключиться к серверу. Проверьте соединение и повторите попытку.'
    if (locale === 'en-GB') return 'Could not connect to the server. Check your connection and try again.'
    return 'No se pudo conectar con el servidor. Revisa tu conexión e inténtalo de nuevo.'
  }
  if (error.code === 'VALIDATION_ERROR' || error.status === 422) {
    const field = Object.keys(error.fieldErrors)[0]
    if (locale === 'ru-RU') {
      const label = field ? listingUpdateFieldLabels['ru-RU'][field] : undefined
      return label ? `Проверьте поле «${label}».` : 'Проверьте данные объявления и повторите сохранение.'
    }
    if (locale === 'en-GB') {
      const label = field ? listingUpdateFieldLabels['en-GB'][field] : undefined
      return label ? `Check the ${label} field.` : 'Check the listing details and try saving again.'
    }
    return field ? `Revisa ${publicationFieldLabels[field] ?? 'los datos del anuncio'}.` : 'Revisa los datos del anuncio y vuelve a guardar.'
  }
  if (error.status >= 500) {
    if (locale === 'ru-RU') return 'Сервер не смог сохранить изменения. Повторите попытку позже.'
    if (locale === 'en-GB') return 'The server could not save the changes. Try again later.'
    return 'El servidor no pudo guardar los cambios. Inténtalo de nuevo más tarde.'
  }
  if (locale === 'ru-RU') return 'Не удалось сохранить изменения объявления.'
  if (locale === 'en-GB') return 'The listing changes could not be saved.'
  return 'No se pudieron guardar los cambios del anuncio.'
}

function publicationDiagnostic(error: unknown) {
  return error instanceof ApiError
    ? { status: error.status, code: error.code ?? 'UNKNOWN', requestId: error.requestId, fields: Object.keys(error.fieldErrors) }
    : { status: 0, code: error instanceof Error ? error.name : 'UNKNOWN' }
}

function collectMediaReferences(value: unknown, found = new Set<string>()) {
  if (typeof value === 'string') {
    if (isMediaReference(value)) found.add(value)
    return found
  }
  if (Array.isArray(value)) value.forEach((item) => collectMediaReferences(item, found))
  else if (value && typeof value === 'object') Object.values(value as Record<string, unknown>).forEach((item) => collectMediaReferences(item, found))
  return found
}

function readDraftRecord() {
  for (const key of [DRAFT_KEY, LEGACY_DRAFT_KEY]) {
    const parsed = parseJson<Record<string, unknown>>(localStorage.getItem(key))
    if (parsed.data) return { key, value: parsed.data }
  }
  return null
}

function readPartialPublication(): PartialPublicationRecovery | null {
  const parsed = parseJson<PartialPublicationRecovery>(localStorage.getItem(PARTIAL_PUBLICATION_KEY))
  if (parsed.failure || !parsed.data) return null
  const value = parsed.data
  return typeof value.listingId === 'string' && typeof value.publicationKey === 'string' && typeof value.ownerUserId === 'string'
    ? value
    : null
}

function persistPartialPublication(value: PartialPublicationRecovery | null) {
  if (value) localStorage.setItem(PARTIAL_PUBLICATION_KEY, JSON.stringify(value))
  else localStorage.removeItem(PARTIAL_PUBLICATION_KEY)
}

type PendingPublicationMedia = {
  listingId: string
  ownerUserId: string
  images: string[]
  video?: string
  prepared: PreparedListingMedia
  savedAt: number
}

function readPendingMedia(): PendingPublicationMedia | null {
  const value = parseJson<PendingPublicationMedia>(localStorage.getItem(PENDING_MEDIA_KEY)).data
  return value && typeof value.listingId === 'string' && typeof value.ownerUserId === 'string'
    && Array.isArray(value.images) && value.images.every((image) => typeof image === 'string')
    && Array.isArray(value.prepared?.images?.assetIds)
    && value.prepared.images.assetIds.every((id) => typeof id === 'string')
    && Array.isArray(value.prepared.images.newlyUploaded)
    && value.prepared.images.newlyUploaded.every((id) => typeof id === 'string')
    && (typeof value.prepared?.video?.assetId === 'string' || value.prepared?.video?.assetId === null)
    && Array.isArray(value.prepared.video.newlyUploaded)
    && value.prepared.video.newlyUploaded.every((id) => typeof id === 'string')
    && typeof value.savedAt === 'number' ? value : null
}

function persistPendingMedia(value: PendingPublicationMedia | null) {
  try {
    if (value) localStorage.setItem(PENDING_MEDIA_KEY, JSON.stringify(value))
    else localStorage.removeItem(PENDING_MEDIA_KEY)
  } catch { /* In-memory retry still works when browser storage is unavailable. */ }
}

function usedMediaReferences(listings: Listing[], users: DemoUser[], draft: unknown = readDraftRecord()?.value) {
  return collectMediaReferences([listings, users, draft])
}

function toAppUser(user: RemoteUser): DemoUser {
  const { avatarUrl, ...profile } = user
  return {
    ...profile,
    avatarRef: avatarUrl ? resolveApiUrl(avatarUrl) : undefined,
    password: '',
    blocked: false,
  }
}

const isStringArray = (value: unknown): value is string[] => Array.isArray(value) && value.every((item) => typeof item === 'string')
const isScopedStringArrays = (value: unknown): value is UserScopedState<string[]> => Boolean(value) && typeof value === 'object' && Object.values(value as Record<string, unknown>).every(isStringArray)
const isSavedSearch = (value: unknown): value is SavedSearch => Boolean(value) && typeof value === 'object' && typeof (value as SavedSearch).id === 'string' && typeof (value as SavedSearch).query === 'string'
const isScopedSavedSearches = (value: unknown): value is UserScopedState<SavedSearch[]> => Boolean(value) && typeof value === 'object' && Object.values(value as Record<string, unknown>).every((items) => Array.isArray(items) && items.every(isSavedSearch))
const isLocalComment = (value: unknown): value is LocalListingComment => Boolean(value) && typeof value === 'object' && typeof (value as LocalListingComment).id === 'string' && typeof (value as LocalListingComment).userId === 'string' && typeof (value as LocalListingComment).listingId === 'string' && typeof (value as LocalListingComment).text === 'string' && typeof (value as LocalListingComment).createdAt === 'string'
const isScopedLocalComments = (value: unknown): value is UserScopedState<LocalListingComment[]> => Boolean(value) && typeof value === 'object' && Object.values(value as Record<string, unknown>).every((items) => Array.isArray(items) && items.every(isLocalComment))
function readScopedStrings(key: string, legacyKey: string) {
  const current = readVersioned(key, 2, {} as UserScopedState<string[]>, isScopedStringArrays)
  if (localStorage.getItem(key) && !current.failure) {
    if (key === '112233:search-history:v2') return Object.fromEntries(Object.entries(current.data).map(([scope, values]) => [scope, sanitizeTenerifeHistory(values)]))
    return current.data
  }
  const legacy = readJson<string[]>(legacyKey, [], isStringArray)
  return legacy.data.length ? { guest: key === '112233:search-history:v2' ? sanitizeTenerifeHistory(legacy.data) : legacy.data } : {}
}

function readScopedLocalComments() {
  return readVersioned('112233:listing-comments:v1', 1, {} as UserScopedState<LocalListingComment[]>, isScopedLocalComments).data
}

function readScopedSavedSearches() {
  const current = readVersioned('112233:saved-searches:v3', 3, {} as UserScopedState<SavedSearch[]>, isScopedSavedSearches)
  if (localStorage.getItem('112233:saved-searches:v3') && !current.failure) {
    return Object.fromEntries(Object.entries(current.data).map(([scope, items]) => [scope, items.map((item) => ({ ...item, filters: normalizeFilters(item.filters) }))]))
  }
  const legacy = readJson<unknown>('112233:saved-searches:v2', [])
  const items = Array.isArray(legacy.data) ? legacy.data.filter(isSavedSearch) : []
  return items.length ? { guest: items.map((item) => ({ ...item, filters: normalizeFilters(item.filters) })) } : {}
}

const storageMessage = (failure: StorageFailure) => failure === 'quota'
  ? 'No hay espacio suficiente. Tus últimos cambios no se han guardado.'
  : failure === 'corrupted'
    ? 'Había datos locales dañados. Se ha cargado una copia segura.'
    : 'No se pudo guardar en este navegador. Revisa la privacidad o el espacio disponible.'

function RemoteAppProvider({ children }: { children: ReactNode }) {
  const [rentalMode, setRentalMode] = useState<RentalMode>('long')
  const [query, setQuery] = useState('Tenerife')
  const [favoriteScopes, setFavoriteScopes] = useState<UserScopedState<string[]>>(() => readScopedStrings('112233:favorites:v2', '112233:favorites:v1'))
  const [discardedScopes, setDiscardedScopes] = useState<UserScopedState<string[]>>(() => readScopedStrings('112233:discarded:v2', '112233:discarded:v1'))
  const [filters, setFilters] = useState<Filters>({ ...defaultFilters })
  const [historyScopes, setHistoryScopes] = useState<UserScopedState<string[]>>(() => readScopedStrings('112233:search-history:v2', '112233:search-history:v1'))
  const [savedSearchScopes, setSavedSearchScopes] = useState<UserScopedState<SavedSearch[]>>(readScopedSavedSearches)
  const [mapPolygon, setMapPolygonState] = useState<MapPolygonPoint[]>([])
  const [allListings, setAllListings] = useState<Listing[]>([])
  const [ownedListings, setOwnedListings] = useState<Listing[]>([])
  const [ownedListingsHydrationStatus, setOwnedListingsHydrationStatus] = useState<OwnedListingsHydrationStatus>('idle')
  const [partialPublication, setPartialPublication] = useState<PartialPublicationRecovery | null>(() => mockMode ? null : readPartialPublication())
  const pendingMedia = useRef<PendingPublicationMedia | null>(readPendingMedia())
  const [reports, setReports] = useState<ReportRecord[]>(() => readJson<ReportRecord[]>('112233:reports:v1', []).data)
  const [commentScopes, setCommentScopes] = useState<UserScopedState<LocalListingComment[]>>(readScopedLocalComments)
  const [users, setUsers] = useState<DemoUser[]>([])
  const [currentUserId, setCurrentUserId] = useState<string | null>(null)
  const [storageError, setStorageError] = useState<string | null>(null)
  const authHydrationStarted = useRef(false)
  const catalogVersion = useRef<string | null>(null)
  const catalogCheck = useRef<AbortController | null>(null)
  const ownedRequest = useRef<AbortController | null>(null)
  const ownedRequestVersion = useRef(0)

  const currentUser = users.find((user) => user.id === currentUserId) ?? null
  const scopeKey = currentUserId ?? 'guest'
  const favorites = useMemo(() => new Set(favoriteScopes[scopeKey] ?? []), [favoriteScopes, scopeKey])
  const discarded = useMemo(() => new Set(discardedScopes[scopeKey] ?? []), [discardedScopes, scopeKey])
  const searchHistory = useMemo(() => historyScopes[scopeKey] ?? [], [historyScopes, scopeKey])
  const savedSearches = useMemo(() => savedSearchScopes[scopeKey] ?? [], [savedSearchScopes, scopeKey])
  const localComments = useMemo(() => commentScopes[scopeKey] ?? [], [commentScopes, scopeKey])

  const refreshPublicConsumers = useCallback(async () => {
    window.dispatchEvent(new Event('catalog:updated'))
  }, [])

  const invalidateOwnedListings = useCallback(() => {
    ownedRequestVersion.current += 1
    ownedRequest.current?.abort()
    ownedRequest.current = null
    setOwnedListings([])
    setOwnedListingsHydrationStatus('idle')
  }, [])

  const refreshOwnedConsumers = useCallback(async () => {
    const requestVersion = ++ownedRequestVersion.current
    ownedRequest.current?.abort()
    if (!currentUserId) {
      setOwnedListings([])
      setOwnedListingsHydrationStatus('ready')
      return
    }
    const request = new AbortController()
    ownedRequest.current = request
    setOwnedListingsHydrationStatus('loading')
    try {
      const listings = await getOwnedListings(request.signal)
      if (!request.signal.aborted && ownedRequestVersion.current === requestVersion) {
        setOwnedListings(listings)
        setOwnedListingsHydrationStatus('ready')
      }
    } catch (error) {
      if (!request.signal.aborted && ownedRequestVersion.current === requestVersion) {
        setOwnedListingsHydrationStatus('error')
        throw error
      }
    } finally {
      if (ownedRequest.current === request) ownedRequest.current = null
    }
  }, [currentUserId])

  const refreshListingConsumers = useCallback(async () => {
    await Promise.all([refreshPublicConsumers(), refreshOwnedConsumers()])
  }, [refreshOwnedConsumers, refreshPublicConsumers])

  const acceptListingSnapshot = useCallback((snapshot: Listing) => {
    setAllListings((current) => [...current.filter((listing) => listing.id !== snapshot.id).slice(-19), snapshot])
    // Preserve owner-only fields while accepting mutable public fields such as
    // the daily view counter returned by GET /listings/{id}.
    setOwnedListings((current) => current.map((listing) => listing.id === snapshot.id ? { ...listing, ...snapshot } : listing))
  }, [])

  const reportStorageFailure = useCallback((failure: StorageFailure | null) => {
    if (!failure) return
    const message = storageMessage(failure)
    setStorageError(message)
    toast.error(message, { id: 'storage-error' })
  }, [])

  useEffect(() => reportStorageFailure(persistVersioned('112233:favorites:v2', 2, favoriteScopes)), [favoriteScopes, reportStorageFailure])
  useEffect(() => reportStorageFailure(persistVersioned('112233:discarded:v2', 2, discardedScopes)), [discardedScopes, reportStorageFailure])
  useEffect(() => reportStorageFailure(persistVersioned('112233:search-history:v2', 2, historyScopes)), [historyScopes, reportStorageFailure])
  useEffect(() => reportStorageFailure(persistVersioned('112233:saved-searches:v3', 3, savedSearchScopes)), [savedSearchScopes, reportStorageFailure])
  useEffect(() => reportStorageFailure(persistJson('112233:reports:v1', reports)), [reports, reportStorageFailure])
  useEffect(() => reportStorageFailure(persistVersioned('112233:listing-comments:v1', 1, commentScopes)), [commentScopes, reportStorageFailure])
  useEffect(() => {
    if (!partialPublication || !currentUserId || partialPublication.ownerUserId === currentUserId) return
    setPartialPublication(null)
    try { persistPartialPublication(null) } catch { /* Ignore stale recovery cleanup failures. */ }
  }, [currentUserId, partialPublication])
  const setRemoteUser = useCallback((remote: RemoteUser) => {
    const user = toAppUser(remote)
    if (currentUserId !== user.id) invalidateOwnedListings()
    setUsers((current) => [...current.filter((item) => item.id !== user.id), user])
    setCurrentUserId(user.id)
  }, [currentUserId, invalidateOwnedListings])

  useEffect(() => {
    if (authHydrationStarted.current) return
    authHydrationStarted.current = true
    void hydrateSession().then((user) => { if (user) setRemoteUser(user) }).catch((error: unknown) => {
      if (!(error instanceof ApiError) || error.status !== 401) toast.error('No se pudo restaurar la sesión.')
    })
  }, [setRemoteUser])

  useEffect(() => {
    if (mockMode) return
    const initial = new AbortController()
    let active = true
    void getCatalogVersion(initial.signal).then((current) => {
      if (active) catalogVersion.current = current.version
    }).catch(() => undefined)

    const refreshIfChanged = () => {
      if (catalogCheck.current) return
      const check = new AbortController()
      catalogCheck.current = check
      void getCatalogVersion(check.signal).then((current) => {
        if (check.signal.aborted) return
        const previous = catalogVersion.current
        catalogVersion.current = current.version
        if (previous !== null && previous !== current.version) {
          window.dispatchEvent(new Event('catalog:updated'))
        }
      }).catch(() => undefined).finally(() => {
        if (catalogCheck.current === check) catalogCheck.current = null
      })
    }
    const onFocus = () => refreshIfChanged()
    const onVisibility = () => { if (document.visibilityState === 'visible') refreshIfChanged() }
    window.addEventListener('focus', onFocus)
    document.addEventListener('visibilitychange', onVisibility)
    return () => {
      active = false
      initial.abort()
      catalogCheck.current?.abort()
      window.removeEventListener('focus', onFocus)
      document.removeEventListener('visibilitychange', onVisibility)
    }
  }, [])

  useEffect(() => {
    if (!currentUserId) return
    const guestFavorites = (favoriteScopes.guest ?? []).filter((id) => /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id))
    const guestSavedSearches = (savedSearchScopes.guest ?? []).map((search) => ({
      name: search.query,
      query: search.query,
      rentalMode: search.rentalMode,
      filters: search.filters as unknown as Record<string, unknown>,
      polygon: search.polygon,
      alertsEnabled: search.alerts,
    }))
    void importGuestState({ favoriteIds: guestFavorites, savedSearches: guestSavedSearches }).then(() =>
      Promise.all([getFavorites(), getDiscarded(), getSavedSearches()]),
    ).then(([remoteFavorites, remoteDiscarded, remoteSearches]) => {
      setFavoriteScopes((current) => ({ ...current, [currentUserId]: remoteFavorites }))
      setDiscardedScopes((current) => ({ ...current, [currentUserId]: remoteDiscarded }))
      setSavedSearchScopes((current) => ({
        ...current,
        [currentUserId]: remoteSearches.map((search) => ({
          id: search.id,
          query: search.query,
          rentalMode: search.rentalMode,
          filters: normalizeFilters({ ...defaultFilters, ...search.filters }),
          alerts: search.alertsEnabled,
          createdAt: search.createdAt,
          polygon: search.polygon,
        })),
      }))
    }).catch(() => toast.error('No se pudieron sincronizar los datos de tu cuenta.'))
  }, [currentUserId, favoriteScopes.guest, savedSearchScopes.guest])

  useEffect(() => {
    if (!currentUserId) return
    void getSearchHistory().then((history) => {
      setHistoryScopes((current) => ({ ...current, [currentUserId]: sanitizeTenerifeHistory(history) }))
    }).catch(() => toast.error('No se pudo sincronizar el historial de búsqueda.'))
  }, [currentUserId])

  useEffect(() => {
    void refreshOwnedConsumers().catch(() => toast.error('No se pudieron cargar tus anuncios.'))
    const refresh = () => { void refreshOwnedConsumers().catch(() => undefined) }
    window.addEventListener('catalog:updated', refresh)
    return () => window.removeEventListener('catalog:updated', refresh)
  }, [refreshOwnedConsumers])

  useEffect(() => {
    const refresh = () => { void refreshListingConsumers().catch(() => toast.error('No se pudo actualizar el catálogo.')) }
    window.addEventListener('catalog:refresh', refresh)
    return () => window.removeEventListener('catalog:refresh', refresh)
  }, [refreshListingConsumers])

  useEffect(() => {
    if (currentUser?.role !== 'admin') return
    void getRemoteReports().then(setReports).catch(() => toast.error('No se pudieron cargar las denuncias.'))
  }, [currentUser?.role])

  useEffect(() => {
    if (currentUser?.role !== 'admin') return
    void getAdminUsers().then(setUsers).catch(() => toast.error('No se pudieron cargar los usuarios.'))
  }, [currentUser?.role])

  const updateScope = useCallback(<T,>(setter: React.Dispatch<React.SetStateAction<UserScopedState<T>>>, update: (current: T | undefined) => T) => {
    setter((current) => ({ ...current, [scopeKey]: update(current[scopeKey]) }))
  }, [scopeKey])

  const toggleFavorite = useCallback((id: string) => updateScope(setFavoriteScopes, (current) => {
    const next = new Set(current ?? [])
    const wasSaved = next.has(id)
    if (wasSaved) next.delete(id); else next.add(id)
    if (currentUserId) {
      const operation = wasSaved ? removeFavorite(id) : addFavorite(id)
      void operation.catch(() => {
        updateScope(setFavoriteScopes, (latest) => wasSaved ? [...new Set([...(latest ?? []), id])] : (latest ?? []).filter((item) => item !== id))
        toast.error('No se pudo sincronizar el favorito.')
      })
    }
    toast.success(wasSaved ? 'Eliminado de favoritos' : 'Guardado en favoritos')
    return [...next]
  }), [currentUserId, updateScope])
  const discardListing = useCallback((id: string) => updateScope(setDiscardedScopes, (current) => {
    if (currentUserId) void addDiscarded(id).catch(() => toast.error('No se pudo sincronizar el anuncio oculto.'))
    return [...new Set([...(current ?? []), id])]
  }), [currentUserId, updateScope])
  const restoreDiscarded = useCallback(() => updateScope<string[]>(setDiscardedScopes, () => {
    if (currentUserId) void clearDiscarded().catch(() => toast.error('No se pudieron restaurar los anuncios.'))
    return []
  }), [currentUserId, updateScope])
  const resetFilters = useCallback(() => setFilters({ ...defaultFilters }), [])
  const addSearchHistory = useCallback((nextQuery: string) => updateScope(setHistoryScopes, (current) => {
    const location = resolveTenerifeLocation(nextQuery)
    if (!location || !isSupportedTenerifeQuery(nextQuery)) return sanitizeTenerifeHistory(current ?? [])
    if (currentUserId) void addRemoteSearchHistory(location.normalizedValue).catch(() => toast.error('No se pudo guardar el historial de búsqueda.'))
    return sanitizeTenerifeHistory([location.normalizedValue, ...(current ?? [])])
  }), [currentUserId, updateScope])
  const clearSearchHistory = useCallback(() => updateScope<string[]>(setHistoryScopes, () => {
    if (currentUserId) void clearRemoteSearchHistory().catch(() => toast.error('No se pudo borrar el historial de búsqueda.'))
    return []
  }), [currentUserId, updateScope])
  const saveCurrentSearch = useCallback(() => updateScope(setSavedSearchScopes, (current) => {
    const searches = current ?? []
    const duplicate = searches.some((item) => item.query === query && item.rentalMode === rentalMode && JSON.stringify(item.filters) === JSON.stringify(filters) && JSON.stringify(item.polygon) === JSON.stringify(mapPolygon))
    if (duplicate) { toast.info('Esta búsqueda ya está guardada'); return searches }
    const optimistic = { id: `search-${Date.now()}`, query, rentalMode, filters: { ...filters }, alerts: true, createdAt: new Date().toISOString(), polygon: mapPolygon }
    if (currentUserId) {
      void createSavedSearch({ name: query, query, rentalMode, filters: filters as unknown as Record<string, unknown>, polygon: mapPolygon, alertsEnabled: true }).then((saved) => {
        updateScope(setSavedSearchScopes, (latest) => (latest ?? []).map((item) => item.id === optimistic.id ? { ...item, id: saved.id, createdAt: saved.createdAt } : item))
      }).catch(() => {
        updateScope(setSavedSearchScopes, (latest) => (latest ?? []).filter((item) => item.id !== optimistic.id))
        toast.error('No se pudo guardar la búsqueda.')
      })
    }
    toast.success('Búsqueda guardada. Te avisaremos de nuevos anuncios.')
    return [optimistic, ...searches]
  }), [currentUserId, filters, mapPolygon, query, rentalMode, updateScope])
  const restoreSavedSearch = useCallback((id: string) => {
    const found = savedSearches.find((item) => item.id === id)
    if (found) { setQuery(found.query); setRentalMode(found.rentalMode); setFilters(normalizeFilters(found.filters)); setMapPolygonState(found.polygon ?? []) }
    return found
  }, [savedSearches])
  const removeSavedSearch = useCallback((id: string) => updateScope(setSavedSearchScopes, (current) => {
    if (currentUserId) void deleteSavedSearch(id).catch(() => toast.error('No se pudo eliminar la búsqueda guardada.'))
    return (current ?? []).filter((item) => item.id !== id)
  }), [currentUserId, updateScope])
  const toggleSearchAlerts = useCallback((id: string) => updateScope(setSavedSearchScopes, (current) => {
    const search = (current ?? []).find((item) => item.id === id)
    if (currentUserId && search) void updateSavedSearch(id, { alertsEnabled: !search.alerts }).catch(() => toast.error('No se pudieron actualizar las alertas.'))
    return (current ?? []).map((item) => item.id === id ? { ...item, alerts: !item.alerts } : item)
  }), [currentUserId, updateScope])
  const setMapPolygon = useCallback((points: MapPolygonPoint[]) => setMapPolygonState(points), [])
  const clearMapPolygon = useCallback(() => setMapPolygonState([]), [])

  const canManageListing = useCallback((listing: Listing) => Boolean(currentUser && (currentUser.role === 'admin' || listing.ownerUserId === currentUser.id)), [currentUser])
  const createListing = useCallback(async (listing: Listing) => {
    if (!currentUser || currentUser.role === 'tenant') { toast.error('Necesitas una cuenta de anfitrión para publicar.'); return false }
    if (partialPublication && partialPublication.publicationKey !== listing.id) {
      toast.error('Termina la recuperación de las fotografías del anuncio anterior antes de publicar otro.')
      return false
    }
    if (partialPublication) {
      const previous = ownedListings.find((item) => item.id === partialPublication.listingId)
      try {
        const images = await syncListingImages(partialPublication.listingId, listing.images)
        const usedAfterRecovery = new Set([
          ...[...allListings, ...ownedListings].filter((item) => item.id !== partialPublication.listingId).flatMap((item) => item.images),
          ...images,
          ...(currentUser.avatarRef ? [currentUser.avatarRef] : []),
        ])
        await removeUnusedMediaReferences(previous?.images ?? [], usedAfterRecovery)
        const recovered = { ...listing, id: partialPublication.listingId, ownerUserId: currentUser.id, userCreated: true, images }
        setOwnedListings((current) => [recovered, ...current.filter((item) => item.id !== partialPublication.listingId)])
        await refreshListingConsumers().catch(() => toast.error('Las fotos se guardaron, pero no se pudo refrescar el catálogo.'))
        setPartialPublication(null)
        try { persistPartialPublication(null) } catch { /* Ignore cleanup failures after the listing is recovered. */ }
        toast.success('Las fotografías se han sincronizado y el anuncio está listo.')
        return true
      } catch (error) {
        console.error('listing_image_recovery_failed', { listingId: partialPublication.listingId, ...publicationDiagnostic(error) })
        toast.error('El anuncio ya está creado, pero las fotografías siguen pendientes. Revisa las fotos y vuelve a intentarlo.')
        return false
      }
    }
    const publicationStartedAt = Date.now()
    const optimistic = { ...listing, ownerUserId: currentUser.id, userCreated: true }
    let prepared: PreparedListingMedia
    try {
      const pending = pendingMedia.current
      const matchingPending = pending && pending.listingId === optimistic.id
        && pending.ownerUserId === currentUser.id
        && pending.savedAt > Date.now() - 23 * 60 * 60 * 1000
        && JSON.stringify(pending.images) === JSON.stringify(optimistic.images)
        && pending.video === optimistic.video
      if (matchingPending) {
        prepared = pending.prepared
      } else {
        if (pending?.ownerUserId === currentUser.id) await cleanupPreparedListingMedia(pending.prepared)
        pendingMedia.current = null
        persistPendingMedia(null)
        prepared = await prepareListingMedia(optimistic.images, optimistic.video)
        pendingMedia.current = {
          listingId: optimistic.id, ownerUserId: currentUser.id,
          images: optimistic.images, video: optimistic.video, prepared, savedAt: Date.now(),
        }
        persistPendingMedia(pendingMedia.current)
      }
    } catch (error) {
      console.error('listing_media_prepare_failed', publicationDiagnostic(error))
      toast.error(error instanceof Error ? error.message : 'No se pudieron preparar las fotos o el vídeo.')
      return false
    }
    setOwnedListings((current) => [optimistic, ...current.filter((item) => item.id !== optimistic.id)])
    try {
      const remote = await createRemoteListing(optimistic, prepared.images.assetIds, prepared.video.assetId)
      pendingMedia.current = null
      persistPendingMedia(null)
      const stored = { ...remote, userCreated: true }
      setOwnedListings((current) => current.map((item) => item.id === optimistic.id ? stored : item))
      await removeUnusedMediaReferences(
        [...optimistic.images, ...(optimistic.video ? [optimistic.video] : [])],
        [...stored.images, ...(stored.video ? [stored.video] : [])],
      ).catch(() => undefined)
      await refreshListingConsumers().catch(() => toast.error('El anuncio se guardó, pero no se pudo refrescar el catálogo.'))
      setPartialPublication(null)
      try { persistPartialPublication(null) } catch { /* Ignore cleanup failures after a successful publication. */ }
      toast.success('Anuncio enviado a moderación y guardado en Mis anuncios')
      return true
    } catch (error) {
      setOwnedListings((current) => current.filter((item) => item.id !== optimistic.id))
      const uncertainCommit = error instanceof ApiError && ['REQUEST_TIMEOUT', 'NETWORK_ERROR'].includes(error.code ?? '')
      if (!uncertainCommit) {
        await cleanupPreparedListingMedia(prepared)
        pendingMedia.current = null
        persistPendingMedia(null)
      }
      if (error instanceof ApiError && error.code === 'DUPLICATE_LISTING_IMAGES') {
        const remainingFeedbackDelay = 1000 - (Date.now() - publicationStartedAt)
        if (remainingFeedbackDelay > 0) await new Promise((resolve) => window.setTimeout(resolve, remainingFeedbackDelay))
      }
      console.error('listing_publication_failed', publicationDiagnostic(error))
      toast.error(publicationErrorMessage(error))
      return false
    }
  }, [allListings, currentUser, ownedListings, partialPublication, refreshListingConsumers])
  const mutateOwned = useCallback((id: string, mutate: (listing: Listing) => Listing | null) => setOwnedListings((current) => current.flatMap((listing) => {
    if (listing.id !== id) return [listing]
    if (!canManageListing(listing)) { toast.error('No puedes gestionar un anuncio de otra cuenta.'); return [listing] }
    const next = mutate(listing)
    return next ? [next] : []
  })), [canManageListing])
  const updateListing = useCallback(async (id: string, listing: Listing) => {
    const previous = ownedListings.find((item) => item.id === id)
    if (!previous || !canManageListing(previous)) {
      if (previous) toast.error('No puedes gestionar un anuncio de otra cuenta.')
      return false
    }
    const next = { ...listing, id: previous.id, ownerUserId: previous.ownerUserId }
    const siblingLocationIds = ownerListingLocationChanged(next, previous)
      ? ownedListings
          .filter((item) => item.id !== id
            && item.ownerUserId === previous.ownerUserId
            && sharesPrivateAddressGroup(item, previous))
          .map((item) => item.id)
      : []
    let prepared: Awaited<ReturnType<typeof prepareListingMedia>>
    try {
      prepared = await prepareListingMedia(next.images, next.video)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'No se pudieron preparar las fotos o el vídeo.')
      return false
    }
    setOwnedListings((current) => current.map((item) => item.id === id ? next : item))
    try {
      const remote = await updateRemoteListing(id, next, prepared.images.assetIds, prepared.video.assetId, previous)
      const stored = { ...remote, userCreated: true }
      const siblingIdSet = new Set(siblingLocationIds)
      setOwnedListings((current) => current.map((item) => {
        if (item.id === id) return stored
        return siblingIdSet.has(item.id) ? applySharedListingLocation(item, stored) : item
      }))
      siblingLocationIds.forEach((siblingId) => {
        try { localStorage.removeItem(`112233:listing-edit-draft:v1:${siblingId}`) } catch { /* server state stays authoritative */ }
      })
      await removeUnusedMediaReferences(
        [...next.images, ...(next.video ? [next.video] : [])],
        [...stored.images, ...(stored.video ? [stored.video] : [])],
      ).catch(() => undefined)
      await refreshListingConsumers().catch(() => toast.error('Los cambios se guardaron, pero no se pudo refrescar el catálogo.'))
      if (siblingLocationIds.length) {
        toast.success(`Ubicación aplicada también a ${siblingLocationIds.length} ${siblingLocationIds.length === 1 ? 'anuncio' : 'anuncios'} del mismo domicilio.`)
      }
      return true
    } catch (error) {
      setOwnedListings((current) => current.map((item) => item.id === id ? previous : item))
      const uncertainCommit = error instanceof ApiError && ['REQUEST_TIMEOUT', 'NETWORK_ERROR'].includes(error.code ?? '')
      if (!uncertainCommit) await cleanupPreparedListingMedia(prepared)
      toast.error(listingUpdateErrorMessage(error))
      return false
    }
  }, [canManageListing, ownedListings, refreshListingConsumers])
  const deleteListing = useCallback(async (id: string): Promise<boolean> => {
    const listing = ownedListings.find((item) => item.id === id)
    if (!listing) return false
    if (!canManageListing(listing)) {
      toast.error('No puedes gestionar un anuncio de otra cuenta.')
      return false
    }
    try {
      // Do not touch browser drafts or IndexedDB media until the server has
      // accepted the permanent deletion of this user-created listing.
      await deleteRemoteListing(id)
    } catch (error) {
      toast.error(error instanceof ApiError && error.status === 403
        ? 'No tienes permiso para eliminar este anuncio.'
        : 'No se pudo eliminar el anuncio en el servidor.')
      return false
    }
    const remaining = ownedListings.filter((item) => item.id !== id)
    const draftRecord = readDraftRecord()
    const deleteDraft = draftRecord?.value.listingId === id
    const draftMedia = deleteDraft ? collectMediaReferences(draftRecord?.value) : new Set<string>()
    if (deleteDraft) {
      localStorage.removeItem(DRAFT_KEY)
      localStorage.removeItem(LEGACY_DRAFT_KEY)
    }
    try { localStorage.removeItem(`112233:listing-edit-draft:v1:${id}`) } catch { /* server deletion stays authoritative */ }
    setOwnedListings(remaining)
    setAllListings((current) => current.filter((item) => item.id !== id))
    setFavoriteScopes((current) => Object.fromEntries(
      Object.entries(current).map(([scope, ids]) => [scope, ids.filter((item) => item !== id)]),
    ))
    setDiscardedScopes((current) => Object.fromEntries(
      Object.entries(current).map(([scope, ids]) => [scope, ids.filter((item) => item !== id)]),
    ))
    setCommentScopes((current) => Object.fromEntries(
      Object.entries(current).map(([scope, comments]) => [scope, comments.filter((comment) => comment.listingId !== id)]),
    ))
    setReports((current) => current.filter((report) => report.listingId !== id))
    try {
      await removeUnusedMediaReferences([...listing.images, ...(listing.video ? [listing.video] : []), ...draftMedia], usedMediaReferences([...allListings.filter((item) => item.id !== id), ...remaining], users, deleteDraft ? null : draftRecord?.value))
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'No se pudieron limpiar las imágenes locales.')
    }
    await refreshListingConsumers().catch(() => toast.error('El anuncio se eliminó, pero no se pudo refrescar el catálogo.'))
    return true
  }, [allListings, canManageListing, ownedListings, refreshListingConsumers, users])
  const setListingStatus = useCallback(async (id: string, status: ListingStatus): Promise<ListingStatus | null> => {
    const previous = ownedListings.find((listing) => listing.id === id)
    if (!previous || !canManageListing(previous)) return null
    mutateOwned(id, (listing) => ({ ...listing, status, closedReason: status === 'Finalizado' ? listing.closedReason : undefined }))
    if (currentUser?.role === 'admin' && previous) {
      try {
        await moderateRemoteListing(id, status)
        await refreshListingConsumers()
        return status
      } catch {
        setOwnedListings((current) => current.map((listing) => listing.id === id ? previous : listing))
        toast.error('No se pudo moderar el anuncio en el servidor.')
        return null
      }
    } else {
      try {
        const remote = await setRemoteListingStatus(id, status)
        setOwnedListings((current) => current.map((listing) => listing.id === id ? { ...remote, userCreated: true } : listing))
        await refreshListingConsumers().catch(() => toast.error('El estado se guardó, pero no se pudo refrescar el catálogo.'))
        return remote.status
      } catch {
        setOwnedListings((current) => current.map((listing) => listing.id === id ? previous : listing))
        toast.error('No se pudo actualizar el estado del anuncio en el servidor.')
        return null
      }
    }
  }, [canManageListing, currentUser?.role, mutateOwned, ownedListings, refreshListingConsumers])
  const renewListing = useCallback(async (id: string): Promise<ListingStatus | null> => {
    const previous = ownedListings.find((listing) => listing.id === id)
    if (!previous || !canManageListing(previous)) return null
    mutateOwned(id, (listing) => ({ ...listing, closedReason: undefined }))
    try {
      const remote = await renewRemoteListing(id)
      setOwnedListings((current) => current.map((listing) => listing.id === id ? { ...remote, userCreated: true } : listing))
      await refreshListingConsumers().catch(() => toast.error('La renovación se guardó, pero no se pudo refrescar el catálogo.'))
      return remote.status
    } catch {
      setOwnedListings((current) => current.map((listing) => listing.id === id ? previous : listing))
      toast.error('No se pudo renovar el anuncio en el servidor.')
      return null
    }
  }, [canManageListing, mutateOwned, ownedListings, refreshListingConsumers])
  const closeListing = useCallback((id: string) => setListingStatus(id, 'Finalizado'), [setListingStatus])
  const refreshListingLifecycle = useCallback(() => undefined, [])
  const addReport = useCallback((listingId: string, reason: string, comment: string) => {
    const optimistic: ReportRecord = { id: `REP-${Date.now().toString().slice(-6)}`, listingId, reason, comment, createdAt: new Date().toISOString(), status: 'Abierta' }
    setReports((current) => [optimistic, ...current])
    void createRemoteReport(listingId, reason, comment).then((report) => {
      setReports((current) => current.map((item) => item.id === optimistic.id ? report : item))
    }).catch(() => {
      setReports((current) => current.filter((item) => item.id !== optimistic.id))
      toast.error('No se pudo enviar la denuncia al servidor.')
    })
  }, [])
  const addLocalComment = useCallback((listingId: string, text: string) => updateScope(setCommentScopes, (current) => [{ id: `comment-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`, userId: scopeKey, listingId, text: text.trim(), createdAt: new Date().toISOString() }, ...(current ?? [])]), [scopeKey, updateScope])
  const updateLocalComment = useCallback((id: string, text: string) => updateScope(setCommentScopes, (current) => (current ?? []).map((comment) => comment.id === id ? { ...comment, text: text.trim(), updatedAt: new Date().toISOString() } : comment)), [updateScope])
  const deleteLocalComment = useCallback((id: string) => updateScope(setCommentScopes, (current) => (current ?? []).filter((comment) => comment.id !== id)), [updateScope])

  const login = useCallback(async (email: string, password: string) => {
    try {
      setRemoteUser(await loginWithPassword(email, password))
      return null
    } catch (error) {
      return error instanceof ApiError ? error.message : 'No se pudo iniciar sesión. Inténtalo de nuevo.'
    }
  }, [setRemoteUser])
  const loginGoogle = useCallback(async (credential: string) => {
    try {
      setRemoteUser(await loginWithGoogle(credential))
      return null
    } catch (error) {
      return error instanceof ApiError ? error.message : 'No se pudo iniciar sesión con Google.'
    }
  }, [setRemoteUser])
  const selectGoogleRole = useCallback(async (role: 'tenant' | 'host') => {
    try {
      setRemoteUser(await saveGoogleRole(role))
      return null
    } catch (error) {
      return error instanceof ApiError ? error.message : 'No se pudo guardar tu elección.'
    }
  }, [setRemoteUser])
  const register = useCallback(async (input: RegisterInput) => {
    try {
      setRemoteUser(await registerAccount(input))
      return null
    } catch (error) {
      return error instanceof ApiError ? error.message : 'No se pudo crear la cuenta. Inténtalo de nuevo.'
    }
  }, [setRemoteUser])
  const logout = useCallback(() => {
    invalidateOwnedListings()
    setCurrentUserId(null)
    void logoutSession().catch(() => undefined)
  }, [invalidateOwnedListings])
  const updateProfile = useCallback((changes: ProfileUpdate) => {
    if (!currentUserId) return
    const previous = users.find((user) => user.id === currentUserId)
    const nextUsers = users.map((user) => user.id === currentUserId ? { ...user, ...changes } : user)
    setUsers(nextUsers)
    const serverFields = Object.fromEntries(
      Object.entries(changes).filter(([key]) => [
        'name', 'phone', 'whatsapp', 'telegram', 'about', 'showPhone', 'showWhatsApp',
      ].includes(key)),
    )
    if (Object.keys(serverFields).length) {
      void updateCurrentUser(serverFields).then(setRemoteUser).catch(() => {
        if (previous) setUsers((current) => current.map((user) => user.id === previous.id ? previous : user))
        toast.error('No se pudo guardar el perfil en el servidor.')
      })
    }
    if (Object.prototype.hasOwnProperty.call(changes, 'avatarRef')) {
      void updateCurrentAvatar(changes.avatarRef).then(setRemoteUser).catch(() => {
        if (previous) setUsers((current) => current.map((user) => user.id === previous.id ? previous : user))
        toast.error('No se pudo guardar el avatar en el servidor.')
      })
    }
    if (previous?.avatarRef && Object.prototype.hasOwnProperty.call(changes, 'avatarRef') && changes.avatarRef !== previous.avatarRef) {
      void removeUnusedMediaReferences([previous.avatarRef], usedMediaReferences(allListings, nextUsers)).catch((error) =>
        toast.error(error instanceof Error ? error.message : 'No se pudo limpiar el avatar anterior.'),
      )
    }
    toast.success('Perfil actualizado')
  }, [allListings, currentUserId, setRemoteUser, users])
  const deleteAccount = useCallback(async () => {
    if (!currentUserId) return false
    try {
      await deleteCurrentUser()
    } catch {
      toast.error('No se pudo eliminar la cuenta en el servidor.')
      return false
    }
    const accountListings = ownedListings.filter((listing) => listing.ownerUserId === currentUserId)
    const remainingListings = allListings.filter((listing) => listing.ownerUserId !== currentUserId)
    const remainingUsers = users.filter((user) => user.id !== currentUserId)
    const draftRecord = readDraftRecord()
    const draftOwner = draftRecord?.value.ownerUserId
    const deleteDraft = Boolean(draftRecord && (!draftOwner || draftOwner === currentUserId))
    const removedMedia = collectMediaReferences([accountListings, users.find((user) => user.id === currentUserId), deleteDraft ? draftRecord?.value : null])
    const retainedDraft = deleteDraft ? null : draftRecord?.value
    setAllListings(remainingListings)
    invalidateOwnedListings()
    setUsers(remainingUsers)
    setFavoriteScopes((current) => Object.fromEntries(Object.entries(current).filter(([scope]) => scope !== currentUserId)))
    setDiscardedScopes((current) => Object.fromEntries(Object.entries(current).filter(([scope]) => scope !== currentUserId)))
    setHistoryScopes((current) => Object.fromEntries(Object.entries(current).filter(([scope]) => scope !== currentUserId)))
    setSavedSearchScopes((current) => Object.fromEntries(Object.entries(current).filter(([scope]) => scope !== currentUserId)))
    setCommentScopes((current) => Object.fromEntries(Object.entries(current).filter(([scope]) => scope !== currentUserId)))
    setReports((current) => current.filter((report) => !accountListings.some((listing) => listing.id === report.listingId)))
    if (deleteDraft) {
      localStorage.removeItem(DRAFT_KEY)
      localStorage.removeItem(LEGACY_DRAFT_KEY)
    }
    setCurrentUserId(null)
    void removeUnusedMediaReferences([...removedMedia], usedMediaReferences(remainingListings, remainingUsers, retainedDraft)).catch((error) =>
      toast.error(error instanceof Error ? error.message : 'No se pudieron limpiar todos los datos multimedia de la cuenta.'),
    )
    return true
  }, [allListings, currentUserId, invalidateOwnedListings, ownedListings, users])
  const toggleUserBlocked = useCallback((id: string) => {
    if (currentUser?.role !== 'admin') return
    const previous = users.find((user) => user.id === id)
    if (!previous) return
    const blocked = !previous.blocked
    setUsers((current) => current.map((user) => user.id === id ? { ...user, blocked } : user))
    void setRemoteUserBlocked(id, blocked).catch(() => {
      setUsers((current) => current.map((user) => user.id === id ? previous : user))
      toast.error('No se pudo actualizar el estado de la cuenta.')
    })
  }, [currentUser?.role, users])

  const activeFilterCount = useMemo(() => getActiveFilterKeys(filters).length, [filters])
  const value = useMemo<AppState>(() => ({ rentalMode, setRentalMode, query, setQuery, favorites, toggleFavorite, discarded, discardListing, restoreDiscarded, filters, setFilters, resetFilters, activeFilterCount, searchHistory, addSearchHistory, clearSearchHistory, savedSearches, saveCurrentSearch, restoreSavedSearch, removeSavedSearch, toggleSearchAlerts, mapPolygon, setMapPolygon, clearMapPolygon, allListings, ownedListings, ownedListingsHydrationStatus, refreshOwnedListings: refreshOwnedConsumers, acceptListingSnapshot, partialPublication, createListing, updateListing, deleteListing, setListingStatus, renewListing, closeListing, refreshListingLifecycle, canManageListing, reports, addReport, localComments, addLocalComment, updateLocalComment, deleteLocalComment, users, currentUser, login, loginGoogle, selectGoogleRole, register, logout, updateProfile, deleteAccount, toggleUserBlocked, storageError, clearStorageError: () => setStorageError(null) }), [rentalMode, query, favorites, toggleFavorite, discarded, discardListing, restoreDiscarded, filters, setFilters, resetFilters, activeFilterCount, searchHistory, addSearchHistory, clearSearchHistory, savedSearches, saveCurrentSearch, restoreSavedSearch, removeSavedSearch, toggleSearchAlerts, mapPolygon, setMapPolygon, clearMapPolygon, allListings, ownedListings, ownedListingsHydrationStatus, refreshOwnedConsumers, acceptListingSnapshot, partialPublication, createListing, updateListing, deleteListing, setListingStatus, renewListing, closeListing, refreshListingLifecycle, canManageListing, reports, addReport, localComments, addLocalComment, updateLocalComment, deleteLocalComment, users, currentUser, login, loginGoogle, selectGoogleRole, register, logout, updateProfile, deleteAccount, toggleUserBlocked, storageError])
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function AppProvider({ children }: { children: ReactNode }) {
  return mockMode
    ? <MockAppProvider context={AppContext}>{children}</MockAppProvider>
    : <RemoteAppProvider>{children}</RemoteAppProvider>
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) throw new Error('useApp debe usarse dentro de AppProvider')
  return context
}
