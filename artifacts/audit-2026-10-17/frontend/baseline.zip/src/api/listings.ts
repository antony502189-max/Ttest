import { api, ApiError, resolveApiUrl } from '@/api/client'
import { buildListingSearchBody } from '@/lib/listing-search-body'
export { buildListingSearchBody } from '@/lib/listing-search-body'
import { ownerListingLocationChanged } from '@/lib/listing-address-group'
import { MAX_LISTING_PHOTOS, MIN_LISTING_PHOTOS } from '@/lib/media-storage'
import type { Filters, Listing, ListingStatus, TenantRequirement } from '@/types'

type ListingDto = {
  id: string
  ownerUserId: string
  owner: { name: string; initials: string; since: string | null; response: string; verified: boolean }
  contactPhone: string | null
  contactWhatsapp: string | null
  contactEmail: string | null
  showPhone: boolean
  showWhatsApp: boolean
  coverImageUrl: string | null
  imageUrls: string[]
  videoUrl: string | null
  title: string
  city: string
  area: string
  approximateAddress: string
  street?: string
  postcode?: string
  exactLatitude?: number | null
  exactLongitude?: number | null
  price: number | null
  cadence: 'mes' | 'noche'
  monthlyPrice: number | null
  nightlyPrice: number | null
  weeklyPrice: number | null
  rentalMode: 'long' | 'holiday'
  roomType: Listing['roomType']
  availableFrom: string | null
  availableUntil: string | null
  minimumStayMonths: number | null
  minimumNights: number | null
  depositAmount: number | null
  depositText: string | null
  billsIncluded: boolean | null
  billsText: string | null
  bathroom: Listing['bathroom'] | null
  kitchen: Listing['kitchen'] | null
  furnished: boolean | null
  roomSizeM2: number | null
  bedroomCount: number | null
  currentResidents: number
  roomCapacity: number | null
  shower: Listing['shower']
  homeSizeM2: number | null
  bathroomCount: number | null
  rentalUnit: Listing['rentalUnit'] | null
  bedType: Listing['bedType'] | null
  bedCount: number | null
  currentRoomResidents: number | null
  availableSpots: number | null
  toilet: Listing['toilet'] | null
  householdGender: Listing['householdGender'] | null
  householdHasChildren: boolean | null
  heatingType: Listing['heatingType'] | null
  accessible: boolean | null
  floor: Listing['floor'] | null
  couplesAllowed: boolean | null
  acceptedTenantTypes: NonNullable<Listing['acceptedTenantTypes']>
  tenantRequirement: TenantRequirement | null
  smokingAllowed: boolean | null
  petsAllowed: boolean | null
  childrenAllowed: boolean | null
  empadronamientoAllowed: boolean | null
  restrictions: string[]
  amenities: string[]
  status: string
  latitude: number | null
  longitude: number | null
  description: string
  homeDescription: string
  advertiserName: string | null
  advertiserType: Listing['advertiserType'] | null
  source: string | null
  isExternal: boolean
  primarySource: string | null
  sourceUrl: string | null
  sourcePriceText: string | null
  priceCurrency: string | null
  pricePeriod: 'month' | 'night' | 'week' | null
  priceIsFrom: boolean | null
  publishedAt: string | null
  expiresAt: string | null
  views: number
  closedReason: Listing['closedReason'] | null
  promoted: boolean
  promotionEndsAt?: string | null
}

type ListingCardDto = Pick<ListingDto, 'id' | 'title' | 'city' | 'area' | 'approximateAddress' | 'rentalMode' | 'price' | 'roomType' | 'currentResidents' | 'roomCapacity' | 'bedroomCount' | 'roomSizeM2' | 'availableFrom' | 'billsIncluded' | 'restrictions' | 'advertiserType' | 'isExternal' | 'sourceUrl' | 'primarySource' | 'sourcePriceText' | 'pricePeriod' | 'priceIsFrom' | 'publishedAt' | 'promoted' | 'coverImageUrl' | 'description'> & { imageUrls?: string[] }
export type ListingCardPage = { items: Listing[]; total: number; nextCursor: string | null; previousCursor: string | null }

type ListingImageDto = {
  assetId: string
  url: string
  sortOrder: number
  isCover: boolean
}

function orderedGalleryUrls(rows: ListingImageDto[]) {
  return [...rows]
    .sort((left, right) => Number(right.isCover) - Number(left.isCover) || left.sortOrder - right.sortOrder)
    .slice(0, MAX_LISTING_PHOTOS)
    .map((row) => resolveApiUrl(row.url))
}

async function hydrateIncompleteInternalGallery(listing: Listing, signal?: AbortSignal): Promise<Listing> {
  if (listing.isExternal || listing.images.length >= MIN_LISTING_PHOTOS) return listing
  try {
    const rows = await api<ListingImageDto[]>(`/listings/${listing.id}/images`, { signal })
    const images = orderedGalleryUrls(rows)
    // A successful nonempty response is authoritative, including legitimate
    // deletions. Failure/empty recovery retains the usable original cover.
    return images.length && (images.length !== listing.images.length
      || images.some((image, index) => image !== listing.images[index])) ? { ...listing, images } : listing
  } catch (error) {
    if (error instanceof ApiError && error.code === 'REQUEST_ABORTED') throw error
    // Search/detail must remain usable if the recovery endpoint is temporarily
    // unavailable. The original card image is still better than failing the page.
    return listing
  }
}

async function hydrateIncompleteInternalGalleries(listings: Listing[], signal?: AbortSignal) {
  return Promise.all(listings.map((listing) => hydrateIncompleteInternalGallery(listing, signal)))
}
export type ListingMapMarker =
  | { type: 'listing'; id: string; latitude: number; longitude: number; price: number | null; promoted: boolean; isExternal: boolean; sourceUrl: string | null }
  | { type: 'cluster'; id: string; latitude: number; longitude: number; count: number; promoted: boolean }

const statusMap: Record<string, ListingStatus> = {
  draft: 'Borrador', pending: 'Pendiente', published: 'Publicado', hidden: 'Oculto', closed: 'Finalizado', rejected: 'Rechazado',
}

const remoteStatusMap: Record<ListingStatus, string> = {
  Borrador: 'draft', Pendiente: 'pending', Publicado: 'published', Oculto: 'hidden', Finalizado: 'closed', Rechazado: 'rejected',
}

function dateOnly(value: string | null, fallback: string) {
  return value ? value.slice(0, 10) : fallback
}

export function toListing(dto: ListingDto): Listing {
  const availableFrom = dateOnly(dto.availableFrom, dto.isExternal ? '' : new Date().toISOString().slice(0, 10))
  const price = dto.price ?? (dto.rentalMode === 'holiday' ? dto.nightlyPrice : dto.monthlyPrice) ?? 0
  return {
    id: dto.id,
    title: dto.title,
    city: dto.city,
    area: dto.area,
    approximateAddress: dto.approximateAddress,
    ...(dto.street !== undefined ? { street: dto.street } : {}),
    ...(dto.postcode !== undefined ? { postcode: dto.postcode } : {}),
    ...(dto.exactLatitude != null && dto.exactLongitude != null
      ? { exactCoordinates: { lat: dto.exactLatitude, lng: dto.exactLongitude } }
      : {}),
    price,
    cadence: dto.cadence,
    monthlyPrice: dto.monthlyPrice ?? undefined,
    nightlyPrice: dto.nightlyPrice ?? undefined,
    weeklyPrice: dto.weeklyPrice ?? undefined,
    rentalMode: dto.rentalMode,
    roomType: dto.roomType,
    available: dto.availableFrom ? `Disponible desde ${availableFrom}` : 'Consultar disponibilidad',
    availableFrom,
    availableUntil: dto.availableUntil ? dateOnly(dto.availableUntil, availableFrom) : undefined,
    minimumStay: dto.rentalMode === 'holiday'
      ? dto.minimumNights == null ? 'Consultar estancia mínima' : `Mínimo ${dto.minimumNights} noche(s)`
      : dto.minimumStayMonths == null ? 'Consultar estancia mínima' : `Mínimo ${dto.minimumStayMonths} mes(es)`,
    minimumStayMonths: dto.minimumStayMonths,
    minimumNights: dto.minimumNights ?? undefined,
    deposit: dto.depositText ?? (dto.depositAmount != null ? `${dto.depositAmount} € de fianza` : 'Consultar fianza'),
    depositAmount: dto.depositAmount,
    bills: dto.billsText ?? (dto.billsIncluded == null ? 'Consultar gastos' : dto.billsIncluded ? 'Gastos incluidos' : 'Gastos no incluidos'),
    billsIncluded: dto.billsIncluded,
    bathroom: dto.bathroom,
    kitchen: dto.kitchen,
    furnished: dto.furnished,
    roomSizeM2: dto.roomSizeM2,
    bedroomCount: dto.bedroomCount ?? undefined,
    currentResidents: dto.currentResidents,
    roomCapacity: dto.roomCapacity,
    shower: dto.shower,
    homeSizeM2: dto.homeSizeM2,
    bathroomCount: dto.bathroomCount,
    rentalUnit: dto.rentalUnit,
    bedType: dto.bedType,
    bedCount: dto.bedCount,
    currentRoomResidents: dto.currentRoomResidents,
    availableSpots: dto.availableSpots,
    toilet: dto.toilet,
    householdGender: dto.householdGender,
    householdHasChildren: dto.householdHasChildren,
    heatingType: dto.heatingType,
    accessible: dto.accessible,
    floor: dto.floor,
    couplesAllowed: dto.couplesAllowed,
    acceptedTenantTypes: dto.acceptedTenantTypes,
    ...(dto.latitude != null && dto.longitude != null
      ? { coordinates: { lat: dto.latitude, lng: dto.longitude } }
      : {}),
    tenantRequirement: dto.tenantRequirement,
    smokingAllowed: dto.smokingAllowed,
    petsAllowed: dto.petsAllowed,
    childrenAllowed: dto.childrenAllowed,
    empadronamientoAllowed: dto.empadronamientoAllowed,
    restrictions: dto.restrictions,
    amenities: dto.amenities.map((item) => item === 'Fibra' ? 'Wi-Fi' : item),
    description: dto.description,
    homeDescription: dto.homeDescription,
    images: dto.imageUrls.slice(0, MAX_LISTING_PHOTOS).map(resolveApiUrl),
    ...(dto.videoUrl ? { video: resolveApiUrl(dto.videoUrl) } : {}),
    owner: {
      name: dto.owner.name,
      initials: dto.owner.initials,
      since: dto.owner.since ? new Date(dto.owner.since).getFullYear().toString() : 'Cuenta verificada',
      response: dto.owner.response,
      verified: dto.owner.verified,
    },
    advertiserType: dto.advertiserType ?? 'Particular',
    source: dto.source ?? undefined,
    isExternal: dto.isExternal,
    primarySource: dto.primarySource ?? undefined,
    sourceUrl: dto.sourceUrl ?? undefined,
    sourcePriceText: dto.sourcePriceText ?? undefined,
    priceCurrency: dto.priceCurrency ?? undefined,
    pricePeriod: dto.pricePeriod ?? undefined,
    priceIsFrom: dto.priceIsFrom ?? undefined,
    // A forward/invalid server value must fail closed in browser consumers.
    // Defaulting unknown values to public previously made map/search exposure
    // possible before the frontend understood a new lifecycle state.
    status: statusMap[dto.status] ?? 'Pendiente',
    publishedAt: dateOnly(dto.publishedAt, availableFrom),
    views: dto.views,
    expiresAt: dateOnly(dto.expiresAt, '2099-12-31'),
    ownerUserId: dto.ownerUserId,
    contactPhone: dto.contactPhone ?? undefined,
    contactWhatsapp: dto.contactWhatsapp ?? undefined,
    contactEmail: dto.contactEmail ?? undefined,
    showPhone: dto.showPhone,
    showWhatsApp: dto.showWhatsApp,
    closedReason: dto.closedReason ?? undefined,
    promoted: dto.promoted,
    ...(dto.promotionEndsAt ? { promotionEndsAt: dto.promotionEndsAt } : {}),
  }
}

export function toCardListing(dto: ListingCardDto): Listing {
  const availableFrom = dateOnly(dto.availableFrom, dto.isExternal ? '' : new Date().toISOString().slice(0, 10))
  return {
    id: dto.id, title: dto.title, city: dto.city, area: dto.area,
    approximateAddress: dto.approximateAddress, rentalMode: dto.rentalMode,
    price: dto.price ?? 0, cadence: dto.rentalMode === 'holiday' ? 'noche' : 'mes',
    roomType: dto.roomType, currentResidents: dto.currentResidents, roomCapacity: dto.roomCapacity,
    bedroomCount: dto.bedroomCount ?? undefined, roomSizeM2: dto.roomSizeM2,
    available: dto.availableFrom ? `Disponible desde ${availableFrom}` : 'Consultar disponibilidad',
    availableFrom, minimumStay: 'Consultar estancia mínima', minimumStayMonths: null,
    deposit: 'Consultar fianza', depositAmount: null,
    bills: dto.billsIncluded == null ? 'Consultar gastos' : dto.billsIncluded ? 'Gastos incluidos' : 'Gastos no incluidos',
    billsIncluded: dto.billsIncluded, bathroom: null, kitchen: null, furnished: null,
    shower: 'Ducha compartida', tenantRequirement: null,
    smokingAllowed: null, petsAllowed: null, childrenAllowed: null, empadronamientoAllowed: null,
    restrictions: dto.restrictions, amenities: [], description: dto.description, homeDescription: '',
    images: dto.imageUrls?.length
      ? dto.imageUrls.slice(0, MAX_LISTING_PHOTOS).map(resolveApiUrl)
      : dto.coverImageUrl ? [resolveApiUrl(dto.coverImageUrl)] : [],
    owner: { name: '', initials: '', since: '', response: '', verified: false },
    advertiserType: dto.advertiserType ?? 'Particular', isExternal: dto.isExternal,
    sourceUrl: dto.sourceUrl ?? undefined, primarySource: dto.primarySource ?? undefined,
    sourcePriceText: dto.sourcePriceText ?? undefined, pricePeriod: dto.pricePeriod ?? undefined,
    priceIsFrom: dto.priceIsFrom ?? undefined, status: 'Publicado',
    publishedAt: dateOnly(dto.publishedAt, availableFrom), views: 0, expiresAt: '2099-12-31',
    showPhone: false, showWhatsApp: false, promoted: dto.promoted,
  }
}

export async function getPublicCardsByIds(ids: string[], signal?: AbortSignal): Promise<Listing[]> {
  const validIds = ids.filter((id) => /^[0-9a-f-]{36}$/i.test(id))
  const chunks = Array.from({ length: Math.ceil(validIds.length / 100) }, (_, index) => validIds.slice(index * 100, (index + 1) * 100))
  const responses = await Promise.all(chunks.map((chunk) => api<ListingCardDto[]>('/listings/cards/resolve', { method: 'POST', body: JSON.stringify({ ids: chunk }), signal })))
  return hydrateIncompleteInternalGalleries(responses.flat().map(toCardListing), signal)
}

export async function getSimilarListings(id: string, signal?: AbortSignal): Promise<Listing[]> {
  const cards = await api<ListingCardDto[]>(`/listings/similar/${id}`, { signal })
  return hydrateIncompleteInternalGalleries(cards.map(toCardListing), signal)
}

export type AutonomousCommunityCount = { id: string; count: number; cities: string[] }

export async function getAutonomousCommunityCounts(input: ListingSearchInput, signal?: AbortSignal): Promise<AutonomousCommunityCount[]> {
  const body = buildListingSearchBody({ ...input, query: 'España', autonomousCommunity: undefined })
  const response = await api<{ items: AutonomousCommunityCount[] }>('/listings/regions/counts', {
    method: 'POST', body: JSON.stringify(body), signal,
  })
  return response.items
}

export async function getMapMarkers(body: Record<string, unknown>, signal?: AbortSignal): Promise<ListingMapMarker[]> {
  const response = await api<{ items: ListingMapMarker[] }>('/listings/map', { method: 'POST', body: JSON.stringify(body), signal })
  return response.items
}

export function getCatalogVersion(signal?: AbortSignal) {
  return api<{ version: string; updatedAt: string }>('/listings/catalog-version', { signal })
}

export async function getOwnedListings(signal?: AbortSignal) {
  return (await api<ListingDto[]>('/listings/mine', { signal })).map(toListing)
}

export async function getPublicListing(id: string) {
  const listing = toListing(await api<ListingDto>(`/listings/${id}`))
  return hydrateIncompleteInternalGallery(listing)
}

export async function getHomepageHeroListing(signal?: AbortSignal) {
  const dto = await api<ListingDto | null>('/listings/homepage-hero', { signal })
  return dto ? toListing(dto) : null
}

export type ListingSearchInput = {
  rentalMode: Listing['rentalMode']
  minPrice: number
  maxPrice: number
  filters: Filters
  query?: string
  autonomousCommunity?: string
  roomTypes?: Listing['roomType'][]
  bounds?: { north: number; south: number; east: number; west: number }
  polygon?: Array<{ latitude: number; longitude: number }>
  center?: { latitude: number; longitude: number }
  radiusKm?: number
  sort?: 'newest' | 'oldest' | 'price_asc' | 'price_desc' | 'saved_new' | 'saved_old' | 'reduced' | 'sqm_asc' | 'sqm_desc' | 'area_asc' | 'area_desc' | 'floor_asc' | 'floor_desc'
  favoriteIds?: string[]
}

export async function searchPublicListings(
  input: ListingSearchInput,
  signal?: AbortSignal,
  cursor?: string,
  limit = 20,
  onGalleryRecovered?: (listing: Listing) => void,
): Promise<ListingCardPage> {
  const response = await api<{ items: ListingCardDto[]; total: number; nextCursor: string | null; previousCursor: string | null }>('/listings/search/cards', {
    method: 'POST', body: JSON.stringify({ ...buildListingSearchBody(input), cursor, limit }), signal,
  })
  const seen = new Set<string>()
  const cards = response.items.filter((item) => {
    if (seen.has(item.id)) return false
    seen.add(item.id)
    return true
  }).map(toCardListing)
  if (onGalleryRecovered) {
    // Render search cards immediately, then recover a legacy/truncated native
    // gallery without waiting for the slowest /listings/:id/images request.
    // The callback updates only the matching visible card; cancellation
    // prevents previous-query recoveries from overwriting new results.
    for (const card of cards) {
      if (card.isExternal || card.images.length >= MIN_LISTING_PHOTOS) continue
      void hydrateIncompleteInternalGallery(card, signal).then((recovered) => {
        if (!signal?.aborted && recovered !== card) onGalleryRecovered(recovered)
      }).catch(() => undefined)
    }
  } else {
    // Preserve the old synchronous hydration contract for other consumers
    // that do not support progressive gallery updates.
    return {
      items: await hydrateIncompleteInternalGalleries(cards, signal),
      total: response.total,
      nextCursor: response.nextCursor,
      previousCursor: response.previousCursor,
    }
  }
  return {
    items: cards,
    total: response.total,
    nextCursor: response.nextCursor,
    previousCursor: response.previousCursor,
  }
}

async function syncContactProfile(listing: Listing) {
  await api('/users/me', {
    method: 'PATCH',
    body: JSON.stringify({
      name: listing.owner.name.trim(),
      phone: listing.contactPhone ?? '',
      whatsapp: listing.contactWhatsapp ?? '',
      showPhone: listing.showPhone,
      showWhatsApp: listing.showWhatsApp,
    }),
  })
}

function listingPayload(listing: Listing, existing?: Listing, assetIds?: string[], videoAssetId?: string | null) {
  const exact = listing.exactCoordinates ?? existing?.exactCoordinates
  const coordinates = listing.coordinates
  if (!coordinates) throw new Error('Coordinates are required for owner-created listings')
  return {
    title: listing.title, city: listing.city, area: listing.area,
    // The API boundary must serialize the state passed by the form. Reading a
    // global browser draft here can shadow an edit-specific draft and silently
    // persist stale private address values from a different workflow.
    street: listing.street?.trim() ?? existing?.street ?? '',
    postcode: listing.postcode?.trim() ?? existing?.postcode ?? '',
    approximateAddress: listing.approximateAddress,
    rentalMode: listing.rentalMode, monthlyPrice: listing.monthlyPrice ?? null, nightlyPrice: listing.nightlyPrice ?? null,
    weeklyPrice: listing.weeklyPrice ?? null, roomType: listing.roomType, availableFrom: listing.availableFrom,
    availableUntil: listing.availableUntil ?? null, minimumStayMonths: listing.minimumStayMonths,
    minimumNights: listing.minimumNights ?? null, depositAmount: listing.depositAmount, billsIncluded: listing.billsIncluded,
    billsText: listing.bills,
    bathroom: listing.bathroom, kitchen: listing.kitchen, furnished: listing.furnished, roomSizeM2: listing.roomSizeM2,
    bedroomCount: listing.bedroomCount ?? null, currentResidents: listing.currentResidents, roomCapacity: listing.roomCapacity,
    shower: listing.shower, homeSizeM2: listing.homeSizeM2 ?? null, bathroomCount: listing.bathroomCount ?? null,
    rentalUnit: listing.rentalUnit ?? null, bedType: listing.bedType ?? null, bedCount: listing.bedCount ?? null,
    currentRoomResidents: listing.currentRoomResidents ?? null, toilet: listing.toilet ?? null,
    householdGender: listing.householdGender ?? null, householdHasChildren: listing.householdHasChildren ?? null,
    heatingType: listing.heatingType ?? null, accessible: listing.accessible ?? null, floor: listing.floor ?? null, couplesAllowed: listing.couplesAllowed ?? null,
    acceptedTenantTypes: listing.acceptedTenantTypes ?? [],
    tenantRequirement: listing.tenantRequirement, smokingAllowed: listing.smokingAllowed,
    petsAllowed: listing.petsAllowed, childrenAllowed: listing.childrenAllowed, empadronamientoAllowed: listing.empadronamientoAllowed,
    restrictions: listing.restrictions, amenities: listing.amenities, latitude: coordinates.lat,
    longitude: coordinates.lng, exactLatitude: exact?.lat ?? null, exactLongitude: exact?.lng ?? null,
    description: listing.description, homeDescription: listing.homeDescription,
    advertiserType: listing.advertiserType,
    ...(!existing ? {
      contactName: listing.owner.name.trim(),
      contactPhone: listing.contactPhone ?? '',
      contactWhatsapp: listing.contactWhatsapp ?? '',
      showPhone: listing.showPhone,
      showWhatsApp: listing.showWhatsApp,
    } : {}),
    ...(existing && ownerListingLocationChanged(listing, existing) ? { syncAddressGroup: true } : {}),
    ...(assetIds ? { assetIds } : {}),
    ...(videoAssetId !== undefined ? { videoAssetId } : {}),
  }
}

export async function createRemoteListing(listing: Listing, assetIds: string[] = [], videoAssetId: string | null = null) {
  const request = () => api<ListingDto>('/listings', {
    method: 'POST',
    headers: { 'Idempotency-Key': listing.id },
    body: JSON.stringify(listingPayload(listing, undefined, assetIds, videoAssetId)),
  })
  try {
    return toListing(await request())
  } catch (error) {
    // A timed-out POST may already have committed. The durable publication
    // key makes one retry safe and returns the original listing if it did.
    if (!(error instanceof ApiError) || !['REQUEST_TIMEOUT', 'NETWORK_ERROR'].includes(error.code ?? '')) throw error
    return toListing(await request())
  }
}

function assertOwnerLocationEcho(intended: Listing, remote: Listing) {
  const textMatches = (left: string | undefined, right: string | undefined) => (left ?? '').trim() === (right ?? '').trim()
  const exactMatches = !intended.exactCoordinates
    || Boolean(
      remote.exactCoordinates
        && Math.abs(remote.exactCoordinates.lat - intended.exactCoordinates.lat) < 1e-6
        && Math.abs(remote.exactCoordinates.lng - intended.exactCoordinates.lng) < 1e-6,
    )
  if (
    intended.city !== remote.city
    || !textMatches(intended.area, remote.area)
    || !textMatches(intended.street, remote.street)
    || !textMatches(intended.postcode, remote.postcode)
    || !exactMatches
  ) {
    throw new Error('El servidor no confirmó la ubicación guardada. Los cambios no se marcarán como guardados.')
  }
}

export async function updateRemoteListing(id: string, listing: Listing, assetIds: string[], videoAssetId: string | null, existing?: Listing) {
  await syncContactProfile(listing)
  const previous = existing ?? (await getOwnedListings()).find((item) => item.id === id)
  const request = () => api<ListingDto>(`/listings/${id}`, {
    method: 'PATCH', body: JSON.stringify(listingPayload(listing, previous, assetIds, videoAssetId)),
  })
  const run = async () => {
    const remote = toListing(await request())
    assertOwnerLocationEcho(listing, remote)
    return remote
  }
  try {
    return await run()
  } catch (error) {
    // The atomic PATCH is idempotent for the same target state. Retry once if
    // the response was lost after commit instead of reporting a false failure.
    if (!(error instanceof ApiError) || !['REQUEST_TIMEOUT', 'NETWORK_ERROR'].includes(error.code ?? '')) throw error
    return run()
  }
}

export async function setRemoteListingStatus(id: string, status: ListingStatus) {
  return toListing(await api<ListingDto>(`/listings/${id}`, {
    method: 'PATCH', body: JSON.stringify({ status: remoteStatusMap[status] }),
  }))
}

export async function renewRemoteListing(id: string) {
  return toListing(await api<ListingDto>(`/listings/${id}/renew`, { method: 'POST' }))
}

export const deleteRemoteListing = (id: string) => api<void>(`/listings/${id}`, { method: 'DELETE' })
