import { api, resolveApiUrl } from '@/api/client'
import { getMediaBlob, isMediaReference, prepareImageForUpload } from '@/lib/media-storage'

type MediaAssetDto = { id: string; url: string }
type ListingImageDto = { assetId: string; url: string; sortOrder: number; isCover: boolean }

export type PreparedListingImages = {
  assetIds: string[]
  newlyUploaded: string[]
}

export type PreparedListingVideo = {
  assetId: string | null
  newlyUploaded: string[]
}

const UPLOAD_CONCURRENCY = 3
const assetIdFromUrl = (reference: string) => reference.match(/\/media\/([0-9a-f-]{36})(?:$|[?#])/i)?.[1]

export async function uploadMediaReference(reference: string) {
  const blob = await getMediaBlob(reference)
  if (!blob) throw new Error('No se encontró una de las imágenes locales.')
  const body = new FormData()
  body.append('file', new File([blob], 'listing-image.webp', { type: blob.type || 'image/webp' }))
  return api<MediaAssetDto>('/uploads', { method: 'POST', body, timeoutMs: 45_000 })
}

/** Direct owner upload used when IndexedDB is unavailable or out of space.
 * The returned asset is kept until the user saves the listing; do not discard
 * it simply because local browser storage failed. */
export async function uploadImageFile(file: File) {
  const prepared = await prepareImageForUpload(file)
  const body = new FormData()
  body.append('file', prepared, prepared.name)
  return api<MediaAssetDto>('/uploads', { method: 'POST', body, timeoutMs: 90_000 })
}

export async function uploadVideoFile(file: File) {
  const body = new FormData()
  body.append('file', file, file.name || 'listing-video')
  return api<MediaAssetDto>('/uploads/video', { method: 'POST', body, timeoutMs: 900_000 })
}

export async function uploadVideoReference(reference: string) {
  const blob = await getMediaBlob(reference)
  if (!blob) throw new Error('No se encontró el vídeo local.')
  const file = blob instanceof File
    ? blob
    : new File([blob], 'listing-video', { type: blob.type || 'application/octet-stream' })
  return uploadVideoFile(file)
}

async function deleteUploadedAsset(assetId: string) {
  await api<void>(`/uploads/${assetId}`, { method: 'DELETE' })
}

export async function cleanupUploadedMediaReference(reference: string) {
  const assetId = assetIdFromUrl(reference)
  if (!assetId) return
  await deleteUploadedAsset(assetId)
}

export async function cleanupPreparedListingImages(prepared: PreparedListingImages) {
  await Promise.allSettled(prepared.newlyUploaded.map(deleteUploadedAsset))
}

export async function cleanupPreparedListingVideo(prepared: PreparedListingVideo) {
  await Promise.allSettled(prepared.newlyUploaded.map(deleteUploadedAsset))
}

export async function prepareListingImages(references: string[]): Promise<PreparedListingImages> {
  const assetIds = new Array<string>(references.length)
  const newlyUploaded: string[] = []
  let cursor = 0

  const worker = async () => {
    while (true) {
      const index = cursor++
      if (index >= references.length) return
      const reference = references[index]
      const existingId = assetIdFromUrl(reference)
      if (existingId) {
        assetIds[index] = existingId
        continue
      }
      if (!isMediaReference(reference)) {
        throw new Error('Una de las imágenes ya no está disponible. Vuelve a añadirla.')
      }
      const uploaded = await uploadMediaReference(reference)
      assetIds[index] = uploaded.id
      newlyUploaded.push(uploaded.id)
    }
  }

  const workers = await Promise.allSettled(
    Array.from({ length: Math.min(UPLOAD_CONCURRENCY, references.length) }, () => worker()),
  )
  const failed = workers.find((result): result is PromiseRejectedResult => result.status === 'rejected')
  if (failed) {
    await Promise.allSettled(newlyUploaded.map(deleteUploadedAsset))
    throw failed.reason
  }
  return { assetIds, newlyUploaded }
}

export async function prepareListingVideo(reference?: string): Promise<PreparedListingVideo> {
  if (!reference) return { assetId: null, newlyUploaded: [] }
  const existingId = assetIdFromUrl(reference)
  if (existingId) return { assetId: existingId, newlyUploaded: [] }
  if (!isMediaReference(reference)) {
    throw new Error('El vídeo ya no está disponible. Vuelve a añadirlo.')
  }
  const uploaded = await uploadVideoReference(reference)
  return { assetId: uploaded.id, newlyUploaded: [uploaded.id] }
}

export type PreparedListingMedia = {
  images: PreparedListingImages
  video: PreparedListingVideo
}

export async function prepareListingMedia(imageReferences: string[], videoReference?: string): Promise<PreparedListingMedia> {
  const images = await prepareListingImages(imageReferences)
  try {
    const video = await prepareListingVideo(videoReference)
    return { images, video }
  } catch (error) {
    await cleanupPreparedListingImages(images)
    throw error
  }
}

export async function cleanupPreparedListingMedia(prepared: PreparedListingMedia) {
  await Promise.allSettled([
    cleanupPreparedListingImages(prepared.images),
    cleanupPreparedListingVideo(prepared.video),
  ])
}

export async function syncListingImages(listingId: string, references: string[]) {
  const prepared = await prepareListingImages(references)
  try {
    const images = await api<ListingImageDto[]>(`/listings/${listingId}/images`, {
      method: 'PUT', body: JSON.stringify({ assetIds: prepared.assetIds }),
    })
    return images.sort((a, b) => a.sortOrder - b.sortOrder).map((image) => resolveApiUrl(image.url))
  } catch (error) {
    await cleanupPreparedListingImages(prepared)
    throw error
  }
}
