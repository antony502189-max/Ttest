import { rentalPriceAllowed } from './rental-price-limit'
import type { AcceptedTenantType, BedType, Coordinates, HeatingType, HouseholdGender, Listing, MappedListing, RentalUnit, TenantRequirement, ToiletType } from '@/types'

export const tenantRequirementLabels: Record<TenantRequirement, string> = {
  'single-man': 'Solo hombre',
  'single-woman': 'Solo mujer',
  'single-person': '1 persona',
  couple: '2 personas (pareja/amigos)',
  any: 'Sin restricciones',
}

export const unknownListingFact = 'Consultar con el anunciante'

export function hasListingCoordinates(listing: Listing): listing is MappedListing {
  const coordinates = listing.coordinates
  return Boolean(
    coordinates
    && Number.isFinite(coordinates.lat)
    && Number.isFinite(coordinates.lng),
  )
}

export function getPrimaryPrice(listing: Listing) {
  return listing.rentalMode === 'holiday'
    ? listing.nightlyPrice ?? listing.price
    : listing.monthlyPrice ?? listing.price
}

export function getPrimaryCadence(listing: Listing): 'mes' | 'noche' {
  return listing.rentalMode === 'holiday' ? 'noche' : 'mes'
}

export function getBedroomCount(listing: Listing) {
  const explicit = Number(listing.bedroomCount)
  if (Number.isFinite(explicit) && explicit >= 1) return Math.min(99, Math.max(1, Math.round(explicit)))
  if (listing.roomType === 'Estudio') return 1
  return Math.min(99, Math.max(1, Math.round((listing.currentResidents || 1) + 1)))
}

export function getCriticalRestrictions(listing: Listing): string[] {
  const restrictions = [
    listing.tenantRequirement == null ? unknownListingFact : tenantRequirementLabels[listing.tenantRequirement],
    listing.roomCapacity == null ? unknownListingFact : `Habitación para ${listing.roomCapacity} ${listing.roomCapacity === 1 ? 'persona' : 'personas'}`,
    listing.petsAllowed == null ? '' : listing.petsAllowed ? 'Mascotas permitidas' : 'Sin mascotas',
    listing.smokingAllowed == null ? '' : listing.smokingAllowed ? 'Se puede fumar' : 'No fumar',
    listing.childrenAllowed == null ? '' : listing.childrenAllowed ? 'Niños permitidos' : 'Sin niños',
    listing.empadronamientoAllowed == null ? '' : listing.empadronamientoAllowed ? 'Empadronamiento posible' : 'Sin empadronamiento',
    listing.rentalMode === 'holiday'
      ? listing.minimumNights == null ? '' : `Estancia mínima de ${listing.minimumNights} ${listing.minimumNights === 1 ? 'noche' : 'noches'}`
      : listing.minimumStayMonths == null ? '' : `Estancia mínima de ${listing.minimumStayMonths} ${listing.minimumStayMonths === 1 ? 'mes' : 'meses'}`,
    listing.billsIncluded == null ? unknownListingFact : listing.billsIncluded ? 'Gastos incluidos' : listing.bills,
  ]
  return [...new Set(restrictions.filter(Boolean))]
}

export function getImageCriticalRestrictions(listing: Listing): string[] {
  const conditions: string[] = []
  if (listing.tenantRequirement && listing.tenantRequirement !== 'any') conditions.push(tenantRequirementLabels[listing.tenantRequirement])
  if (listing.petsAllowed === false) conditions.push('Sin mascotas')
  if (listing.childrenAllowed === false) conditions.push('Sin niños')
  if (listing.smokingAllowed === false) conditions.push('No fumar')
  if (!conditions.length && listing.roomCapacity === 1) conditions.push('1 persona')
  return [...new Set(conditions)].slice(0, 2)
}

export function buildContactConfirmationText(listing: Listing) {
  const conditions = getCriticalRestrictions(listing)
    .slice(0, 5)
    .map((item) => item.charAt(0).toLocaleLowerCase('es-ES') + item.slice(1))
  const last = conditions.pop()
  return `Confirmo que cumplo estas condiciones: ${conditions.join(', ')}${conditions.length && last ? ' y ' : ''}${last ?? ''}.`
}

type LegacyListing = Partial<Listing> & {
  size?: number
  occupants?: number
  genderPreference?: string
  couplesAllowed?: boolean
}

function inferTenantRequirement(listing: LegacyListing): TenantRequirement | null {
  if (listing.tenantRequirement) return listing.tenantRequirement
  if (listing.genderPreference === 'Solo hombre') return 'single-man'
  if (listing.genderPreference === 'Solo mujer') return 'single-woman'
  if (listing.couplesAllowed && listing.roomType !== 'Habitación individual') return 'couple'
  return listing.isExternal ? null : 'any'
}

function enumValue<T extends string>(value: unknown, allowed: readonly T[]): T | null {
  return typeof value === 'string' && allowed.includes(value as T) ? value as T : null
}

function acceptedTenantTypes(value: unknown): AcceptedTenantType[] {
  const allowed: AcceptedTenantType[] = ['man', 'woman', 'couple', 'family']
  if (!Array.isArray(value)) return []
  return [...new Set(value.filter((item): item is AcceptedTenantType => enumValue(item, allowed) !== null))]
}

export function isListingLike(value: unknown): value is Partial<Listing> & Pick<Listing, 'id' | 'title' | 'rentalMode' | 'images' | 'publishedAt'> {
  if (!value || typeof value !== 'object') return false
  const listing = value as Record<string, unknown>
  const coordinates = listing.coordinates as Record<string, unknown> | null | undefined
  const coordinatesValid = coordinates == null || (
    typeof coordinates.lat === 'number'
    && Number.isFinite(coordinates.lat)
    && typeof coordinates.lng === 'number'
    && Number.isFinite(coordinates.lng)
  )
  return typeof listing.id === 'string'
    && typeof listing.title === 'string'
    && typeof listing.city === 'string'
    && typeof listing.area === 'string'
    && typeof listing.price === 'number'
    && Number.isFinite(listing.price)
    && (listing.rentalMode === 'long' || listing.rentalMode === 'holiday')
    && Array.isArray(listing.images)
    && listing.images.every((image) => typeof image === 'string')
    && typeof listing.publishedAt === 'string'
    && typeof listing.expiresAt === 'string'
    && coordinatesValid
}

export function normalizeListing(value: unknown): Listing | null {
  if (!isListingLike(value)) return null
  const legacy = value as LegacyListing
  const rentalMode = value.rentalMode
  const tenantRequirement = inferTenantRequirement(legacy)
  const roomCapacity = typeof legacy.roomCapacity === 'number' && legacy.roomCapacity >= 1
    ? Math.min(10, Math.round(legacy.roomCapacity))
    : tenantRequirement === 'couple' ? 2 : legacy.isExternal ? null : 1
  const price = typeof legacy.price === 'number' ? legacy.price : 0
  const monthlyPrice = typeof legacy.monthlyPrice === 'number'
    ? legacy.monthlyPrice
    : rentalMode === 'long' ? price : undefined
  const nightlyPrice = typeof legacy.nightlyPrice === 'number'
    ? legacy.nightlyPrice
    : rentalMode === 'holiday' ? price : undefined
  const rentalUnit = enumValue<RentalUnit>(legacy.rentalUnit, ['room', 'bed'])
  const bedType = enumValue<BedType>(legacy.bedType, ['single', 'double', 'bunk'])
  const toilet = enumValue<ToiletType>(legacy.toilet, ['Aseo privado', 'Aseo compartido'])
  const householdGender = enumValue<HouseholdGender>(legacy.householdGender, ['men', 'women', 'mixed', 'unknown'])
  const heatingType = enumValue<HeatingType>(legacy.heatingType, ['individual', 'central', 'none', 'unknown'])
  const currentRoomResidents = typeof legacy.currentRoomResidents === 'number' && Number.isFinite(legacy.currentRoomResidents)
    ? Math.max(0, Math.min(9, Math.round(legacy.currentRoomResidents)))
    : null
  const availableSpots = roomCapacity != null && currentRoomResidents != null
    ? Math.max(0, roomCapacity - currentRoomResidents)
    : null
  const listing: Listing = {
    id: value.id,
    title: value.title,
    city: legacy.city ?? 'Tenerife',
    area: legacy.area ?? 'Tenerife',
    approximateAddress: legacy.approximateAddress ?? `${legacy.area ?? 'Tenerife'} · ubicación aproximada`,
    price: rentalMode === 'holiday' ? nightlyPrice ?? price : monthlyPrice ?? price,
    cadence: rentalMode === 'holiday' ? 'noche' : 'mes',
    monthlyPrice,
    nightlyPrice,
    weeklyPrice: legacy.weeklyPrice,
    rentalMode,
    roomType: legacy.roomType ?? 'Habitación individual',
    available: legacy.available ?? 'Consultar disponibilidad',
    availableFrom: legacy.availableFrom ?? new Date().toISOString().slice(0, 10),
    availableUntil: legacy.availableUntil,
    minimumStay: legacy.minimumStay ?? (legacy.isExternal ? 'Consultar estancia mínima' : rentalMode === 'holiday' ? 'Mínimo 1 noche' : 'Mínimo 1 mes'),
    minimumStayMonths: typeof legacy.minimumStayMonths === 'number' ? legacy.minimumStayMonths : legacy.isExternal ? null : rentalMode === 'long' ? 1 : 0,
    minimumNights: typeof legacy.minimumNights === 'number' ? legacy.minimumNights : legacy.isExternal ? undefined : rentalMode === 'holiday' ? 1 : undefined,
    deposit: legacy.deposit ?? (legacy.isExternal ? unknownListingFact : 'Sin fianza'),
    depositAmount: typeof legacy.depositAmount === 'number' ? legacy.depositAmount : legacy.isExternal ? null : 0,
    bills: legacy.bills ?? (legacy.isExternal ? unknownListingFact : 'Gastos no especificados'),
    billsIncluded: typeof legacy.billsIncluded === 'boolean' ? legacy.billsIncluded : legacy.isExternal ? null : false,
    bathroom: legacy.bathroom ?? (legacy.isExternal ? null : 'Baño compartido'),
    kitchen: legacy.kitchen ?? (legacy.isExternal ? null : 'Cocina compartida'),
    furnished: typeof legacy.furnished === 'boolean' ? legacy.furnished : legacy.isExternal ? null : true,
    roomSizeM2: typeof legacy.roomSizeM2 === 'number' ? legacy.roomSizeM2 : typeof legacy.size === 'number' ? legacy.size : legacy.isExternal ? null : 12,
    homeSizeM2: typeof legacy.homeSizeM2 === 'number' && Number.isFinite(legacy.homeSizeM2) ? Math.max(1, Math.round(legacy.homeSizeM2)) : null,
    bedroomCount: typeof legacy.bedroomCount === 'number' && Number.isFinite(legacy.bedroomCount)
      ? Math.min(99, Math.max(1, Math.round(legacy.bedroomCount)))
      : legacy.roomType === 'Estudio' ? 1 : Math.min(99, Math.max(1, Math.round((legacy.currentResidents ?? legacy.occupants ?? 1) + 1))),
    bathroomCount: typeof legacy.bathroomCount === 'number' && Number.isFinite(legacy.bathroomCount) ? Math.max(0, Math.min(20, Math.round(legacy.bathroomCount))) : null,
    currentResidents: typeof legacy.currentResidents === 'number' ? legacy.currentResidents : typeof legacy.occupants === 'number' ? legacy.occupants : 1,
    roomCapacity,
    rentalUnit,
    bedType,
    bedCount: typeof legacy.bedCount === 'number' && Number.isFinite(legacy.bedCount) ? Math.max(1, Math.min(10, Math.round(legacy.bedCount))) : null,
    currentRoomResidents,
    availableSpots: typeof legacy.availableSpots === 'number' && Number.isFinite(legacy.availableSpots) ? Math.max(0, Math.round(legacy.availableSpots)) : availableSpots,
    toilet,
    shower: legacy.shower === 'Ducha privada' ? 'Ducha privada' : 'Ducha compartida',
    householdGender,
    householdHasChildren: typeof legacy.householdHasChildren === 'boolean' ? legacy.householdHasChildren : null,
    heatingType,
    accessible: typeof legacy.accessible === 'boolean' ? legacy.accessible : null,
    couplesAllowed: typeof legacy.couplesAllowed === 'boolean' ? legacy.couplesAllowed : null,
    acceptedTenantTypes: acceptedTenantTypes(legacy.acceptedTenantTypes),
    ...(legacy.coordinates
      && typeof legacy.coordinates.lat === 'number'
      && Number.isFinite(legacy.coordinates.lat)
      && typeof legacy.coordinates.lng === 'number'
      && Number.isFinite(legacy.coordinates.lng)
      ? { coordinates: legacy.coordinates as Coordinates }
      : {}),
    tenantRequirement,
    smokingAllowed: typeof legacy.smokingAllowed === 'boolean' ? legacy.smokingAllowed : null,
    petsAllowed: typeof legacy.petsAllowed === 'boolean' ? legacy.petsAllowed : null,
    childrenAllowed: typeof legacy.childrenAllowed === 'boolean' ? legacy.childrenAllowed : null,
    empadronamientoAllowed: typeof legacy.empadronamientoAllowed === 'boolean' ? legacy.empadronamientoAllowed : null,
    restrictions: Array.isArray(legacy.restrictions) ? legacy.restrictions : [],
    amenities: Array.isArray(legacy.amenities) ? legacy.amenities : [],
    description: legacy.description ?? '',
    homeDescription: legacy.homeDescription ?? '',
    images: value.images,
    ...(typeof legacy.video === 'string' && legacy.video ? { video: legacy.video } : {}),
    owner: legacy.owner ?? { name: 'Anunciante', initials: 'AN', since: 'Cuenta local', response: 'Consulta disponibilidad', verified: false },
    advertiserType: legacy.advertiserType ?? 'Particular',
    source: legacy.source,
    isExternal: legacy.isExternal,
    primarySource: legacy.primarySource,
    sourceUrl: legacy.sourceUrl,
    sourcePriceText: legacy.sourcePriceText,
    priceCurrency: legacy.priceCurrency,
    pricePeriod: legacy.pricePeriod,
    priceIsFrom: legacy.priceIsFrom,
    status: legacy.status ?? 'Publicado',
    publishedAt: value.publishedAt,
    views: typeof legacy.views === 'number' ? legacy.views : 0,
    expiresAt: legacy.expiresAt ?? '2099-12-31',
    userCreated: legacy.userCreated,
    ownerUserId: legacy.ownerUserId ?? (legacy.userCreated ? 'host-demo' : undefined),
    contactPhone: legacy.contactPhone,
    contactWhatsapp: legacy.contactWhatsapp ?? legacy.contactPhone,
    contactEmail: legacy.contactEmail,
    showPhone: legacy.showPhone ?? true,
    showWhatsApp: legacy.showWhatsApp ?? true,
    closedReason: legacy.closedReason,
    promoted: Boolean(legacy.promoted),
    promotionEndsAt: typeof legacy.promotionEndsAt === 'string' ? legacy.promotionEndsAt : undefined,
  }
  listing.restrictions = getCriticalRestrictions(listing)
  return expireListing(listing)
}

export function expireListing(listing: Listing): Listing {
  // Repair browser-local rows produced by the retired automatic-expiry policy.
  if (!listing.isExternal && listing.status === 'Finalizado' && listing.closedReason === 'expired') {
    return { ...listing, status: 'Publicado', closedReason: undefined }
  }
  return listing
}

export function isPublicListing(listing: Listing) {
  return expireListing(listing).status === 'Publicado' && rentalPriceAllowed(listing.rentalMode, listing.monthlyPrice ?? listing.price)
}
