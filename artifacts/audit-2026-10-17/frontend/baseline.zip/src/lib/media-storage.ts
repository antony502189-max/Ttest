const DATABASE_NAME = '112233-media'
const DATABASE_VERSION = 1
const STORE_NAME = 'media'
const MEDIA_PREFIX = 'idb-media:'
const DRAFT_KEYS = new Set(['112233:listing-draft:v3', '112233:listing-draft:v2'])
const EDIT_DRAFT_PREFIX = '112233:listing-edit-draft:v1:'

export const acceptedImageTypes = ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'image/heif'] as const
const photoMimeByExtension: Record<string, string> = {
  jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', webp: 'image/webp',
  heic: 'image/heic', heif: 'image/heif',
}

/** Camera uploads occasionally have an empty/octet-stream MIME type. Inspect
 * the filename as a hint; the backend still validates decoded image bytes. */
export function isAcceptedImageFile(file: Pick<File, 'name' | 'type'>) {
  const extension = (file.name || '').split('.').pop()?.toLowerCase() ?? ''
  return acceptedImageTypes.includes(file.type.toLowerCase() as (typeof acceptedImageTypes)[number])
    || Boolean(photoMimeByExtension[extension] && (!file.type || file.type === 'application/octet-stream'))
}

export const MAX_LISTING_SOURCE_IMAGE_BYTES = 50 * 1024 * 1024
export const MAX_LISTING_IMAGE_UPLOAD_BYTES = 8 * 1024 * 1024
const acceptedVideoExtensions = ['.3g2', '.3gp', '.asf', '.avi', '.f4v', '.flv', '.m2ts', '.m4v', '.mkv', '.mov', '.mp4', '.mpeg', '.mpg', '.mts', '.mxf', '.ogv', '.ts', '.vob', '.webm', '.wmv'] as const

export function isAcceptedVideoFile(file: Pick<File, 'name' | 'type'>) {
  const type = (file.type || '').trim().toLowerCase()
  if (type.startsWith('video/')) return true
  const name = (file.name || '').trim().toLowerCase()
  return acceptedVideoExtensions.some((extension) => name.endsWith(extension))
}

export const MIN_LISTING_PHOTOS = 5
export const MAX_LISTING_PHOTOS = 15
export const MAX_LISTING_VIDEO_SECONDS = 60
export const MAX_LISTING_VIDEO_BYTES = 100 * 1024 * 1024

const LOCAL_MEDIA_MAX_DIMENSION = 2048
const LOCAL_MEDIA_WEBP_QUALITY = 0.84

async function optimizeMediaFile(file: File) {
  if (typeof createImageBitmap !== 'function' || typeof document === 'undefined') return file

  let bitmap: ImageBitmap | null = null
  try {
    bitmap = await createImageBitmap(file)
    if (!bitmap.width || !bitmap.height) return file

    const scale = Math.min(1, LOCAL_MEDIA_MAX_DIMENSION / Math.max(bitmap.width, bitmap.height))
    const width = Math.max(1, Math.round(bitmap.width * scale))
    const height = Math.max(1, Math.round(bitmap.height * scale))
    const canvas = document.createElement('canvas')
    canvas.width = width
    canvas.height = height
    const context = canvas.getContext('2d', { alpha: true })
    if (!context) return file
    context.drawImage(bitmap, 0, 0, width, height)

    const blob = await new Promise<Blob | null>((resolve) => {
      canvas.toBlob(resolve, 'image/webp', LOCAL_MEDIA_WEBP_QUALITY)
    })
    if (!blob || !['image/webp', 'image/png', 'image/jpeg'].includes(blob.type)) return file

    // HEIC must be converted, even when conversion slightly increases bytes.
    // For standard JPG/PNG/WebP a larger same-resolution copy is unnecessary.
    const sourceIsHeic = file.type === 'image/heic' || file.type === 'image/heif'
    if (!sourceIsHeic && scale === 1 && blob.size >= file.size) return file
    const baseName = file.name.replace(/\.[^.]+$/, '') || 'listing-image'
    const extension = blob.type === 'image/webp' ? 'webp' : blob.type === 'image/png' ? 'png' : 'jpg'
    return new File([blob], `${baseName}.${extension}`, {
      type: blob.type,
      lastModified: file.lastModified,
    })
  } catch {
    // Browser-side optimization is best effort; backend validation and
    // normalization remains authoritative.
    return file
  } finally {
    bitmap?.close()
  }
}

export class MediaStorageError extends Error {
  readonly code: 'type' | 'read' | 'quota' | 'unavailable'

  constructor(code: 'type' | 'read' | 'quota' | 'unavailable', message: string) {
    super(message)
    this.name = 'MediaStorageError'
    this.code = code
  }
}

let databasePromise: Promise<IDBDatabase> | null = null

function openDatabase() {
  if (databasePromise) return databasePromise
  databasePromise = new Promise<IDBDatabase>((resolve, reject) => {
    if (!('indexedDB' in window)) {
      databasePromise = null
      reject(new MediaStorageError('unavailable', 'El almacenamiento de imágenes no está disponible.'))
      return
    }
    const request = indexedDB.open(DATABASE_NAME, DATABASE_VERSION)
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains(STORE_NAME)) request.result.createObjectStore(STORE_NAME)
    }
    request.onsuccess = () => {
      const database = request.result
      database.onversionchange = () => {
        database.close()
        databasePromise = null
      }
      resolve(database)
    }
    request.onerror = () => {
      databasePromise = null
      reject(request.error ?? new MediaStorageError('unavailable', 'No se pudo abrir el almacenamiento de imágenes.'))
    }
  })
  return databasePromise
}

function mediaId(reference: string) {
  return reference.slice(MEDIA_PREFIX.length)
}

const mediaReference = (id: IDBValidKey) => `${MEDIA_PREFIX}${String(id)}`

export type MediaReference = `${typeof MEDIA_PREFIX}${string}`

export function isMediaReference(value?: string): value is MediaReference {
  return Boolean(value?.startsWith(MEDIA_PREFIX))
}

function collectDraftMediaReferences(value: unknown, found = new Set<string>()) {
  if (typeof value === 'string') {
    if (isMediaReference(value)) found.add(value)
    return found
  }
  if (Array.isArray(value)) value.forEach((item) => collectDraftMediaReferences(item, found))
  else if (value && typeof value === 'object') Object.values(value as Record<string, unknown>).forEach((item) => collectDraftMediaReferences(item, found))
  return found
}

function protectedDraftMediaReferences() {
  const protectedReferences = new Set<string>()
  try {
    for (let index = 0; index < localStorage.length; index += 1) {
      const key = localStorage.key(index)
      if (!key || (!DRAFT_KEYS.has(key) && !key.startsWith(EDIT_DRAFT_PREFIX))) continue
      const raw = localStorage.getItem(key)
      if (!raw) continue
      try {
        collectDraftMediaReferences(JSON.parse(raw), protectedReferences)
      } catch {
        // A malformed draft must not block cleanup of unrelated orphaned media.
      }
    }
  } catch {
    // Storage can be unavailable in hardened/private browser contexts.
  }
  return protectedReferences
}

async function storeMediaBlob(blob: Blob) {
  const id = typeof crypto.randomUUID === 'function' ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`
  try {
    const database = await openDatabase()
    await new Promise<void>((resolve, reject) => {
      const transaction = database.transaction(STORE_NAME, 'readwrite')
      transaction.objectStore(STORE_NAME).put(blob, id)
      transaction.oncomplete = () => resolve()
      transaction.onerror = () => reject(transaction.error)
      transaction.onabort = () => reject(transaction.error)
    })
    return `${MEDIA_PREFIX}${id}`
  } catch (error) {
    if (error instanceof MediaStorageError) throw error
    if (error instanceof DOMException && (error.name === 'QuotaExceededError' || error.name === 'NS_ERROR_DOM_QUOTA_REACHED')) {
      throw new MediaStorageError('quota', 'No hay espacio suficiente para guardar el archivo.')
    }
    // Safari private browsing and restricted browser profiles may throw
    // SecurityError directly from indexedDB.open(), before a transaction.
    if (error instanceof DOMException && (error.name === 'SecurityError' || error.name === 'InvalidStateError')) {
      databasePromise = null
      throw new MediaStorageError('unavailable', 'El almacenamiento local no está disponible en este navegador.')
    }
    throw new MediaStorageError('read', 'No se pudo leer o guardar el archivo.')
  }
}

async function browserVideoDuration(file: File) {
  if (typeof document === 'undefined' || typeof URL === 'undefined' || typeof URL.createObjectURL !== 'function') return null
  return await new Promise<number | null>((resolve) => {
    const video = document.createElement('video')
    const url = URL.createObjectURL(file)
    let settled = false
    const finish = (value: number | null) => {
      if (settled) return
      settled = true
      window.clearTimeout(timer)
      video.removeAttribute('src')
      video.load()
      URL.revokeObjectURL(url)
      resolve(value)
    }
    const timer = window.setTimeout(() => finish(null), 5_000)
    video.preload = 'metadata'
    video.onloadedmetadata = () => finish(Number.isFinite(video.duration) ? video.duration : null)
    video.onerror = () => finish(null)
    video.src = url
  })
}

export async function prepareImageForUpload(file: File): Promise<File> {
  if (!isAcceptedImageFile(file)) {
    throw new MediaStorageError('type', 'Formato no compatible. Usa JPEG, PNG, WebP o HEIC.')
  }
  if (!file.size || file.size > MAX_LISTING_SOURCE_IMAGE_BYTES) {
    throw new MediaStorageError('quota', 'La foto original no puede superar 50 MB.')
  }
  const extension = file.name.split('.').pop()?.toLowerCase() ?? ''
  const mime = acceptedImageTypes.includes(file.type.toLowerCase() as (typeof acceptedImageTypes)[number])
    ? file.type.toLowerCase()
    : photoMimeByExtension[extension]
  const normalized = file.type === mime ? file
    : new File([file], file.name, { type: mime, lastModified: file.lastModified })
  const optimized = await optimizeMediaFile(normalized)
  // HEIC/HEIF requires real browser decoding and conversion, not a MIME rename.
  // Never send HEIC bytes under an image/webp or image/jpeg label.
  if ((mime === 'image/heic' || mime === 'image/heif')
    && !['image/webp', 'image/png', 'image/jpeg'].includes(optimized.type)) {
    throw new MediaStorageError('type', 'No se pudo convertir la foto HEIC. Exporta la foto como JPEG y vuelve a intentarlo.')
  }
  if (!optimized.size || optimized.size > MAX_LISTING_IMAGE_UPLOAD_BYTES) {
    throw new MediaStorageError('quota', 'No se pudo reducir la foto a 8 MB. Prueba con una imagen más pequeña.')
  }
  return optimized
}

export async function saveMediaFile(file: File) {
  return storeMediaBlob(await prepareImageForUpload(file))
}

export async function validateVideoFile(file: File) {
  if (!isAcceptedVideoFile(file)) {
    throw new MediaStorageError('type', 'Selecciona un archivo de vídeo válido.')
  }
  if (!file.size || file.size > MAX_LISTING_VIDEO_BYTES) {
    throw new MediaStorageError('quota', 'El vídeo no puede superar 100 MB.')
  }
  const duration = await browserVideoDuration(file)
  if (duration !== null && duration > MAX_LISTING_VIDEO_SECONDS) {
    throw new MediaStorageError('type', 'El vídeo no puede durar más de 1 minuto.')
  }
}

export async function saveVideoFile(file: File) {
  await validateVideoFile(file)
  return storeMediaBlob(file)
}

export async function getMediaBlob(reference: string) {
  if (!isMediaReference(reference)) return null
  const database = await openDatabase()
  return await new Promise<Blob | null>((resolve, reject) => {
    const request = database.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).get(mediaId(reference))
    request.onsuccess = () => resolve(request.result instanceof Blob ? request.result : null)
    request.onerror = () => reject(request.error)
  })
}

export async function removeMedia(reference: string) {
  if (!isMediaReference(reference)) return
  const database = await openDatabase()
  await new Promise<void>((resolve, reject) => {
    const transaction = database.transaction(STORE_NAME, 'readwrite')
    transaction.objectStore(STORE_NAME).delete(mediaId(reference))
    transaction.oncomplete = () => resolve()
    transaction.onerror = () => reject(transaction.error)
    transaction.onabort = () => reject(transaction.error)
  })
}

export async function removeMediaReferences(references: string[]) {
  const results = await Promise.allSettled([...new Set(references)].map(removeMedia))
  if (results.some((result) => result.status === 'rejected')) {
    throw new MediaStorageError('unavailable', 'No se pudieron limpiar algunas imágenes locales.')
  }
}

export async function getAllMediaReferences() {
  const database = await openDatabase()
  return await new Promise<string[]>((resolve, reject) => {
    const request = database.transaction(STORE_NAME, 'readonly').objectStore(STORE_NAME).getAllKeys()
    request.onsuccess = () => resolve(request.result.map(mediaReference))
    request.onerror = () => reject(request.error)
  })
}

export async function removeUnusedMediaReferences(references: string[], usedReferences: Iterable<string>) {
  const used = new Set<string>([...usedReferences].filter(isMediaReference))
  return removeMediaReferences(references.filter((reference) => isMediaReference(reference) && !used.has(reference)))
}

export async function cleanupOrphanedMedia(usedReferences: Iterable<string>) {
  const used = new Set<string>([...usedReferences].filter(isMediaReference))
  protectedDraftMediaReferences().forEach((reference) => used.add(reference))
  const stored = await getAllMediaReferences()
  await removeUnusedMediaReferences(stored, used)
  return stored.filter((reference) => !used.has(reference))
}
