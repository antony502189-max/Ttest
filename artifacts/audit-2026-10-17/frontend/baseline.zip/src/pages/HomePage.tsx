import { useEffect, useState } from 'react'
import { ChevronRight, Heart, MessageCircle, PawPrint, Plus, ShieldCheck } from 'lucide-react'
import { Link } from 'react-router'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Separator } from '@/components/ui/separator'
import { HomeMandatorySearch } from '@/components/home-mandatory-search'
import { CommercialAdvertisementPlacement } from '@/components/commercial-advertisement-placement'
import { MediaImage } from '@/components/media-image'
import { useHomepageHeroListing } from '@/hooks/use-homepage-hero-listing'
import '@/home.css'

const homeHeroImage = 'https://images.unsplash.com/photo-1560185008-b033106af5c3?auto=format&fit=crop&w=1920&q=88'

export function HomePage() {
  const heroListing = useHomepageHeroListing()
  const [promotionOpen, setPromotionOpen] = useState(false)
  useEffect(() => { setPromotionOpen(false) }, [heroListing?.id])
  const promotedImage = heroListing?.images[0]

  return (
    <div className="home-page market-home">
      <section
        className={heroListing ? 'home-hero home-hero--promotion' : 'home-hero'}
        aria-labelledby={heroListing ? undefined : 'home-title'}
        aria-label={heroListing ? `Anuncio destacado: ${heroListing.title}` : undefined}
      >
        <MediaImage
          src={promotedImage ?? homeHeroImage}
          alt={heroListing ? heroListing.title : 'Habitación luminosa con cama, escritorio y ventana'}
          width="1920"
          height="1080"
          responsive={Boolean(heroListing)}
          sizes="100vw"
          loading="eager"
          fetchPriority="high"
        />
        <div className="home-hero__overlay" />
        {heroListing ? <>
          <button
            type="button"
            className="home-hero-promotion__hit"
            aria-label={`Mostrar anuncio destacado: ${heroListing.title}`}
            aria-expanded={promotionOpen}
            onClick={() => setPromotionOpen(true)}
          />
          {!promotionOpen ? <Link
            className="home-hero-promotion__cta"
            to={`/habitacion/${heroListing.id}`}
            aria-label={`Ver anuncio: ${heroListing.title}`}
          ><span>Ver anuncio</span><ChevronRight aria-hidden="true" /></Link> : null}
          {promotionOpen ? <div className="home-hero-promotion__card">
            <span>Publicidad destacada</span>
            <strong>{heroListing.title}</strong>
            <small>{heroListing.area}, {heroListing.city} · {heroListing.price} € / {heroListing.cadence}</small>
            <Button asChild size="sm"><Link to={`/habitacion/${heroListing.id}`}>Ver anuncio</Link></Button>
          </div> : null}
        </> : <div className="home-hero__content">
          <h1 id="home-title">Solo habitaciones</h1>
          <p>Encuentra una habitación según quién vivirá y sus condiciones.</p>
          <div className="home-hero__chips" aria-label="Condiciones habituales">
            <Badge variant="secondary" className="hero-condition-chip"><PawPrint aria-hidden="true" />Elige tus condiciones</Badge>
          </div>
        </div>}
      </section>

      <section className="home-search-stage" aria-label="Configurar búsqueda de habitaciones">
        <Card className="market-search-panel">
          <CardHeader className="sr-only">
            <CardTitle>Configura tu búsqueda</CardTitle>
            <CardDescription>Selecciona al menos una condición antes de acceder a los anuncios.</CardDescription>
          </CardHeader>
          <CardContent className="market-search-panel__content">
            <HomeMandatorySearch />
          </CardContent>
        </Card>
        <div className="home-trust-strip" aria-label="Ventajas de 112233.es">
          <div><ShieldCheck aria-hidden="true" /><span>Anuncios verificados</span></div>
          <Separator orientation="vertical" />
          <div><Heart aria-hidden="true" /><span>Resultados adaptados</span></div>
          <Separator orientation="vertical" />
          <div><MessageCircle aria-hidden="true" /><span>Contacta sin comisión</span></div>
        </div>
      </section>

      <div className="home-publish-action"><Button asChild variant="outline"><Link to="/publicar"><Plus data-icon="inline-start" />Publicar anuncio</Link></Button></div>
      <CommercialAdvertisementPlacement />
    </div>
  )
}
