import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  Bell,
  CalendarDays,
  ChevronRight,
  Heart,
  List,
  Map,
  ArrowUpDown,
  X,
} from "lucide-react";
import { Link, useSearchParams } from "react-router";
import { Button } from "@/components/ui/button";
import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerFooter, DrawerHeader, DrawerTitle, DrawerTrigger } from "@/components/ui/drawer";
import { Field, FieldLabel } from "@/components/ui/field";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useApp } from "@/contexts/app-context";
import { useAppBack } from "@/hooks/use-app-back";
import { useI18n } from "@/contexts/i18n-context";
import { currentLocale } from "@/lib/i18n-locale";
import { buildListingSearchBody, searchPublicListings, type ListingSearchInput } from "@/api/listings";
import { defaultFilters } from "@/data/listings";
import { hasListingCoordinates, tenantRequirementLabels } from "@/lib/listings";
import { distanceKm } from "@/lib/geolocation";
import { loadTenerifeZoneHierarchy } from "@/lib/map/geojson";
import { getMunicipalityLabel, getRootMunicipalityId, getZoneLabel, isDetailedZoneId, type TenerifeZoneCollection } from "@/lib/map/zones";
import { listingMatchesTenerifeLocation, resolveTenerifeLocation } from "@/lib/tenerife";
import { communityName, listingInCommunity } from "@/lib/spain-communities";
import { ListMapSwitcher } from "@/components/map/list-map-switcher";
import {
  createProgressiveGalleryPage,
  filterListings,
  filtersFromParams,
  filtersToParams,
  pointInPolygon,
  prioritizePromotedListings,
  sortListings,
} from "@/lib/search";
import { filtersForRentalMode } from "@/lib/price-filter-controls";
import { searchGeographyFromParams } from "@/lib/search-geography";
import {
  EmptyState,
  ErrorState,
  FilterButton,
  FilterSidebar,
  LoadingSkeleton,
  LocationSelector,
  MapView,
  Pagination,
  PropertyCard,
  QuickFilters,
  RentalTypeSwitch,
  SearchBar,
  type MapBounds,
} from "@/components/marketplace";
import type { Filters, Listing, MappedListing, MapPolygonPoint, RentalMode } from "@/types";

const PAGE_SIZE = 9;
const EMPTY_MAP_ITEMS: MappedListing[] = [];
const sortOptions = ["Relevancia", "Más recientes", "Más antiguos", "Precio más bajo", "Precio más alto"];
const MOBILE_MAP_MEDIA = "(max-width: 767px), (max-height: 480px) and (max-width: 900px)";
const mockMode = import.meta.env.VITE_ENABLE_MOCK_MODE === '1';
const boundKeys = ['norte', 'sur', 'este', 'oeste'] as const;

function boundsFromParams(params: URLSearchParams): MapBounds | null {
  if (!boundKeys.every((key) => params.has(key))) return null;
  const [north, south, east, west] = boundKeys.map((key) => Number(params.get(key)));
  if (![north, south, east, west].every(Number.isFinite) || north <= south || east <= west ||
    north > 90 || south < -90 || east > 180 || west < -180) return null;
  return { north, south, east, west };
}

function SortControl({ value, onChange }: { value: string; onChange: (value: string) => void }) {
  return <Drawer><DrawerTrigger asChild><Button variant="outline" className="mobile-sort-control"><ArrowUpDown data-icon="inline-start" />Ordenar</Button></DrawerTrigger><DrawerContent className="sort-drawer"><DrawerHeader><DrawerTitle>Ordenar resultados</DrawerTitle><DrawerDescription>Elige cómo quieres ver las habitaciones.</DrawerDescription></DrawerHeader><RadioGroup value={value} onValueChange={onChange} className="sort-options">{sortOptions.map((option) => { const id = `sort-${option.replace(/\s+/g, '-').toLocaleLowerCase()}`; return <Field key={option} orientation="horizontal"><RadioGroupItem id={id} value={option} /><FieldLabel htmlFor={id}>{option}</FieldLabel></Field> })}</RadioGroup><DrawerFooter><DrawerClose asChild><Button>Aplicar orden</Button></DrawerClose></DrawerFooter></DrawerContent></Drawer>
}

export function SearchPage() {
  const { t } = useI18n();
  const goBack = useAppBack('/');
  const [params, setParams] = useSearchParams();
  const paramString = params.toString();
  const requestParams = new URLSearchParams(paramString);
  ['vista', 'pagina', 'cursor', 'panel', 'dibujar', 'mapLat', 'mapLng', 'mapZoom', 'mapAuto'].forEach((key) => requestParams.delete(key));
  const requestParamString = requestParams.toString();
  const {
    rentalMode: storedRentalMode,
    setRentalMode,
    filters: storedFilters,
    setFilters,
    resetFilters,
    query: storedQuery,
    setQuery,
    addSearchHistory,
    saveCurrentSearch,
    activeFilterCount,
    allListings,
    discarded,
    restoreDiscarded,
    mapPolygon,
    setMapPolygon,
  } = useApp();
  const [selected, setSelected] = useState("");
  const [highlighted, setHighlighted] = useState("");
  const [loading, setLoading] = useState(false);
  const [serverItems, setServerItems] = useState<Listing[] | null>(null);
  const [serverTotal, setServerTotal] = useState(0);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [previousCursor, setPreviousCursor] = useState<string | null>(null);
  const [catalogEpoch, setCatalogEpoch] = useState(0);
  const [serverLoading, setServerLoading] = useState(false);
  const [serverError, setServerError] = useState(false);
  const mapBounds = useMemo(() => boundsFromParams(new URLSearchParams(requestParamString)), [requestParamString]);
  const [zoneHierarchy, setZoneHierarchy] = useState<TenerifeZoneCollection | null>(null);
  const [isMobile, setIsMobile] = useState(() => window.matchMedia(MOBILE_MAP_MEDIA).matches);
  const [initialMapAction, setInitialMapAction] = useState<'draw' | 'near' | null>(() => params.get('dibujar') === '1' ? 'draw' : params.get('cerca') === '1' && (!params.has('lat') || !params.has('lng')) ? 'near' : null);
  const actionConsumedRef = useRef(false);
  const view = params.get("vista") === "mapa" ? "map" : "list";
  const page = Math.max(1, Number(params.get("pagina") || 1));
  const pageCursor = params.get('cursor') ?? undefined;
  const requestedQuery = params.get("q")?.trim() || "España";
  const communityId = params.get('comunidad');
  const location = resolveTenerifeLocation(requestedQuery);
  const invalidLocation = false;
  const query = location?.normalizedValue ?? requestedQuery;
  const rentalMode: RentalMode =
    params.get("alquiler") === "holiday" ? "holiday" : "long";
  const filters = useMemo(() => {
    return filtersFromParams(new URLSearchParams(requestParamString));
    // paramString captures the complete serialized filter state.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [requestParamString]);

  useEffect(() => {
    const refresh = () => setCatalogEpoch((current) => current + 1);
    window.addEventListener('catalog:updated', refresh);
    return () => window.removeEventListener('catalog:updated', refresh);
  }, []);

  useEffect(() => {
    if (!invalidLocation) addSearchHistory(query);
  }, [addSearchHistory, invalidLocation, query]);

  useLayoutEffect(() => {
    const canonicalParams = filtersToParams(filters, new URLSearchParams(params));
    canonicalParams.delete("habitaciones");
    if (canonicalParams.toString() !== params.toString()) {
      setParams(canonicalParams, { replace: true });
      return;
    }
    if (query !== storedQuery) setQuery(query);
    if (rentalMode !== storedRentalMode) setRentalMode(rentalMode);
    if (JSON.stringify(filters) !== JSON.stringify(storedFilters))
      setFilters(filters);
    const polygonParam = params.get("poligono");
    if (polygonParam) {
      const points = polygonParam
        .split(";")
        .map((pair) => pair.split(",").map(Number))
        .filter((pair) => pair.length === 2 && pair.every(Number.isFinite))
        .map(([lat, lng]) => ({ lat, lng }));
      if (JSON.stringify(points) !== JSON.stringify(mapPolygon))
        setMapPolygon(points);
    } else if (mapPolygon.length) setMapPolygon([]);
    // Search params are the source of truth for direct URLs and browser navigation.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paramString]);

  useEffect(() => {
    const media = window.matchMedia(MOBILE_MAP_MEDIA);
    const update = () => setIsMobile(media.matches);
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, []);

  useEffect(() => {
    if (!filters.areas.some(isDetailedZoneId)) return;
    let cancelled = false;
    loadTenerifeZoneHierarchy().then((next) => {
      if (!cancelled) setZoneHierarchy(next);
    }).catch(() => {
      if (!cancelled) setZoneHierarchy(null);
    });
    return () => { cancelled = true; };
  }, [filters.areas]);

  useEffect(() => {
    const requestedAction = params.get('dibujar') === '1' ? 'draw' : params.get('cerca') === '1' && (!params.has('lat') || !params.has('lng')) ? 'near' : null;
    if (!requestedAction) return;
    actionConsumedRef.current = false;
    setInitialMapAction(requestedAction);
  }, [paramString, params]);

  useEffect(() => {
    if (!initialMapAction || actionConsumedRef.current) return;
    actionConsumedRef.current = true;
    const next = new URLSearchParams(params);
    next.delete('dibujar');
    next.delete('cerca');
    setParams(next, { replace: true });
  }, [initialMapAction, params, setParams]);

  const searchInput = useMemo<ListingSearchInput>(() => {
    const activeParams = new URLSearchParams(requestParamString);
    const sort = filters.sort === 'Precio más bajo' ? 'price_asc' : filters.sort === 'Precio más alto' ? 'price_desc' : filters.sort === 'Más antiguos' ? 'oldest' : 'newest';
    const roomTypes = (activeParams.get('tiposHabitacion') ?? '').split('|').filter((value): value is Listing['roomType'] =>
      ['Habitación individual', 'Habitación compartida', 'Estudio'].includes(value));
    return {
      rentalMode, ...searchGeographyFromParams(activeParams), roomTypes,
      minPrice: filters.minPrice, maxPrice: filters.maxPrice, filters, sort,
    };
  }, [filters, rentalMode, requestParamString]);
  const mapQuery = useMemo(() => buildListingSearchBody(searchInput), [searchInput]);

  useLayoutEffect(() => {
    if (mockMode) {
      setServerItems(null);
      setServerLoading(false);
      setServerError(false);
      return;
    }
    let cancelled = false;
    const request = new AbortController();
    const isCurrent = () => !cancelled && !request.signal.aborted;
    const galleryPage = createProgressiveGalleryPage(isCurrent, setServerItems);
    setServerLoading(true);
    setServerError(false);
    setServerItems(null);
    void searchPublicListings(searchInput, request.signal, pageCursor, PAGE_SIZE, galleryPage.recover).then((result) => {
      if (!cancelled) {
        const items = galleryPage.accept(result.items);
        setServerItems((current) => isCurrent() ? items : current);
        setServerTotal(result.total);
        setNextCursor(result.nextCursor);
        setPreviousCursor(result.previousCursor);
      }
    }).catch(() => {
      if (!cancelled) {
        setServerItems(mockMode ? null : []);
        setServerError(true);
      }
    }).finally(() => {
      if (!cancelled) setServerLoading(false);
    });
    return () => { cancelled = true; request.abort(); };
  }, [catalogEpoch, pageCursor, searchInput]);

  const filteredItems = useMemo(
    () =>
      mockMode ? filterListings(
        (serverItems ?? (mockMode ? allListings : [])).filter((listing) => !discarded.has(listing.id)),
        rentalMode,
        filters,
        zoneHierarchy,
      ).filter((listing) => !invalidLocation && (searchInput.polygon || searchInput.bounds || searchInput.center
        ? true
        : communityId
          ? listingInCommunity(listing, communityId)
          : ['españa', 'espana', 'spain'].includes(query.toLowerCase()) || listingMatchesTenerifeLocation(listing, location)))
      : (serverItems ?? []).filter((listing) => !discarded.has(listing.id)),
    [allListings, communityId, discarded, filters, invalidLocation, location, query, rentalMode, searchInput, serverItems, zoneHierarchy],
  );
  const spatialItems = useMemo(
    () =>
      mockMode ? filteredItems.filter((listing) => {
        if (searchInput.bounds) {
          const { north, south, east, west } = searchInput.bounds;
          if (!hasListingCoordinates(listing)) return false;
          if (listing.coordinates.lat > north || listing.coordinates.lat < south ||
            listing.coordinates.lng > east || listing.coordinates.lng < west) return false;
        }
        if (searchInput.polygon?.length) {
          if (!hasListingCoordinates(listing) || !pointInPolygon(listing.coordinates,
            searchInput.polygon.map(({ latitude, longitude }) => ({ lat: latitude, lng: longitude })))) return false;
        }
        if (searchInput.center && searchInput.radiusKm) {
          if (!hasListingCoordinates(listing) || distanceKm(listing.coordinates,
            { lat: searchInput.center.latitude, lng: searchInput.center.longitude }) > searchInput.radiusKm) return false;
        }
        return true;
      }) : filteredItems,
    [filteredItems, searchInput],
  );
  const items = useMemo(() => mockMode ? sortListings(spatialItems, filters.sort) : prioritizePromotedListings(spatialItems), [filters.sort, spatialItems]);
  const mappedItems = useMemo(() => items.filter(hasListingCoordinates), [items]);
  const totalPages = Math.max(1, Math.ceil((mockMode ? items.length : serverTotal) / PAGE_SIZE));
  const currentPage = mockMode ? Math.min(page, totalPages) : page;
  const pageItems = mockMode ? items.slice(
    (currentPage - 1) * PAGE_SIZE,
    currentPage * PAGE_SIZE,
  ) : items;
  const resultCount = mockMode ? items.length : serverTotal;
  const forcedState = params.get("estado");
  const formattedDate = filters.available
    ? new Intl.DateTimeFormat(currentLocale(), {
        day: "numeric",
        month: "short",
        year: "numeric",
      }).format(new Date(`${filters.available}T12:00:00`))
    : "Cualquier fecha";

  useEffect(() => {
    if (!mockMode || page <= totalPages) return;
    const next = new URLSearchParams(params);
    next.set("pagina", String(totalPages));
    setParams(next, { replace: true });
  }, [page, params, setParams, totalPages]);

  const updateParams = (
    mutate: (next: URLSearchParams) => void,
    replace = false,
  ) => {
    const next = new URLSearchParams(params);
    mutate(next);
    setParams(next, { replace });
  };
  const commitBounds = (bounds: MapBounds | null) => {
    // A map search button pressed after drawing must not replace the polygon
    // with the broader visible viewport. Show the scoped list on mobile.
    if (bounds && searchGeographyFromParams(params).polygon) {
      if (isMobile) updateParams((next) => {
        next.delete('vista');
        next.delete('pagina');
        next.delete('cursor');
      }, true);
      return;
    }
    if (bounds) {
      setMapPolygon([]);
      if (filters.areas.length) setFilters({ ...filters, areas: [] });
    }
    updateParams((next) => {
      boundKeys.forEach((key) => next.delete(key));
      if (bounds) {
        next.set('q', 'España');
        next.delete('comunidad');
        next.delete('poligono');
        next.delete('zonas');
        next.set('norte', bounds.north.toFixed(5));
        next.set('sur', bounds.south.toFixed(5));
        next.set('este', bounds.east.toFixed(5));
        next.set('oeste', bounds.west.toFixed(5));
      }
      next.delete('pagina');
      next.delete('cursor');
    }, true);
  };
  const commitPolygon = (polygon: MapPolygonPoint[]) => {
    const nextFilters = polygon.length >= 3 && filters.areas.length ? { ...filters, areas: [] } : filters;
    setMapPolygon(polygon);
    if (nextFilters !== filters) setFilters(nextFilters);
    const next = filtersToParams(nextFilters, new URLSearchParams(params));
    next.delete("pagina");
    next.delete('cursor');
    if (polygon.length >= 3) {
      next.set('q', 'España');
      next.delete('comunidad');
      boundKeys.forEach((key) => next.delete(key));
      next.set("poligono", polygon.map((point) => `${point.lat.toFixed(5)},${point.lng.toFixed(5)}`).join(";"));
    }
    else next.delete("poligono");
    setParams(next, { replace: true });
  };
  const commitFilters = (nextFilters: Filters) => {
    setFilters(nextFilters);
    const next = filtersToParams(nextFilters, new URLSearchParams(params));
    next.delete("pagina");
    next.delete('cursor');
    setParams(next);
  };
  const selectLocation = (nextQuery: string) => {
    const nextLocation = resolveTenerifeLocation(nextQuery);
    const selectedQuery = nextLocation?.normalizedValue ?? nextQuery.trim();
    if (!selectedQuery) return;
    const nextFilters = {
      ...filters,
      areas: nextLocation?.type === 'area' || nextLocation?.type === 'district' ? [selectedQuery] : [],
    };
    setQuery(selectedQuery);
    setFilters(nextFilters);
    const next = filtersToParams(nextFilters, new URLSearchParams(params));
    next.set('q', selectedQuery);
    next.delete('comunidad');
    next.delete('poligono');
    boundKeys.forEach((key) => next.delete(key));
    next.delete('pagina');
    next.delete('cursor');
    setMapPolygon([]);
    setParams(next);
  };
  const applyLocationAreas = (selectedAreas: string[]) => {
    const nextFilters = { ...filters, areas: selectedAreas };
    const rootId = selectedAreas.length === 1 ? getRootMunicipalityId(selectedAreas[0], zoneHierarchy) : undefined;
    const nextQuery = rootId ? getMunicipalityLabel(rootId) ?? 'Tenerife' : 'Tenerife';
    setQuery(nextQuery);
    setFilters(nextFilters);
    setParams((current) => {
      const next = filtersToParams(nextFilters, new URLSearchParams(current));
      next.set('q', nextQuery);
      if (selectedAreas.length) {
        next.delete('comunidad');
        next.delete('poligono');
        boundKeys.forEach((key) => next.delete(key));
      }
      next.delete('pagina');
      next.delete('cursor');
      return next;
    });
    if (selectedAreas.length) setMapPolygon([]);
  };
  const changeView = (nextView: "list" | "map") =>
    updateParams((next) =>
      nextView === "map" ? next.set("vista", "mapa") : next.delete("vista"),
    );
  const changeRentalMode = (mode: RentalMode) => {
    const nextFilters = filtersForRentalMode(filters, mode);
    if (nextFilters !== filters) setFilters(nextFilters);
    setParams((current) => {
      const next = filtersToParams(nextFilters, new URLSearchParams(current));
      next.set("alquiler", mode);
      next.delete("pagina");
      next.delete('cursor');
      return next;
    });
  };
  const highlightListing = (id: string) => {
    setHighlighted(id);
    if (id) requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-listing-id="${CSS.escape(id)}"]`)?.scrollIntoView({ block: 'nearest' }));
  };
  const changeSort = (value: string) => {
    setLoading(true);
    // Search params are the source of truth.  Use the updater form so two
    // quick sort changes cannot apply the second value to a stale render.
    setParams((current) => {
      const nextFilters = { ...filtersFromParams(current), sort: value };
      const next = filtersToParams(nextFilters, new URLSearchParams(current));
      next.delete("pagina");
      next.delete('cursor');
      return next;
    });
    window.setTimeout(() => setLoading(false), 180);
  };
  const changePage = (nextPage: number) => {
    if (!mockMode && Math.abs(nextPage - currentPage) !== 1) return;
    const cursor = nextPage > currentPage ? nextCursor : previousCursor;
    if (!mockMode && !cursor) return;
    updateParams((next) => {
      if (nextPage === 1) next.delete('pagina');
      else next.set('pagina', String(nextPage));
      if (cursor) next.set('cursor', cursor);
      else next.delete('cursor');
    });
    document
      .getElementById("results-title")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
  };
  const clearAll = () => {
    resetFilters();
    setMapPolygon([]);
    const next = filtersToParams(defaultFilters, new URLSearchParams(params));
    ["pagina", "cursor", "poligono", "zonas", ...boundKeys].forEach((name) => next.delete(name));
    next.set('q', 'España');
    ['comunidad', 'cerca', 'lat', 'lng', 'radio'].forEach((key) => next.delete(key));
    setParams(next);
  };

  const setOne = <K extends keyof Filters>(key: K, value: Filters[K]) => {
    commitFilters({ ...filters, [key]: value });
  };
  const appliedFilters = useMemo(() => {
    const chips: { key: string; label: string; clear: () => void }[] = [];
    if (filters.areas.length)
      chips.push({
        key: "areas",
        label:
          filters.areas.length === 1
            ? getZoneLabel(filters.areas[0], zoneHierarchy)
            : `${filters.areas.length} zonas`,
        clear: () => setOne("areas", []),
      });
    if (
      filters.minPrice !== defaultFilters.minPrice ||
      filters.maxPrice !== defaultFilters.maxPrice
    )
      chips.push({
        key: "price",
        label: `${filters.minPrice}–${filters.maxPrice} €`,
        clear: () =>
          commitFilters({
            ...filters,
            minPrice: defaultFilters.minPrice,
            maxPrice: defaultFilters.maxPrice,
          }),
      });
    const stringFields: [keyof Filters, string][] = [
      ["roomType", "Habitación"],
      ["available", "Fecha"],
      ["minStay", "Estancia"],
      ["tenantRequirement", "Requisito"],
      ["bathroom", "Baño"],
      ["kitchen", "Cocina"],
      ["deposit", "Fianza"],
      ["shower", "Ducha"],
      ["currentResidents", "Residentes"],
      ["roomCapacity", "Capacidad"],
      ["availableUntil", "Disponible hasta"],
      ["smoking", "Fumar"],
      ["pets", "Mascotas"],
      ["children", "Niños"],
      ["empadronamiento", "Empadronamiento"],
      ["publicationDate", "Publicado"],
      ["advertiserType", "Anunciante"],
    ];
    stringFields.forEach(([key, prefix]) => {
      if (filters[key] !== defaultFilters[key] && filters[key] !== "")
        chips.push({
          key: String(key),
          label: `${prefix}: ${key === "tenantRequirement" && filters.tenantRequirement !== "Cualquiera" ? tenantRequirementLabels[filters.tenantRequirement] : key === "currentResidents" && filters.currentResidents === "5+" ? "5 o más" : key === "roomCapacity" ? `${filters.roomCapacity} ${filters.roomCapacity === "1" ? "persona" : "personas"}` : String(filters[key])}`,
          clear: () => setOne(key, defaultFilters[key]),
        });
    });
    if (filters.roomSizeMin !== defaultFilters.roomSizeMin || filters.roomSizeMax !== defaultFilters.roomSizeMax)
      chips.push({ key: "roomSize", label: `${filters.roomSizeMin}–${filters.roomSizeMax} m²`, clear: () => commitFilters({ ...filters, roomSizeMin: defaultFilters.roomSizeMin, roomSizeMax: defaultFilters.roomSizeMax }) });
    if (filters.minimumNights !== defaultFilters.minimumNights)
      chips.push({ key: "minimumNights", label: `Estancia mínima: hasta ${filters.minimumNights} noches`, clear: () => setOne("minimumNights", defaultFilters.minimumNights) });
    (["furnished", "billsIncluded"] as const).forEach((key) => {
      if (filters[key])
        chips.push({
          key,
          label: key === "furnished" ? "Amueblada" : "Gastos incluidos",
          clear: () => setOne(key, false),
        });
    });
    filters.conditions.forEach((condition) =>
      chips.push({
        key: `condition-${condition}`,
        label: condition,
        clear: () =>
          setOne(
            "conditions",
            filters.conditions.filter((item) => item !== condition),
          ),
      }),
    );
    filters.amenities.forEach((amenity) =>
      chips.push({
        key: `amenity-${amenity}`,
        label: amenity,
        clear: () =>
          setOne(
            "amenities",
            filters.amenities.filter((item) => item !== amenity),
          ),
      }),
    );
    if (mapPolygon.length >= 3)
      chips.push({
        key: "polygon",
        label: "Zona dibujada",
        clear: () => commitPolygon([]),
      });
    if (mapBounds)
      chips.push({
        key: "bounds",
        label: "Área visible del mapa",
        clear: () => commitBounds(null),
      });
    return chips;
    // setOne only closes over the latest filters.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filters, mapBounds, mapPolygon, zoneHierarchy]);

  if (view === 'map' && isMobile) {
    return <div className="mobile-map-screen" aria-label="Mapa de habitaciones en Tenerife">
      <header className="mobile-map-screen__header">
        <Button type="button" variant="ghost" size="icon" onClick={goBack} aria-label="Volver"><ArrowLeft /></Button>
        <LocationSelector selected={filters.areas} currentQuery={`${resultCount} habitaciones, ${query}`} onApply={applyLocationAreas} onLocationSelect={selectLocation} />
        <Button type="button" className="mobile-save-search" onClick={saveCurrentSearch} aria-label="Guardar búsqueda"><Bell /><span>Guardar</span></Button>
      </header>
      <div className="mobile-map-screen__contextbar" aria-label="Acciones de resultados">
        <FilterButton resultCount={resultCount} onFiltersChange={commitFilters} onRentalModeChange={changeRentalMode} />
        <Button type="button" variant="ghost" onClick={() => changeView('list')}><List data-icon="inline-start" />Lista</Button>
      </div>
      <div className="mobile-map-screen__canvas">
        <MapView
          items={mockMode ? mappedItems : EMPTY_MAP_ITEMS}
          serverQuery={mockMode ? undefined : mapQuery}
          selectedId={selected}
          highlightedId={highlighted}
          onSelect={setSelected}
          onHighlight={highlightListing}
          fullScreen
          initialAction={initialMapAction}
          onInitialActionHandled={() => setInitialMapAction(null)}
          fitResultsKey={mapBounds ? 1 : 0}
          onBoundsSearch={commitBounds}
          onPolygonSearch={commitPolygon}
          onDrawingStart={() => {
            if (!filters.areas.length) return true;
            if (!window.confirm(t('Dibujar una zona sustituirá los municipios seleccionados. ¿Continuar?'))) return false;
            return true;
          }}
        />
      </div>
      <div className="mobile-map-screen__footer"><ListMapSwitcher value="map" count={resultCount} onChange={changeView} /></div>
    </div>;
  }

  return (
    <div
      className={
        view === "map"
          ? "search-page idealista-search-page is-map-page"
          : "search-page idealista-search-page"
      }
    >
      <header className="mobile-results-topbar">
        <Button type="button" variant="ghost" size="icon" onClick={goBack} aria-label="Volver"><ArrowLeft /></Button>
        <LocationSelector selected={filters.areas} currentQuery={query} onApply={applyLocationAreas} onLocationSelect={selectLocation} />
        <Button type="button" className="mobile-save-search" onClick={saveCurrentSearch} aria-label="Guardar búsqueda"><Bell /><span>Guardar</span></Button>
      </header>
      <div className="search-toolbar">
        <div className="container">
          <RentalTypeSwitch
            compact
            onChange={changeRentalMode}
          />
          <SearchBar compact />
        </div>
      </div>
      <div className="container search-breadcrumb">
        <Link to="/">Inicio</Link>
        <ChevronRight aria-hidden="true" />
        <span>Habitaciones en {query || "Tenerife"}</span>
      </div>
      <div
        className={
          view === "map"
            ? "container idealista-results-layout is-map-view"
            : "container idealista-results-layout"
        }
      >
        <FilterSidebar
          resultCount={resultCount}
          onFiltersChange={commitFilters}
        />
        <section className="idealista-results" aria-labelledby="results-title">
          {invalidLocation ? <div className="location-search-error" role="alert"><strong>Solo buscamos en Tenerife</strong><span>En esta versión solo puedes buscar habitaciones en Tenerife. Prueba Tenerife, Adeje, Arona, Santa Cruz o La Laguna.</span></div> : null}
          {params.get("alertas") === "1" ? (
            <div className="search-alert-panel">
              <Bell aria-hidden="true" />
              <div>
                <strong>Guarda esta búsqueda</strong>
                <span>Recibe avisos con los filtros y zona actuales.</span>
              </div>
              <Button
                onClick={() => {
                  saveCurrentSearch();
                  updateParams((next) => next.delete("alertas"), true);
                }}
              >
                Guardar
              </Button>
            </div>
          ) : null}
          <header className="results-head idealista-results-head">
            <div>
              <h1 id="results-title">
                {t(`${resultCount} ${resultCount === 1 ? "habitación" : "habitaciones"} en ${communityId ? communityName(communityId) : query || "España"}`)}
              </h1>
              <p>
                <CalendarDays aria-hidden="true" />
                {formattedDate} ·{" "}
                {rentalMode === "long"
                  ? "Larga estancia"
                  : "Alquiler vacacional"}{" "}
                <button
                  type="button"
                  onClick={() =>
                    document
                      .querySelector<HTMLInputElement>(".search-toolbar input")
                      ?.focus()
                  }
                >
                  Modificar
                </button>
              </p>
            </div>
            <Button
              variant="outline"
              className="save-search-button"
              onClick={saveCurrentSearch}
            >
              <Heart data-icon="inline-start" />
              Guardar búsqueda
            </Button>
          </header>
          <QuickFilters
            resultCount={resultCount}
            onFiltersChange={commitFilters}
          />
          {appliedFilters.length ? (
            <div className="applied-filters" aria-label="Filtros aplicados">
              {appliedFilters.map((filter) => (
                <button type="button" key={filter.key} onClick={filter.clear}>
                  {filter.label}
                  <X aria-hidden="true" />
                </button>
              ))}
              <button
                type="button"
                className="applied-filters__clear"
                onClick={clearAll}
              >
                Borrar filtros ({activeFilterCount})
              </button>
            </div>
          ) : null}
          <div className="idealista-results-toolbar">
            <div className="mobile-filter-control">
              <FilterButton resultCount={resultCount} onFiltersChange={commitFilters} onRentalModeChange={changeRentalMode} />
            </div>
            <SortControl value={filters.sort} onChange={changeSort} />
            <label className="desktop-sort-control">
              <span>Ordenar:</span>
              <select
                aria-label="Ordenar resultados"
                value={filters.sort}
                onChange={(event) => changeSort(event.target.value)}
              >
                {sortOptions.map((option) => <option key={option} value={option}>{option}</option>)}
              </select>
            </label>
            <Button
              className="results-map-button"
              variant={view === "map" ? "default" : "outline"}
              onClick={() => changeView(view === "map" ? "list" : "map")}
              aria-pressed={view === "map"}
              aria-label={view === "map" ? "Mostrar lista de habitaciones" : "Mostrar habitaciones en el mapa"}
            >
              {view === "map" ? (
                <List data-icon="inline-start" />
              ) : (
                <Map data-icon="inline-start" />
              )}
              {view === "map" ? "Lista" : "Mapa"}
            </Button>
          </div>
          {view === "map" ? (
            <div className="map-results-split">
              <div
                className="map-results-cards"
                aria-label="Lista sincronizada con el mapa"
              >
                {items.map((listing) => (
                  <PropertyCard
                    key={listing.id}
                    listing={listing}
                    compact
                    selected={selected === listing.id || highlighted === listing.id}
                    onFocus={() => highlightListing(listing.id)}
                  />
                ))}
              </div>
              <div className="idealista-map-view">
                <MapView
                  items={mockMode ? mappedItems : EMPTY_MAP_ITEMS}
                  serverQuery={mockMode ? undefined : mapQuery}
                  selectedId={selected}
                  highlightedId={highlighted}
                  onSelect={setSelected}
                  onHighlight={highlightListing}
                  fullScreen
                  initialAction={initialMapAction}
                  onInitialActionHandled={() => setInitialMapAction(null)}
                  fitResultsKey={mapBounds ? 1 : 0}
                  onBoundsSearch={commitBounds}
                  onPolygonSearch={(polygon: MapPolygonPoint[]) => {
                    commitPolygon(polygon);
                  }}
                  onDrawingStart={() => {
                    if (!filters.areas.length) return true;
                    if (!window.confirm('Dibujar una zona sustituirá los municipios seleccionados. ¿Continuar?')) return false;
                    return true;
                  }}
                />
              </div>
            </div>
          ) : forcedState === "error" || serverError ? (
            <ErrorState />
          ) : loading || serverLoading || forcedState === "loading" ? (
            <LoadingSkeleton />
          ) : forcedState === "empty" || items.length === 0 ? (
            <EmptyState
              onReset={() => {
                clearAll();
                restoreDiscarded();
              }}
            />
          ) : (
            <div className="results-list">
              {pageItems.map((listing) => (
                <PropertyCard
                  key={listing.id}
                  listing={listing}
                  selected={selected === listing.id || highlighted === listing.id}
                  onFocus={() => highlightListing(listing.id)}
                />
              ))}
              <Pagination
                page={currentPage}
                totalPages={totalPages}
                onPage={changePage}
                sequential={!mockMode}
              />
              <section
                className="search-related"
                aria-labelledby="related-title"
              >
                <h2 id="related-title">También puede interesarte</h2>
                <div>
                  <Link to="/registro">Crea tu perfil</Link>
                  <Link to="/buscar?q=Adeje">Habitaciones en Adeje</Link>
                  <Link to="/buscar?q=Arona">Habitaciones en Arona</Link>
                  <Link to="/buscar?q=La%20Laguna">
                    Habitaciones en La Laguna
                  </Link>
                </div>
              </section>
            </div>
          )}
        </section>
      </div>
      <ListMapSwitcher className="mobile-map-toggle" value={view} count={resultCount} onChange={changeView} />
    </div>
  );
}
