import { lazy, Suspense, useEffect, useMemo, useRef, useState, type MutableRefObject, type ReactNode } from 'react'
import { useLocation, useNavigate } from 'react-router'
import {
  Bell,
  BriefcaseBusiness,
  Check,
  ChevronDown,
  ArrowLeft,
  ChevronRight,
  Crosshair,
  Heart,
  Globe2,
  Home,
  Image as ImageIcon,
  Layers3,
  Mail,
  Map,
  Megaphone,
  MapPin,
  Menu,
  PenTool,
  Plus,
  Search,
  Shield,
  SlidersHorizontal,
  Trash2,
  UserRound,
  Users,
  X,
} from 'lucide-react'
import { MediaImage } from '@/components/media-image'
import { cn } from '@/lib/utils'
import { useApp } from '@/contexts/app-context'
import { buildListingSearchBody, getAutonomousCommunityCounts, type AutonomousCommunityCount } from '@/api/listings'
import { useFavoriteListings } from '@/hooks/use-favorite-listings'
import { useRecentlyViewedListings } from '@/hooks/use-recently-viewed-listings'
import { useAdminAccess } from '@/hooks/use-admin-access'
import { useI18n, type Language } from '@/contexts/i18n-context'
import { requestCurrentLocation, type GeolocationFailure } from '@/lib/geolocation'
import { mobileHomeSearchFilters } from '@/lib/mobile-home-filters'
import { useHomepageHeroListing } from '@/hooks/use-homepage-hero-listing'
import { selectMobileSearchListings } from '@/lib/mobile-search'
import { filterListings, filtersFromParams, filtersToParams } from '@/lib/search'
import { searchGeographyFromParams } from '@/lib/search-geography'
import { SPANISH_COMMUNITIES, communityAtCoordinates, communityMapCamera, communityName, communitySuggestions, getCommunity } from '@/lib/spain-communities'
import { preloadAccountPages } from '@/lib/route-preload'
import { useAppBack } from '@/hooks/use-app-back'
import { FIRST_MAP_VIEWPORT, mapViewportFromParams, readLastMapViewport, rememberMapViewport, type MapViewport } from '@/lib/map-visit-history'
import { resolveTenerifeLocation } from '@/lib/tenerife'
import type { Listing } from '@/types'

type OnboardingStep = 'language' | 'country' | 'privacy' | 'auth' | 'done'
type OnboardingOrigin = 'startup' | 'language-settings' | 'region-settings' | 'region-location' | 'account'
type MobileTab = 'home' | 'searches' | 'favorites' | 'menu'
type AppLanguage = Language
type SearchMode = 'vivienda' | 'turismo' | null
type AppPage = 'tabs' | 'location' | 'map'
type MapMode = 'draw' | 'search'
type OccupantOption = 'anyone' | 'man' | 'woman' | 'person' | 'couple' | 'unrestricted'
type MapStatus = 'loading' | 'ready' | 'error'
type LocationStatus = 'idle' | 'loading' | 'success' | GeolocationFailure | 'empty'
type MapPoint = { lat: number; lng: number }
type MapCamera = MapViewport
type DrawingStroke = { pointerId: number; lastX: number; lastY: number; points: MapPoint[] }
type MapInteractionState = {
  gestureHandling: google.maps.MapOptions['gestureHandling']
  draggable: google.maps.MapOptions['draggable']
  scrollwheel: google.maps.MapOptions['scrollwheel']
  disableDoubleClickZoom: google.maps.MapOptions['disableDoubleClickZoom']
  keyboardShortcuts: google.maps.MapOptions['keyboardShortcuts']
}

const ONBOARDING_KEY = '112233:mobile-onboarding:v1'
// Lives for the browser document, not for a React component: navigating to a
// listing unmounts MobileAppV2, but Back should still restore the exact camera.
// A genuine reload/new tab resets this flag and uses the 70 km recall instead.
let mapOpenedInCurrentDocument = false
const mockMode = import.meta.env.VITE_ENABLE_MOCK_MODE === '1'
const MobileMapListingsLayer = lazy(() => import('@/components/mobile-map-listings-layer').then((module) => ({ default: module.MobileMapListingsLayer })))
const CommercialAdvertisementPlacement = lazy(() => import('@/components/commercial-advertisement-placement').then((module) => ({ default: module.CommercialAdvertisementPlacement })))
const MobileServerMapLayer = lazy(() => import('@/components/mobile-map-listings-layer').then((module) => ({ default: module.MobileServerMapLayer })))
const GENERAL_OCCUPANTS = new Set<OccupantOption>(['anyone', 'unrestricted'])

const languages: Array<{ value: AppLanguage; label: string }> = [
  { value: 'es', label: 'Español' },
  { value: 'en', label: 'English' },
  { value: 'ru', label: 'Русский' },
]

const copy = {
  es: {
    languageTitle: 'Selecciona el idioma de la aplicación', continue: 'Continuar', regionTitle: 'Selecciona la región en la que buscas o tienes una vivienda',
    privacyTitle: 'Gracias por instalar nuestra aplicación', privacyText: 'Necesitamos tu permiso para personalizar las funciones disponibles según el uso que hagas del sitio web y de la aplicación.',
    skip: 'Ahora no', authTitle: 'Inicia sesión o regístrate', googleContinue: 'Continuar con Google', emailLogin: 'Iniciar sesión con email',
    legalIntro: 'Consulta la siguiente información:', privacyPolicy: 'Política de privacidad', terms: 'Términos y condiciones',
    housingMode: 'Vivienda', tourismMode: 'Turismo', occupantQuestion: '¿Quién vivirá?', occupantPrefix: 'Para quién:', occupantAnyone: 'cualquiera',
    occupantMan: 'solo un hombre', occupantWoman: 'solo una mujer', occupantPerson: 'una persona', occupantCouple: 'solo pareja', occupantUnrestricted: 'sin restricción', done: 'Listo',
    searchTenerife: 'Seleccionar ubicación actual', search: 'Buscar', publishAd: 'Publicar anuncio', searchesTitle: 'Tus búsquedas', searchesHeading: 'Todas tus búsquedas en un solo lugar',
    searchesText: 'Guarda aquí tus búsquedas habituales para acceder a ellas más fácilmente. También te avisaremos cuando aparezcan nuevos anuncios que coincidan con tus criterios.',
    searchesEmpty: 'Aún no tienes búsquedas guardadas', searchesEmptyText: 'Aplica tus condiciones y guárdalas desde los resultados.',
    favoritesTitle: 'Favoritos y listas', favoritesHeading: 'No tienes viviendas en favoritos', favoritesText: 'Guarda los anuncios que te gusten en tu cuenta para consultarlos desde el teléfono, la tableta o el ordenador.', recentlyViewed: 'Vistos recientemente', clearHistory: 'Borrar historial', historyEmpty: 'Los anuncios que abras aparecerán aquí.',
    login: 'Iniciar sesión', menu: 'Menú', loginDescription: 'Sincroniza tus favoritos y búsquedas en el ordenador, la tableta y el teléfono móvil.',
    yourProperties: 'Ver y crear anuncios', editProfile: 'Editar perfil', propertyManagement: 'Gestión de propiedades', findAgencies: 'Buscar agencias para vender', publishYourAd: 'Publica tu anuncio', settings: 'Ajustes', searchRegion: 'Región de búsqueda',
    language: 'Idioma', appearance: 'Apariencia', appearanceDefault: 'Predeterminada (clara)', about: 'Acerca de la aplicación', version: 'Versión 14.5.0', adminPanel: 'Abrir panel de administración',
    home: 'Inicio', searches: 'Búsquedas', favorites: 'Favoritos',
    mainNavigation: 'Navegación principal', heroAlt: 'Interior de una vivienda', heroAdView: 'Ver anuncio',
    locationTitle: '¿Dónde buscas?', regionSearch: 'Buscar en España', change: 'Cambiar', locationPlaceholder: 'Municipio, zona o dirección', alsoYouCan: 'También puedes',
    drawZone: 'Dibujar tu zona', redrawZone: 'Volver a dibujar', cancelDrawing: 'Cancelar dibujo', clearZone: 'Eliminar zona', drawInstruction: 'Mantén pulsado y dibuja el contorno',
    drawingInstruction: 'Rodea la zona y suelta el dedo', drawTooShort: 'Dibuja una zona más grande con un solo movimiento', areaReady: 'Zona seleccionada',
    searchOnMap: 'Buscar en el mapa', searchNearby: 'Buscar alrededor de ti', searchByPhone: 'Buscar por teléfono', mapDrawTitle: 'Tu propia zona', visibleArea: 'Zona visible', filters: 'Filtros', list: 'Listado',
    phoneIntro: '¿Has visto un cartel de "se vende" o "se alquila"? Introduce los datos para buscarlo', phone: 'Teléfono', operation: 'Operación',
    buy: 'Comprar', rent: 'Alquilar', type: 'Tipo', homes: 'Viviendas', invalidPhone: 'Introduce un teléfono válido', phoneNotFound: 'No hemos encontrado ningún anuncio con ese teléfono.',
    searchArea: 'Buscar en esta zona', save: 'Guardar', saved: 'Guardado', layers: 'Cambiar capas', locate: 'Mi ubicación', mapLoading: 'Cargando mapa…', mapError: 'No se pudo cargar Google Maps',
    locating: 'Buscando tu ubicación…', locationFound: 'Ubicación encontrada', locationDenied: 'No has permitido acceder a tu ubicación', locationUnavailable: 'Tu ubicación no está disponible',
    locationTimeout: 'La búsqueda de ubicación ha tardado demasiado', locationUnsupported: 'Este navegador no ofrece geolocalización', locationOutside: 'Tu ubicación está fuera de España',
    nearbyEmpty: 'No hay anuncios cerca de esta ubicación', back: 'Volver', close: 'Cerrar', clear: 'Borrar búsqueda',
  },
  en: {
    languageTitle: 'Select the app language', continue: 'Continue', regionTitle: 'Select the region where you are looking for or own a property',
    privacyTitle: 'Thank you for installing our app', privacyText: 'We need your permission to personalize the available features based on how you use the website and the app.',
    skip: 'Not now', authTitle: 'Sign in or create an account', googleContinue: 'Continue with Google', emailLogin: 'Sign in with email', legalIntro: 'Review the following information:',
    privacyPolicy: 'Privacy policy', terms: 'Terms and conditions', housingMode: 'Housing', tourismMode: 'Tourism', occupantQuestion: 'Who will live there?', occupantPrefix: 'For:',
    occupantAnyone: 'anyone', occupantMan: 'men only', occupantWoman: 'women only', occupantPerson: 'one person', occupantCouple: 'couples only', occupantUnrestricted: 'no restriction', done: 'Done',
    searchTenerife: 'Choose your location', search: 'Search', publishAd: 'Publish an ad', searchesTitle: 'Your searches', searchesHeading: 'All your searches in one place',
    searchesText: 'Save your frequent searches here for easier access. We will also notify you when new ads match your criteria.', favoritesTitle: 'Favorites and lists',
    searchesEmpty: 'You have no saved searches yet', searchesEmptyText: 'Set your conditions and save them from the results.',
    favoritesHeading: 'You have no favorite properties', favoritesText: 'Save the ads you like to your account and view them on your phone, tablet, or computer.', recentlyViewed: 'Recently viewed', clearHistory: 'Clear history', historyEmpty: 'Listings you open will appear here.',
    login: 'Sign in', menu: 'Menu', loginDescription: 'Sync your favorites and searches across your computer, tablet, and mobile phone.', yourProperties: 'View and create listings', editProfile: 'Edit profile', propertyManagement: 'Property management',
    findAgencies: 'Find agencies to sell', publishYourAd: 'Publish your ad', settings: 'Settings', searchRegion: 'Search region', language: 'Language', appearance: 'Appearance',
    appearanceDefault: 'Default (light)', about: 'About the app', version: 'Version 14.5.0', adminPanel: 'Open administration panel', home: 'Home', searches: 'Searches', favorites: 'Favorites',
    mainNavigation: 'Main navigation', heroAlt: 'Home interior', heroAdView: 'View listing', locationTitle: 'Where are you looking?',
    regionSearch: 'Search in Spain', change: 'Change',
    locationPlaceholder: 'Town, area or address', alsoYouCan: 'You can also', drawZone: 'Draw your own area', redrawZone: 'Draw again', cancelDrawing: 'Cancel drawing',
    clearZone: 'Delete area', drawInstruction: 'Press and draw the area outline', drawingInstruction: 'Draw around the area and release',
    drawTooShort: 'Draw a larger area in one continuous movement', areaReady: 'Area selected', searchOnMap: 'Search on the map', searchNearby: 'Search around you', searchByPhone: 'Search by phone', mapDrawTitle: 'Your own area',
    phoneIntro: 'Have you seen a "for sale" or "for rent" sign? Enter the details to find it', phone: 'Phone', operation: 'Operation',
    buy: 'Buy', rent: 'Rent', type: 'Type', homes: 'Homes', invalidPhone: 'Enter a valid phone number', phoneNotFound: 'We could not find a listing with that phone number.',
    visibleArea: 'Visible area', filters: 'Filters', list: 'List', save: 'Save', saved: 'Saved', layers: 'Change map layers', locate: 'My location', mapLoading: 'Loading map…',
    mapError: 'Google Maps could not be loaded', searchArea: 'Search this area', locating: 'Finding your location…', locationFound: 'Location found', locationDenied: 'Location permission was denied',
    locationUnavailable: 'Your location is unavailable', locationTimeout: 'Finding your location took too long', locationUnsupported: 'This browser does not provide geolocation',
    locationOutside: 'Your location is outside Spain', nearbyEmpty: 'There are no listings near this location', back: 'Back', close: 'Close', clear: 'Clear search',
  },
  ru: {
    languageTitle: 'Выберите язык приложения', continue: 'Продолжить', regionTitle: 'Выберите регион, в котором вы ищете или имеете жильё',
    privacyTitle: 'Спасибо, что установили наше приложение', privacyText: 'Нам нужно ваше разрешение на персонализацию доступных функций в зависимости от использования сайта и приложения.',
    skip: 'Сейчас нет', authTitle: 'Войти в аккаунт или зарегистрироваться', googleContinue: 'Продолжить с Google', emailLogin: 'Войти с помощью email',
    legalIntro: 'Ознакомьтесь со следующей информацией:', privacyPolicy: 'Политика конфиденциальности', terms: 'Общие положения и условия', housingMode: 'Жильё', tourismMode: 'Туризм',
    occupantQuestion: 'Кто будет жить?', occupantPrefix: 'Для кого:', occupantAnyone: 'для любого', occupantMan: 'только мужчина', occupantWoman: 'только женщина',
    occupantPerson: 'один человек', occupantCouple: 'только пара', occupantUnrestricted: 'без ограничений', done: 'Готово', searchTenerife: 'Выберите текущую локацию',
    search: 'Найти', publishAd: 'Разместить объявление', searchesTitle: 'Ваши поиски', searchesHeading: 'Все ваши поиски в одном месте',
    searchesText: 'Сохраняйте здесь частые настройки поиска для большего удобства. Также мы уведомим вас о появлении новых объявлений, совпадающих с вашими критериями.',
    searchesEmpty: 'У вас пока нет сохранённых поисков', searchesEmptyText: 'Выберите условия и сохраните их из результатов.',
    favoritesTitle: 'Избранное и списки', favoritesHeading: 'У вас нет объектов в избранном', favoritesText: 'Сохраните понравившиеся объявления в аккаунте, чтобы просматривать их на телефоне, планшете или компьютере.', recentlyViewed: 'Недавно просмотренные', clearHistory: 'Очистить историю', historyEmpty: 'Открытые вами объявления появятся здесь.',
    login: 'Войти в аккаунт', menu: 'Меню', loginDescription: 'Синхронизируйте избранное и поиски на компьютере, планшете и мобильном телефоне.',
    yourProperties: 'Просмотр и создание объявлений', editProfile: 'Редактировать профиль', propertyManagement: 'Управление объектами', findAgencies: 'Искать агентства для продажи', publishYourAd: 'Опубликовать своё объявление', settings: 'Настройки', searchRegion: 'Регион поиска',
    language: 'Язык', appearance: 'Внешний вид', appearanceDefault: 'По умолчанию (светлый)', about: 'О приложении', version: 'Версия 14.5.0', adminPanel: 'Перейти в админ-панель', home: 'Главная',
    searches: 'Поиски', favorites: 'Избранное', mainNavigation: 'Основная навигация', heroAlt: 'Интерьер жилого помещения', heroAdView: 'Открыть объявление', locationTitle: 'Где вы ищете?',
    regionSearch: 'Поиск по Испании', change: 'Изменить', locationPlaceholder: 'Город, район или адрес', alsoYouCan: 'Также вы можете', drawZone: 'Нарисовать свою зону',
    redrawZone: 'Нарисовать заново', cancelDrawing: 'Отменить рисование', clearZone: 'Удалить зону', drawInstruction: 'Зажмите и нарисуйте контур зоны',
    drawingInstruction: 'Обведите нужную территорию и отпустите', drawTooShort: 'Нарисуйте область побольше одним непрерывным движением', areaReady: 'Зона выбрана',
    searchOnMap: 'Искать на карте', searchNearby: 'Искать рядом с вами', searchByPhone: 'Искать по телефону', mapDrawTitle: 'Ваша собственная зона', visibleArea: 'Видимая зона', filters: 'Фильтры', list: 'Перечень', save: 'Сохранить',
    phoneIntro: 'Вы видели объявление «продаётся» или «сдаётся»? Введите данные, чтобы найти его', phone: 'Телефон', operation: 'Операция',
    buy: 'Купить', rent: 'Снять', type: 'Тип', homes: 'Жильё', invalidPhone: 'Введите корректный номер телефона', phoneNotFound: 'Объявление с таким номером телефона не найдено.',
    saved: 'Сохранено', layers: 'Сменить слой карты', locate: 'Моё местоположение', mapLoading: 'Загрузка карты…', mapError: 'Не удалось загрузить Google Maps',
    searchArea: 'Искать в этой области', locating: 'Определяем местоположение…', locationFound: 'Местоположение найдено', locationDenied: 'Доступ к местоположению отклонён',
    locationUnavailable: 'Местоположение недоступно', locationTimeout: 'Определение местоположения заняло слишком много времени', locationUnsupported: 'Этот браузер не поддерживает геолокацию',
    locationOutside: 'Вы находитесь за пределами Испании', nearbyEmpty: 'Рядом с этим местом объявлений нет', back: 'Назад', close: 'Закрыть', clear: 'Очистить поиск',
  },
} as const

type MobileCopy = Record<keyof typeof copy.es, string>

const favoriteActionCopy: Record<AppLanguage, {
  startDelete: string
  cancel: string
  selectAll: string
  clearSelection: string
  selected: (count: number) => string
  removeSelected: (count: number) => string
  selectListing: (title: string) => string
  deselectListing: (title: string) => string
}> = {
  es: {
    startDelete: 'Seleccionar favoritos para eliminar',
    cancel: 'Cancelar',
    selectAll: 'Seleccionar todo',
    clearSelection: 'Quitar selección',
    selected: (count) => `${count} ${count === 1 ? 'seleccionado' : 'seleccionados'}`,
    removeSelected: (count) => `Eliminar seleccionados (${count})`,
    selectListing: (title) => `Seleccionar ${title} para eliminar`,
    deselectListing: (title) => `Quitar ${title} de la selección`,
  },
  en: {
    startDelete: 'Select favorites to remove',
    cancel: 'Cancel',
    selectAll: 'Select all',
    clearSelection: 'Clear selection',
    selected: (count) => `${count} selected`,
    removeSelected: (count) => `Remove selected (${count})`,
    selectListing: (title) => `Select ${title} for removal`,
    deselectListing: (title) => `Deselect ${title}`,
  },
  ru: {
    startDelete: 'Выбрать избранное для удаления',
    cancel: 'Отмена',
    selectAll: 'Выбрать всё',
    clearSelection: 'Снять выделение',
    selected: (count) => `Выбрано: ${count}`,
    removeSelected: (count) => `Удалить выбранные (${count})`,
    selectListing: (title) => `Выбрать «${title}» для удаления`,
    deselectListing: (title) => `Снять выбор с «${title}»`,
  },
}

const darkMapStyles: google.maps.MapTypeStyle[] = [
  { elementType: 'geometry', stylers: [{ color: '#1e2938' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#1e2938' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#9ba7b6' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d0a36f' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#87a078' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#203b36' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#4f5560' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#2f3440' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#b8a48d' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2a3442' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#142536' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#70879a' }] },
]

function Brand({ compact = false }: { compact?: boolean }) {
  return <div className={cn('m2-brand', compact && 'm2-brand--compact')} aria-label="www.112233.es">www.112233.es</div>
}

function PrimaryButton({ children, onClick, onFocus, onPointerDown, testId, type = 'button' }: { children: ReactNode; onClick?: () => void; onFocus?: () => void; onPointerDown?: () => void; testId?: string; type?: 'button' | 'submit' }) {
  return <button type={type} className="m2-primary" onClick={onClick} onFocus={onFocus} onPointerDown={onPointerDown} data-testid={testId}>{children}</button>
}

function BackHeader({ title, onBack, backLabel }: { title: string; onBack: () => void; backLabel: string }) {
  return <header className="m2-back-header"><button type="button" className="m2-icon-button" onClick={onBack} aria-label={backLabel}><ArrowLeft /></button><strong>{title}</strong><div className="m2-back-header__right" /></header>
}

function AuthPanel({ onContinue, t }: { onContinue: () => void; t: MobileCopy }) {
  return <div className="m2-auth-panel"><Brand /><span>España</span><h1>{t.authTitle}</h1><button type="button" onClick={onContinue}><b>G</b>{t.googleContinue}</button><button type="button" onClick={onContinue}><Mail />{t.emailLogin}</button><p>{t.legalIntro}</p><a href="#/privacidad">{t.privacyPolicy}</a><a href="#/terminos">{t.terms}</a></div>
}

function Onboarding({ step, origin, language, setLanguage, onStep, onCountryContinue, onLanguageContinue, onAuthBack, onDone }: {
  step: OnboardingStep; origin: OnboardingOrigin; language: AppLanguage; setLanguage: (language: AppLanguage) => void; onStep: (step: OnboardingStep) => void
  onCountryContinue: () => void; onLanguageContinue: () => void; onAuthBack: () => void; onDone: () => void
}) {
  const t: MobileCopy = copy[language]
  if (step === 'auth') return <section className="m2-onboarding m2-onboarding--auth"><button type="button" className="m2-auth-back" onClick={onAuthBack} aria-label={t.back}><ArrowLeft /></button><button type="button" className="m2-auth-skip" onClick={onDone}>{t.skip}</button><AuthPanel onContinue={onDone} t={t} /></section>
  return <section className="m2-onboarding"><Brand />
    {step === 'language' ? <><div className="m2-onboarding__content"><h1>{t.languageTitle}</h1><div className="m2-language-list">{languages.map(({ value, label }) => <button key={value} type="button" className={cn(value === language && 'is-selected')} aria-pressed={value === language} onClick={() => setLanguage(value)}><span lang={value}>{label}</span>{value === language ? <Check /> : null}</button>)}</div></div><PrimaryButton onClick={onLanguageContinue}>{t.continue}</PrimaryButton></> : null}
    {step === 'country' ? <><div className="m2-onboarding__content"><h1>{t.regionTitle}</h1><button type="button" className="m2-country is-selected" aria-pressed="true"><span>ES</span><strong>España</strong><Check /></button></div><PrimaryButton onClick={onCountryContinue}>{t.continue}</PrimaryButton></> : null}
    {step === 'privacy' ? <><div className="m2-onboarding__content m2-privacy"><h1>{t.privacyTitle}</h1><p>{t.privacyText}</p><a className="m2-privacy__policy" href="#/privacidad">{t.privacyPolicy}</a></div><PrimaryButton onClick={() => onStep('auth')}>{t.continue}</PrimaryButton></> : null}
    <span className="m2-sr-only">{origin}</span>
  </section>
}

function getOccupantOptions(t: MobileCopy): Array<{ value: OccupantOption; label: string }> {
  return [{ value: 'anyone', label: t.occupantAnyone }, { value: 'man', label: t.occupantMan }, { value: 'woman', label: t.occupantWoman }, { value: 'person', label: t.occupantPerson }, { value: 'couple', label: t.occupantCouple }, { value: 'unrestricted', label: t.occupantUnrestricted }]
}

function OccupantSelector({ t }: { t: MobileCopy }) {
  const [open, setOpen] = useState(false)
  const [selected, setSelected] = useState<OccupantOption[]>(['anyone'])
  const options = getOccupantOptions(t)
  const summary = useMemo(() => `${t.occupantPrefix} ${options.filter((option) => selected.includes(option.value)).map((option) => option.label).join(', ')}`, [options, selected, t.occupantPrefix])
  useEffect(() => {
    if (!open) return
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const closeOnEscape = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false) }
    document.addEventListener('keydown', closeOnEscape)
    return () => { document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', closeOnEscape) }
  }, [open])
  const toggle = (value: OccupantOption) => {
    if (GENERAL_OCCUPANTS.has(value)) { setSelected([value]); return }
    setSelected((current) => {
      const specific = current.filter((item) => !GENERAL_OCCUPANTS.has(item))
      const next = specific.includes(value) ? specific.filter((item) => item !== value) : [...specific, value]
      return next.length ? next : ['anyone']
    })
  }
  return <><button type="button" className="m2-occupant-trigger" onClick={() => setOpen(true)} aria-haspopup="dialog" aria-expanded={open} aria-label={`${t.occupantQuestion} ${summary}`}><Users /><span><small>{t.occupantQuestion}</small><strong>{summary}</strong></span><ChevronDown /></button>
    {open ? <div className="m2-sheet-backdrop" onClick={() => setOpen(false)}><section className="m2-sheet" role="dialog" aria-modal="true" aria-label={t.occupantQuestion} onClick={(event) => event.stopPropagation()}><header><strong>{t.occupantQuestion}</strong><button type="button" onClick={() => setOpen(false)} aria-label={t.close}><X /></button></header><div className="m2-check-list" role="group" aria-label={t.occupantQuestion}>{options.map((option) => { const checked = selected.includes(option.value); return <button key={option.value} type="button" role="checkbox" aria-checked={checked} className={cn(checked && 'is-selected')} onClick={() => toggle(option.value)}><span>{t.occupantPrefix} {option.label}</span><i>{checked ? <Check /> : null}</i></button> })}</div><PrimaryButton onClick={() => setOpen(false)}>{t.done}</PrimaryButton></section></div> : null}
  </>
}

function HomeScreen({ t, mode, onMode, onLocation, onSearch, onSearchIntent, onPublish, selectedCommunity, language }: { t: MobileCopy; mode: SearchMode; onMode: (mode: Exclude<SearchMode, null>) => void; onLocation: () => void; onSearch: () => void; onSearchIntent: () => void; onPublish: () => void; selectedCommunity: string | null; language: AppLanguage }) {
  const heroListing = useHomepageHeroListing()
  const navigate = useNavigate()
  const [heroAdOpen, setHeroAdOpen] = useState(false)
  useEffect(() => { setHeroAdOpen(false) }, [heroListing?.id])
  return <section className="m2-screen m2-home"><header className="m2-topbar"><Brand compact /></header><div className={cn('m2-hero', heroListing && 'm2-hero--promotion')} role="img" aria-label={heroListing?.title ?? t.heroAlt}>{heroListing ? <><MediaImage className="m2-hero__promotion-image" src={heroListing.images[0]} responsive sizes="100vw" alt="" loading="eager" fetchPriority="high" /><button type="button" className="m2-hero-ad__reveal" aria-label={`${t.heroAdView}: ${heroListing.title}`} aria-expanded={heroAdOpen} onClick={() => setHeroAdOpen(true)} />{!heroAdOpen ? <button type="button" className="m2-hero-ad__cta" aria-label={`${t.heroAdView}: ${heroListing.title}`} onClick={() => navigate(`/habitacion/${heroListing.id}`)}><span>{t.heroAdView}</span><ChevronRight aria-hidden="true" /></button> : null}{heroAdOpen ? <div className="m2-hero-ad__card"><span>112233.es</span><strong>{heroListing.title}</strong><small>{heroListing.area} · {heroListing.price} € / {heroListing.cadence}</small><button type="button" onClick={() => navigate(`/habitacion/${heroListing.id}`)}>{t.heroAdView}</button></div> : null}</> : null}</div><div className="m2-search-card"><div className="m2-mode-switch" role="group" aria-label={`${t.housingMode} / ${t.tourismMode}`}><button type="button" className={cn(mode === 'vivienda' && 'is-active')} onClick={() => onMode('vivienda')} aria-label={t.housingMode} aria-pressed={mode === 'vivienda'}><span className="m2-mode-icon m2-mode-icon--home"><Home /></span><span>{t.housingMode}</span></button><button type="button" className={cn(mode === 'turismo' && 'is-active')} onClick={() => onMode('turismo')} aria-label={t.tourismMode} aria-pressed={mode === 'turismo'}><span className="m2-mode-icon m2-mode-icon--tourism"><BriefcaseBusiness /></span><span>{t.tourismMode}</span></button></div><OccupantSelector t={t} /><button type="button" className="m2-select-row" onClick={onLocation}><span>{selectedCommunity ? communityName(selectedCommunity, language) : t.searchTenerife}</span><MapPin /></button><PrimaryButton onFocus={onSearchIntent} onPointerDown={onSearchIntent} onClick={onSearch} testId="open-location"><Search />{t.search}</PrimaryButton><button type="button" className="m2-outline" onClick={onPublish}>{t.publishAd}</button></div><Suspense fallback={null}><CommercialAdvertisementPlacement mobile /></Suspense></section>
}

function locationStatusMessage(t: MobileCopy, status: LocationStatus) {
  if (status === 'loading') return t.locating
  if (status === 'success') return t.locationFound
  if (status === 'denied') return t.locationDenied
  if (status === 'unavailable') return t.locationUnavailable
  if (status === 'timeout') return t.locationTimeout
  if (status === 'unsupported') return t.locationUnsupported
  if (status === 'outside') return t.locationOutside
  if (status === 'empty') return t.nearbyEmpty
  return ''
}

function LocationScreen({ t, language, rentalMode, onBack, onMap, onNearby, onRegionSelect, nearbyStatus }: {
  t: MobileCopy
  language: AppLanguage
  rentalMode: 'long' | 'holiday'
  onBack: () => void
  onMap: (mode: MapMode, query?: string) => void
  onNearby: () => void
  onRegionSelect: (id: string) => void
  nearbyStatus: LocationStatus
}) {
  const { allListings, discarded, filters } = useApp()
  const [query, setQuery] = useState('')
  const [expanded, setExpanded] = useState(false)
  const [counts, setCounts] = useState<AutonomousCommunityCount[]>([])
  const [countError, setCountError] = useState(false)
  const currentFilters = useMemo(() => mobileHomeSearchFilters(filters, rentalMode), [filters, rentalMode])
  useEffect(() => {
    if (mockMode) {
      const eligible = filterListings(allListings.filter((listing) => !discarded.has(listing.id)), rentalMode, currentFilters)
      // Resolve each point only once. Re-running point-in-polygon for every
      // community would make the inline suggestions noticeably slow on mobile.
      const grouped = new globalThis.Map<string, { count: number; cities: Set<string> }>(
        SPANISH_COMMUNITIES.map((region): [string, { count: number; cities: Set<string> }] =>
          [region.id, { count: 0, cities: new Set<string>() }]),
      )
      for (const listing of eligible) {
        if (!listing.coordinates) continue
        const id = communityAtCoordinates(listing.coordinates.lat, listing.coordinates.lng)?.id
        const aggregate = id ? grouped.get(id) : undefined
        if (!aggregate) continue
        aggregate.count += 1
        if (listing.city) aggregate.cities.add(listing.city)
      }
      setCounts(SPANISH_COMMUNITIES.map((region) => ({
        id: region.id, count: grouped.get(region.id)?.count ?? 0,
        cities: [...(grouped.get(region.id)?.cities ?? [])],
      })))
      return
    }
    const controller = new AbortController()
    setCountError(false)
    setCounts([])
    void getAutonomousCommunityCounts({
      rentalMode, filters: currentFilters,
      minPrice: currentFilters.minPrice, maxPrice: currentFilters.maxPrice,
      query: 'España',
    }, controller.signal).then((next) => {
      if (!controller.signal.aborted) setCounts(next)
    }).catch(() => { if (!controller.signal.aborted) setCountError(true) })
    return () => controller.abort()
  }, [allListings, discarded, currentFilters, rentalMode])
  const cities = useMemo(() => Object.fromEntries(counts.map((entry) => [entry.id, entry.cities])), [counts])
  const suggestions = useMemo(() => communitySuggestions(query, cities), [query, cities])
  const selected = (id: string) => { setExpanded(false); onRegionSelect(id) }
  const submit = (event: React.FormEvent) => {
    event.preventDefault()
    if (suggestions[0]) selected(suggestions[0].id)
    else setExpanded(true)
  }
  const statusMessage = locationStatusMessage(t, nearbyStatus)
  const listingsWord = language === 'ru' ? 'объявлений' : language === 'en' ? 'listings' : 'anuncios'
  return <section className="m2-screen m2-location" data-testid="location-screen">
    <BackHeader title={t.locationTitle} onBack={onBack} backLabel={t.back} />
    <div className="m2-location__body">
      <form className="m2-location-search" onSubmit={submit}>
        <Search aria-hidden="true" />
        <input value={query} onFocus={() => setExpanded(true)}
          onChange={(event) => { setQuery(event.target.value); setExpanded(true) }}
          type="search" placeholder={t.locationPlaceholder} aria-label={t.locationPlaceholder}
          autoComplete="off" data-testid="community-search-input" />
        {query ? <button type="button" className="m2-location-clear" onClick={() => { setQuery(''); setExpanded(true) }} aria-label={t.clear}><X /></button> : null}
      </form>
      {expanded ? <div className="m2-community-suggestions" data-testid="community-suggestions" aria-live="polite">
        {suggestions.length ? suggestions.map((region) => {
          const entry = counts.find((item) => item.id === region.id)
          return <button type="button" className="m2-community-option" key={region.id}
            onClick={() => selected(region.id)} data-testid={`community-option-${region.id}`}>
            <span><strong>{region[language]}</strong>
              <small>{({ es: 'Comunidad autónoma', en: 'Autonomous community', ru: 'Автономное сообщество' })[language]}</small>
            </span>
            <span className="m2-community-option__count">{countError ? '—' : entry ? entry.count.toLocaleString(language === 'ru' ? 'ru-RU' : 'es-ES') : '…'} {listingsWord}</span>
            <ChevronRight />
          </button>
        }) : <p className="m2-community-empty">{({ es: 'No se encontró ninguna comunidad', en: 'No matching region', ru: 'Область не найдена' })[language]}</p>}
      </div> : <><h2>{t.alsoYouCan}</h2>
        <button type="button" className="m2-location-action" onClick={() => onMap('draw')} data-testid="draw-zone"><span><PenTool /></span><strong>{t.drawZone}</strong><ChevronRight /></button>
        <button type="button" className="m2-location-action" onClick={() => onMap('search')} data-testid="search-map"><span><Map /></span><strong>{t.searchOnMap}</strong><ChevronRight /></button>
        <button type="button" className="m2-location-action" onClick={onNearby} disabled={nearbyStatus === 'loading'} data-testid="search-nearby"><span><Crosshair /></span><strong>{t.searchNearby}</strong><ChevronRight /></button>
      </>}
      {statusMessage ? <p className={cn('m2-location-feedback', !['loading', 'success'].includes(nearbyStatus) && 'is-error')} role={nearbyStatus === 'loading' ? 'status' : 'alert'}>{statusMessage}</p> : null}
    </div>
  </section>
}

function GoogleMapCanvas({ t, mapRef, query, initialCenter, initialCamera, onStatus, onCameraChange }: { t: MobileCopy; mapRef: MutableRefObject<google.maps.Map | null>; query: string; initialCenter?: MapPoint; initialCamera?: MapCamera; onStatus: (status: MapStatus) => void; onCameraChange: (camera: MapCamera, interacted?: boolean) => void }) {
  const containerRef = useRef<HTMLDivElement>(null)
  const [status, setStatus] = useState<MapStatus>('loading')
  const startingView = useRef({ query, initialCenter, initialCamera })
  const cameraChange = useRef(onCameraChange)
  cameraChange.current = onCameraChange
  useEffect(() => {
    let cancelled = false
    let removeInteractionListeners = () => {}
    const initialize = async () => {
      try {
        const { googleMapsConfig, loadGoogleMaps } = await import('@/lib/google-maps/loader')
        const { maps } = await loadGoogleMaps()
        const GoogleMap = maps.Map
        if (cancelled || !containerRef.current) return
        const mapId = googleMapsConfig.mapId
        const { initialCenter: center, initialCamera: camera } = startingView.current
        const map = new GoogleMap(containerRef.current, { center: camera ?? center ?? FIRST_MAP_VIEWPORT, zoom: camera?.zoom ?? (center ? 14 : FIRST_MAP_VIEWPORT.zoom), mapId: mapId || undefined, styles: mapId ? undefined : darkMapStyles, disableDefaultUI: true, gestureHandling: 'greedy', clickableIcons: false, backgroundColor: '#142536', minZoom: 2, maxZoom: 19 })
        const startingCenter = camera ?? center ?? FIRST_MAP_VIEWPORT
        // Apply the camera to the map instance as well as its UI metadata.
        // The lightweight test Maps SDK does not honor constructor options.
        map.setCenter({ lat: startingCenter.lat, lng: startingCenter.lng })
        map.setZoom(camera?.zoom ?? (center ? 14 : FIRST_MAP_VIEWPORT.zoom))
        mapRef.current = map
        let userHasExploredMap = false
        const persistExploredCamera = () => {
          if (!userHasExploredMap) return
          const point = map.getCenter()
          const zoom = map.getZoom()
          if (point && zoom !== undefined) rememberMapViewport({ lat: point.lat(), lng: point.lng(), zoom })
        }
        const onVisibilityChange = () => {
          if (document.visibilityState === 'hidden') persistExploredCamera()
        }
        window.addEventListener('pagehide', persistExploredCamera)
        document.addEventListener('visibilitychange', onVisibilityChange)
        const markUserInteraction = () => { userHasExploredMap = true }
        const canvas = containerRef.current
        canvas.addEventListener('pointerdown', markUserInteraction, { passive: true })
        canvas.addEventListener('wheel', markUserInteraction, { passive: true })
        canvas.addEventListener('keydown', markUserInteraction)
        const dragListener = map.addListener('dragstart', markUserInteraction)
        removeInteractionListeners = () => {
          canvas.removeEventListener('pointerdown', markUserInteraction)
          canvas.removeEventListener('wheel', markUserInteraction)
          canvas.removeEventListener('keydown', markUserInteraction)
          dragListener.remove()
          window.removeEventListener('pagehide', persistExploredCamera)
          document.removeEventListener('visibilitychange', onVisibilityChange)
          persistExploredCamera()
        }
        if (camera) {
          map.getDiv().dataset.mapCenter = `${camera.lat.toFixed(6)},${camera.lng.toFixed(6)}`
          map.getDiv().dataset.mapZoom = String(camera.zoom)
          cameraChange.current(camera)
        }
        map.addListener('idle', () => {
          if (cancelled) return
          const point = map.getCenter()
          const zoom = map.getZoom()
          if (!point || zoom === undefined) return
          map.getDiv().dataset.mapCenter = `${point.lat().toFixed(6)},${point.lng().toFixed(6)}`
          map.getDiv().dataset.mapZoom = String(zoom)
          cameraChange.current({ lat: point.lat(), lng: point.lng(), zoom }, userHasExploredMap)
        })
        google.maps.event.addListenerOnce(map, 'tilesloaded', () => { if (!cancelled) { setStatus('ready'); onStatus('ready') } })
      } catch (error) {
        console.error('Google Maps initialization failed', error)
        if (!cancelled) { setStatus('error'); onStatus('error') }
      }
    }
    setStatus('loading'); onStatus('loading'); void initialize()
    return () => { cancelled = true; removeInteractionListeners(); mapRef.current = null }
  }, [mapRef, onStatus])
  return <div className="m2-map-canvas-wrap"><div ref={containerRef} className="m2-map-canvas" data-testid="google-map" />{status === 'loading' ? <div className="m2-map-status" role="status">{t.mapLoading}</div> : null}{status === 'error' ? <div className="m2-map-status m2-map-status--error" role="alert">{t.mapError}</div> : null}</div>
}

function captureMapInteractions(map: google.maps.Map): MapInteractionState {
  return {
    gestureHandling: map.get('gestureHandling') as MapInteractionState['gestureHandling'],
    draggable: map.get('draggable') as MapInteractionState['draggable'],
    scrollwheel: map.get('scrollwheel') as MapInteractionState['scrollwheel'],
    disableDoubleClickZoom: map.get('disableDoubleClickZoom') as MapInteractionState['disableDoubleClickZoom'],
    keyboardShortcuts: map.get('keyboardShortcuts') as MapInteractionState['keyboardShortcuts'],
  }
}

function mapPointFromPointer(map: google.maps.Map, clientX: number, clientY: number): MapPoint | null {
  const projection = map.getProjection()
  const center = map.getCenter()
  const zoom = map.getZoom()
  if (!projection || !center || zoom === undefined) return null
  const centerPoint = projection.fromLatLngToPoint(center)
  if (!centerPoint) return null
  const bounds = map.getDiv().getBoundingClientRect()
  const scale = 2 ** zoom
  const worldPoint = new google.maps.Point(centerPoint.x + (clientX - bounds.left - bounds.width / 2) / scale, centerPoint.y + (clientY - bounds.top - bounds.height / 2) / scale)
  const latLng = projection.fromPointToLatLng(worldPoint, true)
  return latLng ? { lat: latLng.lat(), lng: latLng.lng() } : null
}

function pointLineDistance(point: MapPoint, start: MapPoint, end: MapPoint) {
  const dx = end.lng - start.lng
  const dy = end.lat - start.lat
  if (dx === 0 && dy === 0) return Math.hypot(point.lng - start.lng, point.lat - start.lat)
  const ratio = Math.max(0, Math.min(1, ((point.lng - start.lng) * dx + (point.lat - start.lat) * dy) / (dx * dx + dy * dy)))
  return Math.hypot(point.lng - (start.lng + ratio * dx), point.lat - (start.lat + ratio * dy))
}

function simplifyMapPath(points: MapPoint[], tolerance = 0.00018): MapPoint[] {
  if (points.length <= 3) return points
  let maxDistance = 0
  let splitIndex = 0
  for (let index = 1; index < points.length - 1; index += 1) {
    const distance = pointLineDistance(points[index], points[0], points[points.length - 1])
    if (distance > maxDistance) { maxDistance = distance; splitIndex = index }
  }
  if (maxDistance <= tolerance) return [points[0], points[points.length - 1]]
  const left = simplifyMapPath(points.slice(0, splitIndex + 1), tolerance)
  const right = simplifyMapPath(points.slice(splitIndex), tolerance)
  return [...left.slice(0, -1), ...right]
}

function FreehandAreaLayer({ mapRef, mapReady, active, setActive, polygon, onPolygonChange, t }: {
  mapRef: MutableRefObject<google.maps.Map | null>; mapReady: boolean; active: boolean; setActive: (active: boolean) => void
  polygon: MapPoint[]; onPolygonChange: (polygon: MapPoint[]) => void; t: MobileCopy
}) {
  const layerRef = useRef<google.maps.Polygon | google.maps.Polyline | null>(null)
  const interactionRef = useRef<MapInteractionState | null>(null)
  const strokeRef = useRef<DrawingStroke | null>(null)
  const [draft, setDraft] = useState<MapPoint[]>([])
  const [hint, setHint] = useState(t.drawInstruction)

  useEffect(() => { setHint(t.drawInstruction) }, [t.drawInstruction])

  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady) return
    layerRef.current?.setMap(null)
    const points = draft.length >= 2 ? draft : polygon
    if (points.length >= 3) {
      layerRef.current = new google.maps.Polygon({ map, paths: points, clickable: false, strokeColor: '#d2ff3f', strokeOpacity: 1, strokeWeight: 3, fillColor: '#d2ff3f', fillOpacity: .22, zIndex: 20 })
    } else if (points.length === 2) {
      layerRef.current = new google.maps.Polyline({ map, path: points, clickable: false, strokeColor: '#d2ff3f', strokeOpacity: 1, strokeWeight: 3, zIndex: 20 })
    }
    return () => { layerRef.current?.setMap(null); layerRef.current = null }
  }, [draft, mapReady, mapRef, polygon])

  useEffect(() => {
    const map = mapRef.current
    if (!map || !mapReady || !active) return
    interactionRef.current = captureMapInteractions(map)
    map.setOptions({ gestureHandling: 'none', draggable: false, scrollwheel: false, disableDoubleClickZoom: true, keyboardShortcuts: false })
    setDraft([])
    setHint(t.drawInstruction)
    return () => {
      if (interactionRef.current) map.setOptions(interactionRef.current)
      interactionRef.current = null
      strokeRef.current = null
    }
  }, [active, mapReady, mapRef, t.drawInstruction])

  const appendPointerPoint = (stroke: DrawingStroke, clientX: number, clientY: number) => {
    const map = mapRef.current
    if (!map) return false
    const point = mapPointFromPointer(map, clientX, clientY)
    if (!point) return false
    stroke.lastX = clientX
    stroke.lastY = clientY
    stroke.points.push(point)
    setDraft([...stroke.points])
    return true
  }

  const pointerDown = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!event.isPrimary || (event.pointerType === 'mouse' && event.button !== 0)) return
    event.preventDefault()
    event.stopPropagation()
    event.currentTarget.setPointerCapture(event.pointerId)
    setHint(t.drawingInstruction)
    const stroke: DrawingStroke = { pointerId: event.pointerId, lastX: event.clientX, lastY: event.clientY, points: [] }
    strokeRef.current = stroke
    appendPointerPoint(stroke, event.clientX, event.clientY)
  }

  const pointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    const stroke = strokeRef.current
    if (!stroke || event.pointerId !== stroke.pointerId) return
    event.preventDefault()
    event.stopPropagation()
    const samples = event.nativeEvent.getCoalescedEvents?.() ?? [event.nativeEvent]
    const minimumDistance = event.pointerType === 'touch' ? 7 : 5
    samples.forEach((sample) => {
      const distance = Math.hypot(sample.clientX - stroke.lastX, sample.clientY - stroke.lastY)
      if (distance >= minimumDistance) appendPointerPoint(stroke, sample.clientX, sample.clientY)
    })
  }

  const finishStroke = (event: React.PointerEvent<HTMLDivElement>) => {
    const stroke = strokeRef.current
    if (!stroke || event.pointerId !== stroke.pointerId) return
    event.preventDefault()
    event.stopPropagation()
    const distance = Math.hypot(event.clientX - stroke.lastX, event.clientY - stroke.lastY)
    if (distance >= 3) appendPointerPoint(stroke, event.clientX, event.clientY)
    try { event.currentTarget.releasePointerCapture(event.pointerId) } catch { /* capture may already be released */ }
    strokeRef.current = null
    const simplified = simplifyMapPath(stroke.points)
    if (simplified.length < 3) {
      setDraft([])
      setHint(t.drawTooShort)
      return
    }
    const limited = simplified.length > 80 ? simplified.filter((_, index) => index % Math.ceil(simplified.length / 80) === 0) : simplified
    setDraft([])
    onPolygonChange(limited)
    setHint(t.areaReady)
    setActive(false)
  }

  const cancelStroke = (event: React.PointerEvent<HTMLDivElement>) => {
    if (strokeRef.current?.pointerId !== event.pointerId) return
    strokeRef.current = null
    setDraft([])
    setHint(t.drawInstruction)
  }

  if (!active) return null
  return <div className="m2-freehand-overlay" data-testid="freehand-overlay" role="application" aria-label={t.drawInstruction} onPointerDown={pointerDown} onPointerMove={pointerMove} onPointerUp={finishStroke} onPointerCancel={cancelStroke} onContextMenu={(event) => event.preventDefault()}><span>{hint}</span></div>
}

function MapScreen({ mode, language, t, query, initialCenter, initialCamera, polygon, items, serverQuery, onPolygonChange, onCameraChange, onBack, onSave, onList, onFilters, onSearchArea }: {
  mode: MapMode; language: AppLanguage; t: MobileCopy; query: string; initialCenter?: MapPoint; initialCamera?: MapCamera; polygon: MapPoint[]; items: Listing[]; serverQuery?: Record<string, unknown>; onPolygonChange: (polygon: MapPoint[]) => void; onCameraChange: (camera: MapCamera, interacted?: boolean) => void; onBack: () => void; onSave?: () => void; onList?: () => void; onFilters?: () => void; onSearchArea?: () => void
}) {
  const mapRef = useRef<google.maps.Map | null>(null)
  const preserveInitialCamera = useRef(Boolean(initialCamera))
  const userMarkerRef = useRef<google.maps.marker.AdvancedMarkerElement | null>(null)
  const [mapType, setMapType] = useState<'roadmap' | 'hybrid'>('roadmap')
  const [saved, setSaved] = useState(false)
  const [mapStatus, setMapStatus] = useState<MapStatus>('loading')
  const [locationStatus, setLocationStatus] = useState<LocationStatus>('idle')
  const [drawing, setDrawing] = useState(false)
  const toggleLayers = () => { const next = mapType === 'roadmap' ? 'hybrid' : 'roadmap'; setMapType(next); mapRef.current?.setMapTypeId(next) }
  const showUserMarker = async (coordinates: MapPoint) => {
    const { loadGoogleMaps } = await import('@/lib/google-maps/loader')
    await loadGoogleMaps()
    if (!mapRef.current) return
    if (!userMarkerRef.current) {
      const content = document.createElement('span')
      content.className = 'm2-user-location-marker'
      content.setAttribute('aria-label', t.locationFound)
      userMarkerRef.current = new google.maps.marker.AdvancedMarkerElement({ map: mapRef.current, position: coordinates, content, title: t.locationFound, zIndex: 5000 })
    } else {
      userMarkerRef.current.map = mapRef.current
      userMarkerRef.current.position = coordinates
    }
  }
  const locate = async () => {
    setLocationStatus('loading')
    const result = await requestCurrentLocation()
    if (!result.ok) { setLocationStatus(result.reason); return }
    mapRef.current?.panTo(result.coordinates)
    mapRef.current?.setZoom(14)
    await showUserMarker(result.coordinates)
    onCameraChange({ ...result.coordinates, zoom: 14 }, true)
    setLocationStatus('success')
  }
  useEffect(() => {
    if (mapStatus !== 'ready' || !initialCenter) return
    void showUserMarker(initialCenter)
    return () => { if (userMarkerRef.current) userMarkerRef.current.map = null }
    // Marker creation is tied to the resolved initial coordinates and map readiness.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [initialCenter?.lat, initialCenter?.lng, mapStatus])
  const locationMessage = locationStatusMessage(t, locationStatus)
  const mainDrawLabel = drawing ? t.cancelDrawing : polygon.length >= 3 ? t.redrawZone : t.drawZone
  const toggleDrawing = () => setDrawing((current) => !current)
  return <section className={cn('m2-map-screen', drawing && 'is-freehand-drawing', polygon.length >= 3 && 'has-drawn-zone')} data-testid={mapStatus === 'ready' ? `map-${mode}` : undefined}>
    {mode === 'draw' ? <BackHeader title={t.mapDrawTitle} onBack={onBack} backLabel={t.back} /> : <><header className="m2-map-results-header"><button type="button" className="m2-icon-button" onClick={onBack} aria-label={t.back}><ArrowLeft /></button><div><strong>{communityName(new URLSearchParams(window.location.hash.split('?')[1] || '').get('comunidad'), language)}</strong><small>{query || t.visibleArea}</small></div><button type="button" className={cn('m2-save', saved && 'is-saved')} onClick={() => { if (!saved) onSave?.(); setSaved((value) => !value) }} aria-pressed={saved}>{saved ? <Check /> : <Bell />}{saved ? t.saved : t.save}</button></header><div className="m2-map-toolbar"><button type="button" onClick={onFilters}><SlidersHorizontal />{t.filters}</button><button type="button" onClick={onList}><Menu />{t.list}</button></div></>}
    <GoogleMapCanvas t={t} mapRef={mapRef} query={query} initialCenter={initialCenter} initialCamera={initialCamera} onStatus={setMapStatus} onCameraChange={onCameraChange} />
    <Suspense fallback={null}>{serverQuery ? <MobileServerMapLayer mapRef={mapRef} mapReady={mapStatus === 'ready'} query={serverQuery} /> : <MobileMapListingsLayer mapRef={mapRef} mapReady={mapStatus === 'ready'} language={language} drawing={drawing} items={items} preserveCamera={preserveInitialCamera.current} onInitialFit={onCameraChange} />}</Suspense>
    <FreehandAreaLayer mapRef={mapRef} mapReady={mapStatus === 'ready'} active={drawing} setActive={setDrawing} polygon={polygon} onPolygonChange={onPolygonChange} t={t} />
    <div className="m2-map-controls"><button type="button" onClick={toggleLayers} aria-label={t.layers} aria-pressed={mapType === 'hybrid'} disabled={mapStatus !== 'ready' || drawing}><Layers3 /></button><button type="button" onClick={locate} aria-label={t.locate} disabled={mapStatus !== 'ready' || locationStatus === 'loading' || drawing}><Crosshair /></button></div>
    {locationMessage ? <div className={cn('m2-location-toast', !['loading', 'success'].includes(locationStatus) && 'is-error')} role="status">{locationMessage}</div> : null}
    {polygon.length >= 3 && !drawing ? <button type="button" className="m2-search-area" data-testid="search-this-area" onClick={onSearchArea}><Search />{t.searchArea}</button> : null}
    <div className="m2-draw-actions">{polygon.length >= 3 && !drawing ? <button type="button" className="m2-clear-zone" onClick={() => onPolygonChange([])} aria-label={t.clearZone}><Trash2 /></button> : null}<button type="button" className="m2-draw-cta" onClick={toggleDrawing} disabled={mapStatus !== 'ready'} aria-pressed={drawing}><PenTool />{mainDrawLabel}</button></div>
  </section>
}

type MobileCollectionItem = { id: string; title: string; meta: string; image?: string; onOpen: () => void }

function EmptyScreen({ kind, onLogin, onExplore, authenticated, t, items = [] }: { kind: 'searches' | 'favorites'; onLogin: () => void; onExplore: () => void; authenticated: boolean; t: MobileCopy; items?: MobileCollectionItem[] }) {
  const data = { searches: { title: t.searchesTitle, heading: t.searchesHeading, text: t.searchesText, icon: <Bell /> }, favorites: { title: t.favoritesTitle, heading: t.favoritesHeading, text: t.favoritesText, icon: <Heart /> } }[kind]
  if (items.length) return <section className="m2-screen m2-empty m2-collection"><header>{data.title}</header><div className="m2-collection__list">{items.map((item) => <button type="button" key={item.id} onClick={item.onOpen}><span><strong>{item.title}</strong><small>{item.meta}</small></span><ChevronRight /></button>)}</div></section>
  const heading = authenticated && kind === 'searches' ? t.searchesEmpty : data.heading
  const text = authenticated && kind === 'searches' ? t.searchesEmptyText : data.text
  return <section className="m2-screen m2-empty"><header>{data.title}</header><div className="m2-empty__icon">{data.icon}</div><h1>{heading}</h1><p>{text}</p><PrimaryButton onClick={authenticated ? onExplore : onLogin}>{authenticated ? t.search : t.login}</PrimaryButton></section>
}

function FavoritesCollectionScreen({ items, recentItems, onRemove, onClearRecent, onLogin, onExplore, authenticated, language, t }: {
  items: MobileCollectionItem[]
  recentItems: MobileCollectionItem[]
  onRemove: (id: string) => void
  onClearRecent: () => void
  onLogin: () => void
  onExplore: () => void
  authenticated: boolean
  language: AppLanguage
  t: MobileCopy
}) {
  const actionCopy = favoriteActionCopy[language]
  const [selecting, setSelecting] = useState(false)
  const [selected, setSelected] = useState<Set<string>>(() => new Set())

  useEffect(() => {
    const available = new Set(items.map((item) => item.id))
    setSelected((current) => new Set([...current].filter((id) => available.has(id))))
    if (!items.length) setSelecting(false)
  }, [items])

  if (!items.length && !recentItems.length) return <EmptyScreen kind="favorites" onLogin={onLogin} onExplore={onExplore} authenticated={authenticated} t={t} />

  const allSelected = selected.size === items.length
  const stopSelecting = () => { setSelecting(false); setSelected(new Set()) }
  const toggleSelected = (id: string) => setSelected((current) => {
    const next = new Set(current)
    if (next.has(id)) next.delete(id)
    else next.add(id)
    return next
  })
  const toggleAll = () => setSelected(allSelected ? new Set() : new Set(items.map((item) => item.id)))
  const removeSelected = () => {
    const ids = [...selected]
    if (!ids.length) return
    ids.forEach(onRemove)
    stopSelecting()
  }

  return <section className="m2-screen m2-empty m2-collection">
    <header className="m2-collection__header">
      <span>{t.favoritesTitle}</span>
      {items.length ? <button
        type="button"
        className="m2-favorites-trash"
        aria-label={selecting ? actionCopy.cancel : actionCopy.startDelete}
        aria-pressed={selecting}
        onClick={() => { if (selecting) stopSelecting(); else setSelecting(true) }}
      >{selecting ? <X /> : <Trash2 />}</button> : null}
    </header>
    {selecting ? <div className="m2-favorites-selection-bar" role="toolbar" aria-label={actionCopy.startDelete}>
      <strong aria-live="polite">{actionCopy.selected(selected.size)}</strong>
      <div className="m2-favorites-selection-actions">
        <button type="button" onClick={toggleAll}>{allSelected ? actionCopy.clearSelection : actionCopy.selectAll}</button>
        <button type="button" onClick={stopSelecting}>{actionCopy.cancel}</button>
        <button type="button" className="m2-favorites-remove-selected" disabled={!selected.size} onClick={removeSelected}><Trash2 />{actionCopy.removeSelected(selected.size)}</button>
      </div>
    </div> : null}
    {items.length ? <section className="m2-favorites-primary" aria-labelledby="m2-favorites-primary-title">
      <div className="m2-favorites-section-head">
        <strong id="m2-favorites-primary-title">{t.favorites}</strong>
        <span aria-label={String(items.length)}>{items.length}</span>
      </div>
      <div className="m2-collection__list m2-favorite-cards">
        {items.map((item) => {
          const isSelected = selected.has(item.id)
          return <button
            type="button"
            key={item.id}
            className={cn('m2-favorite-card', selecting && 'm2-favorite-item--selecting', isSelected && 'm2-favorite-item--selected')}
            aria-pressed={selecting ? isSelected : undefined}
            aria-label={selecting ? (isSelected ? actionCopy.deselectListing(item.title) : actionCopy.selectListing(item.title)) : undefined}
            onClick={selecting ? () => toggleSelected(item.id) : item.onOpen}
          >
            <span className="m2-favorite-card__media" aria-hidden="true">
              {item.image ? <span data-testid="favorite-full-photo" className="m2-favorite-card__photo" style={{ backgroundImage: `url("${item.image.replace(/"/g, '%22')}")` }} /> : <ImageIcon />}
            </span>
            <span className="m2-favorite-card__copy"><strong>{item.title}</strong><small>{item.meta}</small></span>
            {selecting ? <span className="m2-favorites-select-indicator" aria-hidden="true">{isSelected ? <Check /> : null}</span> : <ChevronRight />}
          </button>
        })}
      </div>
    </section> : null}
    <section className="m2-recent-history" aria-labelledby="m2-recent-history-title">
      <div className="m2-recent-history__head">
        <strong id="m2-recent-history-title">{t.recentlyViewed}</strong>
        {recentItems.length ? <button type="button" onClick={onClearRecent}>{t.clearHistory}</button> : null}
      </div>
      {recentItems.length ? <div className="m2-collection__list m2-recent-history__list">
        {recentItems.map((item) => <button type="button" key={item.id} onClick={item.onOpen}><span><strong>{item.title}</strong><small>{item.meta}</small></span><ChevronRight /></button>)}
      </div> : <p className="m2-recent-history__empty">{t.historyEmpty}</p>}
    </section>
  </section>
}

function MenuScreen({
  onLogin, onProperties, onAdvertising, onLanguage, onRegion, onPublish, onAdmin,
  adminAllowed, authenticated, language, t, currentUserName, selectedCommunity,
}: {
  onLogin: () => void
  onProperties: () => void
  onAdvertising: () => void
  onLanguage: () => void
  onRegion: () => void
  onPublish: () => void
  onAdmin: () => void
  adminAllowed: boolean
  authenticated: boolean
  language: AppLanguage
  t: MobileCopy
  currentUserName?: string
  selectedCommunity: string | null
}) {
  const languageLabel = languages.find((item) => item.value === language)?.label ?? 'Español'
  const advertisingLabel = language === 'ru' ? 'Мои рекламные кампании' : language === 'en' ? 'My advertising campaigns' : 'Mis campañas publicitarias'
  const regionLabel = selectedCommunity
    ? `España (${communityName(selectedCommunity, language)})`
    : 'España'
  const adminCopy = {
    es: { eyebrow: 'PANEL DE ADMINISTRACIÓN', description: 'Gestiona tus propiedades, reservas, clientes y ajustes avanzados.' },
    en: { eyebrow: 'ADMINISTRATION PANEL', description: 'Manage properties, bookings, clients and advanced settings.' },
    ru: { eyebrow: 'ПАНЕЛЬ АДМИНИСТРАТОРА', description: 'Управление объектами, бронированиями, клиентами и настройками.' },
  }[language]
  const name = currentUserName?.trim() || t.login

  return (
    <section className="m2-screen m2-menu" data-testid="mobile-menu">
      <header>{t.menu}</header>
      <div className="m2-menu-content">
        {adminAllowed ? (
          <button
            type="button"
            className="m2-menu-admin-card"
            onClick={onAdmin}
            data-testid="menu-admin-entry"
          >
            <span className="m2-menu-admin-card__icon"><Shield aria-hidden="true" /></span>
            <span className="m2-menu-admin-card__content">
              <small>{adminCopy.eyebrow}</small>
              <strong>{t.adminPanel}</strong>
              <span>{adminCopy.description}</span>
            </span>
            <span className="m2-menu-admin-card__arrow"><ChevronRight aria-hidden="true" /></span>
          </button>
        ) : null}

        <section className="m2-menu-account-card" aria-label={name}>
          <div className="m2-menu-login">
            <span className="m2-menu-account-avatar"><UserRound aria-hidden="true" /></span>
            <div>
              <h2>{name}</h2>
              <p>{t.loginDescription}</p>
            </div>
          </div>
          <PrimaryButton onClick={authenticated ? onProperties : onLogin}>
            <span>{authenticated ? t.yourProperties : t.login}</span>
            <ChevronRight aria-hidden="true" />
          </PrimaryButton>
          {authenticated ? (
            <button type="button" className="m2-menu-row m2-menu-row--profile" onClick={onLogin}>
              <span className="m2-menu-row__label"><span className="m2-menu-row__icon m2-menu-row__icon--plain"><UserRound aria-hidden="true" /></span>{t.editProfile}</span>
              <ChevronRight aria-hidden="true" />
            </button>
          ) : null}
        </section>

        <section className="m2-menu-section" aria-label={t.propertyManagement}>
          <h3>{t.propertyManagement}</h3>
          <div className="m2-menu-group">
            <button type="button" className="m2-menu-row" onClick={onPublish}>
              <span className="m2-menu-row__label"><span className="m2-menu-row__icon"><Plus aria-hidden="true" /></span>{t.publishYourAd}</span>
              <ChevronRight aria-hidden="true" />
            </button>
            {authenticated ? (
              <button type="button" className="m2-menu-row" onClick={onAdvertising}>
                <span className="m2-menu-row__label"><span className="m2-menu-row__icon"><Megaphone aria-hidden="true" /></span>{advertisingLabel}</span>
                <ChevronRight aria-hidden="true" />
              </button>
            ) : null}
          </div>
        </section>

        <section className="m2-menu-section" aria-label={t.settings}>
          <h3>{t.settings}</h3>
          <div className="m2-menu-group">
            <button type="button" className="m2-menu-row" onClick={onRegion}>
              <span className="m2-menu-row__label"><span className="m2-menu-row__icon"><MapPin aria-hidden="true" /></span>{t.searchRegion}</span>
              <span className="m2-menu-row__trailing"><b>{regionLabel}</b><ChevronRight aria-hidden="true" /></span>
            </button>
            <button type="button" className="m2-menu-row" onClick={onLanguage}>
              <span className="m2-menu-row__label"><span className="m2-menu-row__icon"><Globe2 aria-hidden="true" /></span>{t.language}</span>
              <span className="m2-menu-row__trailing"><b>{languageLabel}</b><ChevronRight aria-hidden="true" /></span>
            </button>
          </div>
        </section>
      </div>
    </section>
  )
}

function getNavItems(t: MobileCopy): Array<{ tab: MobileTab; label: string; icon: typeof Home }> {
  return [{ tab: 'home', label: t.home, icon: Home }, { tab: 'searches', label: t.searches, icon: Bell }, { tab: 'favorites', label: t.favorites, icon: Heart }, { tab: 'menu', label: t.menu, icon: Menu }]
}

const tabRoutes: Record<MobileTab, string> = {
  home: '/',
  searches: '/busquedas-guardadas',
  favorites: '/favoritos',
  menu: '/menu',
}

function tabFromPath(pathname: string): MobileTab {
  if (pathname === '/busquedas-guardadas') return 'searches'
  if (pathname === '/favoritos') return 'favorites'
  if (pathname === '/menu') return 'menu'
  return 'home'
}

export function MobileAppV2() {
  const location = useLocation()
  const navigate = useNavigate()
  const routeSearchRef = useRef(location.search)
  const pendingRouteSearchRef = useRef<string | null>(null)
  const latestPendingCameraRef = useRef<{ camera: MapCamera; query: string | null } | null>(null)
  // A generated exact map camera is only for Back/Forward within the same app
  // session. On a fresh visit or browser reload we recall the 70 km region.
  const mapEntryRef = useRef({ active: false, returnedInApp: false })
  const onMapRoute = location.pathname === '/buscar' && new URLSearchParams(location.search).get('vista') === 'mapa'
  if (onMapRoute && !mapEntryRef.current.active) {
    mapEntryRef.current.returnedInApp = mapOpenedInCurrentDocument
  }
  mapEntryRef.current.active = onMapRoute
  // Commit only after React mounts the route. StrictMode may render the tree
  // twice before effects run; a speculative render must not start a session.
  useEffect(() => {
    if (onMapRoute) mapOpenedInCurrentDocument = true
  }, [onMapRoute])
  if (pendingRouteSearchRef.current === location.search) pendingRouteSearchRef.current = null
  if (!pendingRouteSearchRef.current) routeSearchRef.current = location.search
  const backToHome = useAppBack('/')
  const mapBackParams = new URLSearchParams(location.search)
  mapBackParams.delete('vista')
  mapBackParams.delete('mapLat')
  mapBackParams.delete('mapLng')
  mapBackParams.delete('mapZoom')
  const backFromMap = useAppBack(`/buscar?${mapBackParams.toString()}`)
  const { language, setLanguage } = useI18n()
  const { allListings, discarded, toggleFavorite, savedSearches, mapPolygon, setMapPolygon, saveCurrentSearch, restoreSavedSearch, setQuery, rentalMode, filters, setFilters, currentUser } = useApp()
  const mapPolygonRef = useRef(mapPolygon)
  mapPolygonRef.current = mapPolygon
  const [step, setStep] = useState<OnboardingStep>(() => {
    const navigation = performance.getEntriesByType('navigation')[0] as PerformanceNavigationTiming | undefined
    try {
      const stored = localStorage.getItem(ONBOARDING_KEY)
      if (stored === 'done:refreshable' && navigation?.type === 'reload') return 'language'
      return stored === 'done' || stored === 'done:refreshable' ? 'done' : 'language'
    } catch { return 'language' }
  })
  const [origin, setOrigin] = useState<OnboardingOrigin>('startup')
  const [page, setPage] = useState<AppPage>('tabs')
  const [mapMode, setMapMode] = useState<MapMode>('search')
  const [mapQuery, setMapQuery] = useState('')
  const [mapCenter, setMapCenter] = useState<MapPoint | undefined>()
  const [nearbyStatus, setNearbyStatus] = useState<LocationStatus>('idle')
  const [tab, setTab] = useState<MobileTab>(() => tabFromPath(location.pathname))
  const [homeMode, setHomeMode] = useState<SearchMode>(null)
  const [selectedCommunity, setSelectedCommunity] = useState<string | null>(null)
  const [mobileViewport, setMobileViewport] = useState(() => window.matchMedia('(max-width: 767px), (max-height: 480px) and (max-width: 900px)').matches)
  const shellActive = mobileViewport && ['/', '/buscar', '/favoritos', '/busquedas-guardadas', '/menu'].includes(location.pathname)
  const t: MobileCopy = copy[language]
  const adminAllowed = useAdminAccess()
  const navItems = getNavItems(t)
  const mapFilterParams = new URLSearchParams(location.search)
  mapFilterParams.delete('mapLat')
  mapFilterParams.delete('mapLng')
  mapFilterParams.delete('mapZoom')
  // An automatically recorded camera is not a search filter. Otherwise the
  // first map idle churns marker data and recreates every price marker.
  mapFilterParams.delete('mapAuto')
  const mapFilterSearch = mapFilterParams.toString()
  // The results list and map must use identical route-scoped criteria.
  // React context can retain the previous search/region after a language or
  // filter change; it is not a reliable source for a new map API request.
  const mapRouteCriteria = useMemo(() => {
    const route = new URLSearchParams(mapFilterSearch)
    const scopedFilters = filtersFromParams(route)
    const types = (route.get('tiposHabitacion') ?? '').split('|').filter(
      (value): value is Listing['roomType'] =>
        ['Habitación individual', 'Habitación compartida', 'Estudio'].includes(value),
    )
    const geometry = searchGeographyFromParams(route)
    return {
      mode: route.get('alquiler') === 'holiday' ? 'holiday' as const : 'long' as const,
      filters: scopedFilters,
      roomTypes: types,
      geography: geometry,
    }
  }, [mapFilterSearch])
  const mapItems = useMemo(() => mockMode ? selectMobileSearchListings({
    listings: allListings,
    discarded,
    rentalMode: mapRouteCriteria.mode,
    filters: mapRouteCriteria.filters,
    polygon: mapPolygon,
    query: mapRouteCriteria.geography.query ?? 'España',
    params: new URLSearchParams(mapFilterSearch),
  }) : [], [allListings, discarded, mapFilterSearch, mapPolygon, mapRouteCriteria])
  const serverMapQuery = useMemo(() => mockMode ? undefined : buildListingSearchBody({
    rentalMode: mapRouteCriteria.mode,
    ...mapRouteCriteria.geography,
    filters: mapRouteCriteria.filters,
    minPrice: mapRouteCriteria.filters.minPrice,
    maxPrice: mapRouteCriteria.filters.maxPrice,
    roomTypes: mapRouteCriteria.roomTypes,
    polygon: mapPolygon.length >= 3
      ? mapPolygon.map(({ lat, lng }) => ({ latitude: lat, longitude: lng }))
      : mapRouteCriteria.geography.polygon,
  }), [mapRouteCriteria, mapPolygon])
  const cameraParams = new URLSearchParams(location.search)
  // Explicit deep links and a new city search outrank previous map history.
  // "Tenerife" is the generic search label, not a newly selected municipality.
  const explicitCamera = cameraParams.get('mapAuto') === '1' && !mapEntryRef.current.returnedInApp
    ? null : mapViewportFromParams(cameraParams)
  const hasNearbyCoordinates = cameraParams.has('lat') && cameraParams.has('lng')
    && Number.isFinite(Number(cameraParams.get('lat'))) && Number.isFinite(Number(cameraParams.get('lng')))
    && Math.abs(Number(cameraParams.get('lat'))) <= 85 && Math.abs(Number(cameraParams.get('lng'))) <= 180
  const chosenLocation = resolveTenerifeLocation(cameraParams.get('q') ?? '')
  const selectedRouteCommunity = cameraParams.get('comunidad')
  const selectedRegionCamera = selectedRouteCommunity ? communityMapCamera(selectedRouteCommunity, window.innerWidth, window.innerHeight) : undefined
  const namedLocation = chosenLocation?.type !== 'island' ? chosenLocation?.coordinates : undefined
  const hasActivePolygon = mapPolygon.length >= 3 || Boolean(cameraParams.get('poligono')?.trim())
  const mapCamera = explicitCamera ?? (hasNearbyCoordinates || hasActivePolygon ? undefined
    : selectedRegionCamera ?? (namedLocation ? { ...namedLocation, zoom: 12 }
      : readLastMapViewport(window.innerWidth, window.innerHeight) ?? FIRST_MAP_VIEWPORT))
  const nearbyCameraCenter = hasNearbyCoordinates
    ? { lat: Number(cameraParams.get('lat')), lng: Number(cameraParams.get('lng')) }
    : undefined
  const { listings: favoriteListings } = useFavoriteListings()
  const { listings: recentlyViewedListings, clear: clearRecentHistory, mark: markRecent } = useRecentlyViewedListings()
  const favoriteItems = useMemo<MobileCollectionItem[]>(() => favoriteListings.map((listing) => ({ id: listing.id, title: listing.title, meta: `${listing.approximateAddress ? `${listing.approximateAddress}, ${listing.city}` : `${listing.area}, ${listing.city}`} · ${listing.price} €`, image: listing.images[0], onOpen: () => navigate(`/habitacion/${listing.id}`) })), [favoriteListings, navigate])
  const recentItems = useMemo<MobileCollectionItem[]>(() => recentlyViewedListings.map((listing) => ({ id: listing.id, title: listing.title, meta: `${listing.approximateAddress ? `${listing.approximateAddress}, ${listing.city}` : `${listing.area}, ${listing.city}`} · ${listing.price} €`, onOpen: () => {
    markRecent(listing.id)
    if (listing.isExternal && listing.sourceUrl) { window.open(listing.sourceUrl, '_blank', 'noopener,noreferrer'); return }
    navigate(`/habitacion/${listing.id}`)
  } })), [markRecent, navigate, recentlyViewedListings])
  const savedSearchItems = useMemo<MobileCollectionItem[]>(() => savedSearches.map((search) => ({ id: search.id, title: search.query, meta: search.rentalMode === 'holiday' ? t.tourismMode : t.housingMode, onOpen: () => { restoreSavedSearch(search.id); navigate(`/buscar?q=${encodeURIComponent(search.query)}&alquiler=${search.rentalMode}`) } })), [navigate, restoreSavedSearch, savedSearches, t.housingMode, t.tourismMode])
  useEffect(() => {
    document.documentElement.classList.toggle('mobile-v2-active', shellActive)
    return () => document.documentElement.classList.remove('mobile-v2-active')
  }, [shellActive])
  useEffect(() => {
    if (shellActive && tab === 'menu' && currentUser) preloadAccountPages()
  }, [currentUser, shellActive, tab])
  useEffect(() => {
    const media = window.matchMedia('(max-width: 767px), (max-height: 480px) and (max-width: 900px)')
    const update = () => setMobileViewport(media.matches)
    media.addEventListener('change', update)
    return () => media.removeEventListener('change', update)
  }, [])
  useEffect(() => {
    if (step !== 'done') return
    const params = new URLSearchParams(location.search)
    if (location.pathname === '/buscar' && params.get('vista') === 'mapa') {
      setMapMode(params.get('dibujar') === '1' ? 'draw' : 'search')
      setMapQuery(params.get('q') ?? '')
      const latParam = params.get('lat')
      const lngParam = params.get('lng')
      const lat = Number(latParam)
      const lng = Number(lngParam)
      setMapCenter(latParam !== null && lngParam !== null && Number.isFinite(lat) && Number.isFinite(lng) ? { lat, lng } : undefined)
      setPage('map')
      return
    }
    if (location.pathname === '/' && params.get('panel') === 'ubicacion') {
      setPage('location')
      return
    }
    setPage('tabs')
    setTab(tabFromPath(location.pathname))
  }, [location.pathname, location.search, step])
  useEffect(() => {
    if (!shellActive || location.pathname !== '/buscar') return
    const polygonParam = new URLSearchParams(location.search).get('poligono')
    const routePolygon = polygonParam
      ? polygonParam.split(';').map((pair) => pair.split(',').map(Number)).filter((pair) => pair.length === 2 && pair.every(Number.isFinite)).map(([lat, lng]) => ({ lat, lng }))
      : []
    const nextPolygon = routePolygon.length >= 3 ? routePolygon : []
    if (JSON.stringify(nextPolygon) !== JSON.stringify(mapPolygonRef.current)) setMapPolygon(nextPolygon)
  }, [location.pathname, location.search, setMapPolygon, shellActive])
  useEffect(() => {
    if (location.pathname !== '/buscar') return
    setHomeMode(rentalMode === 'holiday' ? 'turismo' : 'vivienda')
  }, [location.pathname, rentalMode])
  const persistOnboarding = () => { try { localStorage.setItem(ONBOARDING_KEY, 'done:refreshable') } catch { /* private mode */ } }
  const returnToApp = () => { persistOnboarding(); setStep('done'); setPage('tabs') }
  const finishAuth = () => { persistOnboarding(); if (origin === 'startup') { setTab(tabFromPath(location.pathname)); setPage('tabs') }; setStep('done') }
  const openAccount = () => navigate(currentUser ? '/perfil' : '/acceso')
  const openProperties = () => navigate(currentUser ? '/mis-anuncios' : '/acceso')
  const openLanguageSettings = () => { setOrigin('language-settings'); setStep('language') }
  const openRegionSettings = (from: 'menu' | 'location') => { setOrigin(from === 'menu' ? 'region-settings' : 'region-location'); setStep('country') }
  const handleLanguageContinue = () => { if (origin === 'language-settings') { setStep('done'); setPage('tabs'); setTab('menu') } else setStep('country') }
  const handleCountryContinue = () => { if (origin === 'region-location') { setStep('done'); navigate('/?panel=ubicacion'); return }; if (origin === 'region-settings') { setStep('done'); navigate('/menu'); return }; setStep('privacy') }
  const authBack = () => { if (origin === 'startup') setStep('privacy'); else returnToApp() }
  const openMap = (mode: MapMode, query = '') => {
    const searchMode = homeMode === 'turismo' ? 'holiday' : 'long'
    const nextFilters = mobileHomeSearchFilters(filters, searchMode)
    setFilters(nextFilters)
    const params = filtersToParams(nextFilters)
    params.set('q', query || (selectedCommunity ? getCommunity(selectedCommunity)?.es : undefined) || 'España')
    if (selectedCommunity && !query) params.set('comunidad', selectedCommunity)
    params.set('vista', 'mapa')
    params.set('alquiler', searchMode)
    if (mapPolygon.length >= 3) params.set('poligono', mapPolygon.map((point) => `${point.lat.toFixed(5)},${point.lng.toFixed(5)}`).join(';'))
    if (mode === 'draw') params.set('dibujar', '1')
    navigate(`/buscar?${params.toString()}`)
  }
  const openNearby = async () => {
    setNearbyStatus('loading')
    const result = await requestCurrentLocation()
    if (!result.ok) { setNearbyStatus(result.reason); return }
    const searchMode = homeMode === 'turismo' ? 'holiday' : 'long'
    const nextFilters = mobileHomeSearchFilters(filters, searchMode)
    setFilters(nextFilters)
    const params = filtersToParams(nextFilters)
    params.set('q', 'España')
    params.set('vista', 'mapa')
    params.set('cerca', '1')
    params.set('radio', '30')
    params.set('lat', String(result.coordinates.lat))
    params.set('lng', String(result.coordinates.lng))
    params.set('alquiler', searchMode)
    setNearbyStatus('success')
    navigate(`/buscar?${params.toString()}`)
  }
  const commitMobilePolygon = (polygon: MapPoint[]) => {
    setMapPolygon(polygon)
    const params = new URLSearchParams(routeSearchRef.current)
    if (polygon.length >= 3) params.set('poligono', polygon.map((point) => `${point.lat.toFixed(5)},${point.lng.toFixed(5)}`).join(';'))
    else params.delete('poligono')
    routeSearchRef.current = `?${params.toString()}`
    pendingRouteSearchRef.current = routeSearchRef.current
    navigate(`${location.pathname}?${params.toString()}`, { replace: true })
  }
  const commitMapCamera = (camera: MapCamera, interacted = false) => {
    // Keep Back/deep-link camera state on the URL, but only real map exploration
    // contributes to the next SEARCH's remembered 70 km circle.
    if (interacted) rememberMapViewport(camera)
    if (pendingRouteSearchRef.current) {
      // Google Maps can emit a pan and zoom idle in the same render. Keep the
      // newest camera rather than losing zoom while Router processes replace.
      latestPendingCameraRef.current = { camera, query: new URLSearchParams(routeSearchRef.current).get('q') }
      return
    }
    const params = new URLSearchParams(routeSearchRef.current)
    const lat = camera.lat.toFixed(5)
    const lng = camera.lng.toFixed(5)
    const zoom = camera.zoom.toFixed(2)
    if (params.get('mapLat') === lat && params.get('mapLng') === lng && params.get('mapZoom') === zoom) return
    // Generated cameras must not override the next visit's 70 km recall;
    // explicit bookmarked deep links without this flag still retain their zoom.
    if (interacted || !params.has('mapLat')) params.set('mapAuto', '1')
    params.set('mapLat', lat)
    params.set('mapLng', lng)
    params.set('mapZoom', zoom)
    routeSearchRef.current = `?${params.toString()}`
    pendingRouteSearchRef.current = routeSearchRef.current
    navigate(`${location.pathname}?${params.toString()}`, { replace: true })
  }
  useEffect(() => {
    if (pendingRouteSearchRef.current || !latestPendingCameraRef.current) return
    if (location.pathname !== '/buscar' || new URLSearchParams(location.search).get('vista') !== 'mapa') {
      latestPendingCameraRef.current = null
      return
    }
    const latest = latestPendingCameraRef.current
    latestPendingCameraRef.current = null
    // A new search must not inherit delayed pan events from the old query.
    if (latest.query !== new URLSearchParams(location.search).get('q')) return
    commitMapCamera(latest.camera)
    // The pending camera is flushed only when Router applies its previous URL
    // update; commitMapCamera reads routeSearchRef.current synchronously.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [location.pathname, location.search])

  const navigateFromMap = (target: 'list' | 'filters' | 'area') => {
    const params = new URLSearchParams(location.search)
    params.delete('dibujar')
    params.delete('vista')
    params.delete('mapLat')
    params.delete('mapLng')
    params.delete('mapZoom')
    params.delete('pagina')
    if (target === 'filters') params.set('panel', 'filtros')
    else params.delete('panel')
    if (target === 'area' && mapPolygon.length >= 3) {
      params.set('poligono', mapPolygon.map((point) => `${point.lat.toFixed(5)},${point.lng.toFixed(5)}`).join(';'))
    }
    navigate(`/buscar?${params.toString()}`)
  }
  const searchThisMapArea = () => {
    const params = new URLSearchParams(location.search)
    const keepMap = params.get('dibujar') === '1'
    params.delete('dibujar')
    if (!keepMap) params.delete('vista')
    params.delete('pagina')
    params.delete('panel')
    navigate(`/buscar?${params.toString()}`)
  }
  const chooseCommunity = (id: string) => {
    const region = getCommunity(id)
    if (!region) return
    const mode = homeMode === 'turismo' ? 'holiday' : 'long'
    const nextFilters = { ...mobileHomeSearchFilters(filters, mode), areas: [] }
    setSelectedCommunity(id)
    setMapPolygon([])
    setQuery(region.es)
    setFilters(nextFilters)
    const params = filtersToParams(nextFilters)
    params.set('q', region.es)
    params.set('comunidad', id)
    params.set('alquiler', mode)
    navigate(`/buscar?${params.toString()}`)
  }
  const runHomeSearch = () => {
    const mode = homeMode === 'turismo' ? 'holiday' : 'long'
    const nextFilters = mobileHomeSearchFilters(filters, mode)
    if (nextFilters !== filters) setFilters(nextFilters)
    const params = filtersToParams(nextFilters)
    params.set('q', selectedCommunity ? getCommunity(selectedCommunity)?.es ?? 'España' : 'España')
    if (selectedCommunity) params.set('comunidad', selectedCommunity)
    params.set('alquiler', mode)
    navigate(`/buscar?${params.toString()}`)
  }
  const preloadMobileSearchResults = () => { void import('@/components/mobile-search-results-v2').catch(() => undefined) }
  const openPublication = () => navigate(`${location.pathname}?gate=publicar`)
  if (!shellActive) return null
  if (step !== 'done') return <div className="m2-app notranslate" translate="no"><Onboarding step={step} origin={origin} language={language} setLanguage={setLanguage} onStep={setStep} onCountryContinue={handleCountryContinue} onLanguageContinue={handleLanguageContinue} onAuthBack={authBack} onDone={finishAuth} /></div>
  if (page === 'location') return <div className="m2-app notranslate" translate="no"><LocationScreen t={t} language={language} rentalMode={homeMode === 'turismo' ? 'holiday' : 'long'} onBack={backToHome} onMap={openMap} onNearby={() => { void openNearby() }} onRegionSelect={chooseCommunity} nearbyStatus={nearbyStatus} /></div>
  if (page === 'map') return <div className="m2-app notranslate" translate="no"><MapScreen key={mapQuery} mode={mapMode} language={language} t={t} query={mapQuery} initialCenter={nearbyCameraCenter ?? mapCenter} initialCamera={mapCamera} polygon={mapPolygon} items={mapItems} serverQuery={serverMapQuery} onPolygonChange={commitMobilePolygon} onCameraChange={commitMapCamera} onBack={backFromMap} onSave={() => { setQuery(mapQuery || 'Tenerife'); saveCurrentSearch() }} onList={() => navigateFromMap('list')} onFilters={() => navigateFromMap('filters')} onSearchArea={searchThisMapArea} /></div>
  return <div className="m2-app notranslate" translate="no"><main className="m2-main">{tab === 'home' && location.pathname !== '/buscar' ? <HomeScreen t={t} mode={homeMode} onMode={setHomeMode} onLocation={() => navigate('/?panel=ubicacion')} onSearch={runHomeSearch} onSearchIntent={preloadMobileSearchResults} onPublish={openPublication} selectedCommunity={selectedCommunity} language={language} /> : null}{tab === 'searches' ? <EmptyScreen kind="searches" onLogin={openAccount} onExplore={() => navigate('/buscar?q=Tenerife')} authenticated={Boolean(currentUser)} t={t} items={savedSearchItems} /> : null}{tab === 'favorites' ? <FavoritesCollectionScreen items={favoriteItems} recentItems={recentItems} onRemove={toggleFavorite} onClearRecent={clearRecentHistory} onLogin={openAccount} onExplore={() => navigate('/buscar?q=Tenerife')} authenticated={Boolean(currentUser)} language={language} t={t} /> : null}{tab === 'menu' ? <MenuScreen onLogin={openAccount} onProperties={openProperties} onAdvertising={() => navigate('/mis-campanas')} onLanguage={openLanguageSettings} onRegion={() => openRegionSettings('menu')} onPublish={openPublication} onAdmin={() => navigate('/admin')} adminAllowed={adminAllowed} authenticated={Boolean(currentUser)} language={language} t={t} currentUserName={currentUser?.name} selectedCommunity={selectedCommunity} /> : null}</main><nav className="m2-bottom-nav" aria-label={t.mainNavigation}>{navItems.map(({ tab: itemTab, label, icon: Icon }) => <button key={itemTab} type="button" className={cn(tab === itemTab && 'is-active')} aria-current={tab === itemTab ? 'page' : undefined} onClick={() => navigate(tabRoutes[itemTab])}><Icon /><span>{label}</span></button>)}</nav></div>
}
