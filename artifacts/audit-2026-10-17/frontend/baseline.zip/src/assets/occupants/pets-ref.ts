export { occupantPetsIcon } from './pets'
