"""Verify packaged hashes and recompute acceptance offline from extracted raw."""
import hashlib
import importlib.util
import json
import tarfile
import tempfile
from pathlib import Path

evidence = Path('/code/reports/post-merge-remediation-evidence')
index = json.loads((evidence / 'performance-capacity-evidence.json').read_text())
archive = evidence / index['archive']['name']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == index['archive']['sha256']
with tempfile.TemporaryDirectory() as directory:
    extracted = Path(directory)
    with tarfile.open(archive, 'r:gz') as tar:
        tar.extractall(extracted, filter='data')
    for name, metadata in index['files'].items():
        assert hashlib.sha256((extracted / name).read_bytes()).hexdigest() == metadata['sha256']
    for manifest in (extracted / 'raw').glob('runner-*.json'):
        data = json.loads(manifest.read_text())
        assert data['code_revision'] == index['source_sha']
        for path, expected_hash in data['source_hashes'].items():
            code = extracted / 'source' / path.removeprefix('/code/')
            assert hashlib.sha256(code.read_bytes()).hexdigest() == expected_hash
    spec = importlib.util.spec_from_file_location('acceptance', '/code/scripts/check-ai-map-capacity.py')
    accept = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(accept)
    summary_spec = importlib.util.spec_from_file_location('summary', '/code/scripts/summarize-ai-map-capacity.py')
    summarizer = importlib.util.module_from_spec(summary_spec)
    summary_spec.loader.exec_module(summarizer)
    raw = extracted / 'raw'
    result = summarizer.summarize(raw)
    assert result['protocol_complete'] is True and result['warnings'] == []
    assert result['provenance']['code_revision'] == index['source_sha']
    assert result['slo_passed'] == index['slo_passed']
    try:
        accept.accept(raw, index['source_sha'])
        verdict = 'PASS'
    except ValueError as error:
        assert str(error) == 'current protocol and all capacity SLOs must pass'
        verdict = 'BLOCKED'
    assert (verdict == 'PASS') is result['slo_passed']
    output = {'source_sha': index['source_sha'], 'archive': index['archive'],
        'all_file_hashes_verified': True, 'measured_source_hashes_verified': True,
        'protocol_complete': result['protocol_complete'],
        'slo_passed': result['slo_passed'], 'warnings': result['warnings'],
        'acceptance': verdict, 'network': 'none', 'scales': [
            {'listings': s['dataset']['listings'], 'cases': len(s['load']),
             'attempts': sum(c['samples'] for c in s['load']), 'errors': sum(c['failures'] for c in s['load']),
             'slo_pass_cases': sum(c['pass'] for c in s['load'])} for s in result['scales']]}
    Path('/diagnostic/performance-capacity-replay.json').write_text(json.dumps(output, indent=2))
    print(json.dumps(output))
