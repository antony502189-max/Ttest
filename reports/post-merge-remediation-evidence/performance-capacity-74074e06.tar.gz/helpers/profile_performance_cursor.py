"""Sequential read-only cursor diagnostic on the new, measured synthetic lab."""
import asyncio
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path

from sqlalchemy import Text, func, literal, select, text
from sqlalchemy.dialects.postgresql import aggregate_order_by, dialect

from app.models.ai_fact_pipeline import AiFactCatalog
from app.models.ai_query_proof import AiQueryProof
from app.repositories.ai_query_proofs import proof_population_signature
from app.repositories.ai_query_settings import configure_ai_query


async def main():
    root = Path('/results')
    output = Path('/diagnostic/performance-card-cursor-profile.json')
    assert not output.exists()
    experiment = json.loads((root / 'experiment.json').read_text())
    assert experiment['code_revision'] == os.environ['R01_CODE_REVISION']
    template = json.loads((root / 'template.json').read_text())
    spec = importlib.util.spec_from_file_location('benchmark', '/code/scripts/benchmark-ai-map.py')
    bench = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bench)
    # One connection holds the immutable-dataset freeze; one executes the
    # sequential diagnostic. Neither is a new timed capacity scenario.
    db = bench.engine(pool=2, timeout=5000)
    records = []
    p = AiQueryProof.__table__
    member = func.concat(p.c.canonical_listing_id, ':', p.c.signature, ':', p.c.feature_revision)
    legacy = func.encode(func.sha256(func.convert_to(func.coalesce(func.string_agg(
        member, aggregate_order_by(literal('|'), p.c.canonical_listing_id)), literal('')).cast(Text), 'UTF8')), 'hex')
    statements = {
        'fact_catalog_revision': select(func.count(), func.coalesce(func.sum(AiFactCatalog.revision), 0)),
        'legacy_proof_population_aggregate': select(legacy).where(
            p.c.resolver_version == bench.RESOLVER, p.c.vocabulary_hash == template['vocabulary_hash']),
        'proof_population_generation': select(proof_population_signature(
            resolver_version=bench.RESOLVER, vocabulary_hash=template['vocabulary_hash'])),
    }
    try:
        await bench.verify_database_identity(db)
        async with db.begin() as freeze:
            assert await freeze.scalar(text('SELECT pg_try_advisory_xact_lock(401, 1)'))
            tables = list(await freeze.scalars(text("SELECT format('%I.%I', n.nspname, c.relname) "
                "FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
                "WHERE n.nspname=current_schema() AND c.relkind IN ('r','p') ORDER BY c.oid")))
            await freeze.execute(text('LOCK TABLE ' + ', '.join(tables) + ' IN SHARE MODE NOWAIT'))
            before = await freeze.scalar(text('SELECT data FROM r01_meta'))
            assert before['provenance'] == experiment
            count = await freeze.scalar(text('SELECT count(*) FROM r01_entities'))
            assert count == 1000000
            for name, statement in statements.items():
                sql = str(statement.compile(dialect=dialect(), compile_kwargs={'literal_binds': True}))
                record = {'name': name, 'sql': sql, 'sql_sha256': hashlib.sha256(sql.encode()).hexdigest(), 'samples': []}
                for _ in range(3):
                    started = time.perf_counter()
                    try:
                        async with db.connect() as c:
                            await c.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
                            await configure_ai_query(c)
                            result = (await c.execute(statement)).one()
                        sample = {'ok': True, 'result': list(result)}
                    except Exception as error:
                        sample = {'ok': False, 'error': type(error).__name__, 'detail': str(error)[:300]}
                    sample['ms'] = (time.perf_counter() - started) * 1000
                    record['samples'].append(sample)
                async with db.connect() as c:
                    await c.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
                    await configure_ai_query(c)
                    try:
                        record['plan'] = await c.scalar(text('EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ' + sql))
                    except Exception as error:
                        record['plan_error'] = {'type': type(error).__name__, 'detail': str(error)[:300]}
                records.append(record)
            after = await freeze.scalar(text('SELECT data FROM r01_meta'))
            assert before == after
            result = {'at': bench.now(), 'profile': 'sequential-cursor-aggregates-only', 'capacity_certification': False,
                'provenance': experiment, 'listings': count, 'concurrency': 1, 'driver_cpu': 2,
                'driver_memory_gib': 2, 'statement_timeout_ms': 5000, 'query_settings': {'jit': 'off'},
                'includes_transaction_config_and_pool': True, 'dataset_stable': before == after,
                'seed_generation': before['generation'], 'write_frozen': True, 'lock_mode': 'SHARE',
                'locked_tables': tables, 'records': records,
                'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
            output.write_text(json.dumps(result, indent=2, default=str))
            print(json.dumps({r['name']: r['samples'] for r in records}, default=str))
    finally:
        await db.dispose()


asyncio.run(main())
