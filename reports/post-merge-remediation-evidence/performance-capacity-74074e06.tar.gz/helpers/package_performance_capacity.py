"""Package this continuation only; never rewrite historical measurements."""
import hashlib
import io
import json
import subprocess
import tarfile
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

repo = Path.cwd()
local = repo / 'output/post-merge-remediation'
state = json.loads((local / 'performance-capacity-run.json').read_text(encoding='utf-8-sig'))
result = json.loads((local / 'performance-capacity-result.json').read_text(encoding='utf-8-sig'))
assert result['status'] == 'measured' and result['source_sha'] == state['source_sha']
raw = Path(state['output'])
summary = json.loads((raw / 'summary.json').read_text(encoding='utf-8'))
assert summary['provenance']['code_revision'] == state['source_sha']
assert summary['protocol_complete'] is True
assert summary['warnings'] == []
assert len(summary['scales']) == 3 and sum(len(s['load']) for s in summary['scales']) == 54
evidence = repo / 'reports/post-merge-remediation-evidence'
archive = evidence / ('performance-capacity-' + state['experiment_id'][:8] + '.tar.gz')
assert not archive.exists()
files = {'raw/' + p.name: p.read_bytes() for p in sorted(raw.iterdir()) if p.is_file() and not p.name.startswith('.')}
tests = {}
for name in ('single-pass-unit.xml', 'single-pass-proof-contracts-final.xml', 'single-pass-integration-final.xml',
             'single-pass-migration-map-toolchain.xml', 'single-pass-population-final.xml', 'single-pass-windows.xml'):
    path = local / name
    files['tests/' + name] = path.read_bytes()
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    totals = {k: sum(int(s.attrib.get(k, '0')) for s in suites) for k in ('tests', 'failures', 'errors', 'skipped')}
    assert totals['failures'] == totals['errors'] == 0
    tests[name] = totals
for name in ('run-performance-capacity.ps1', 'resume-performance-capacity.ps1', 'performance-capacity-orchestration.log',
             'performance-capacity-orchestration.err', 'performance-capacity-resume.log', 'performance-capacity-resume.err',
             'performance-capacity-run.json', 'performance-capacity-result.json', 'profile-performance-cursor.ps1',
             'profile_performance_cursor.py', 'performance-cursor-profile-first-failed.log', 'performance-cursor-profile.log', 'performance-card-cursor-profile.json', 'performance-runtime-ci.json', 'package_performance_capacity.py', 'replay_performance_capacity.py'):
    files['helpers/' + name] = (local / name).read_bytes()
with tempfile.TemporaryDirectory() as directory:
    exported = Path(directory) / 'source.tar'
    subprocess.run(['git', 'archive', '--format=tar', '--output=' + str(exported), state['source_sha']], check=True)
    assert hashlib.sha256(exported.read_bytes()).hexdigest() == summary['provenance']['archive_sha256']
    with tarfile.open(exported) as tar:
        for name in ('backend/app/repositories/ai_query_settings.py', 'backend/app/repositories/ai_verified_cards.py',
                     'backend/app/repositories/listings.py', 'backend/app/repositories/ai_query_proofs.py',
                     'backend/alembic/versions/0075_ai_proof_population.py', 'scripts/benchmark-ai-map.py'):
            # Execution uses exported archive bytes (including Git's EOL
            # attributes), not git-show blob bytes. Preserve them exactly.
            files['source/' + name] = tar.extractfile(name).read()
index = {'kind': 'full-isolated-capacity-protocol', 'date': '2026-10-31 Europe/Moscow',
    'experiment_id': state['experiment_id'], 'source_sha': state['source_sha'],
    'provenance': summary['provenance'], 'protocol_complete': summary['protocol_complete'],
    'slo_passed': summary['slo_passed'], 'summary_exit': result['summary_exit'],
    'acceptance_exit': result['acceptance_exit'], 'tests': tests,
    'source_bytes': 'exact git archive export; native Git EOL attributes preserved',
    'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in files.items()}}
with tarfile.open(archive, 'w:gz') as tar:
    for name, data in files.items():
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        tar.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    for name, metadata in index['files'].items():
        assert hashlib.sha256(tar.extractfile(name).read()).hexdigest() == metadata['sha256']
index['archive'] = {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(evidence / 'performance-capacity-evidence.json').write_text(json.dumps(index, indent=2), encoding='utf-8')
(evidence / 'performance-capacity-summary.json').write_bytes((raw / 'summary.json').read_bytes())
(evidence / 'ci-performance-runtime.json').write_bytes((local / 'performance-runtime-ci.json').read_bytes())
(evidence / 'performance-card-cursor-profile.json').write_bytes((local / 'performance-card-cursor-profile.json').read_bytes())
header = f"Источник: `{state['source_sha']}`; experiment `{state['experiment_id']}`; 31 октября 2026, Europe/Moscow.\n\nНовый изолированный прогон; исторические результаты `6548a2ae` в него не перенесены.\n\n"
(repo / 'reports/AI_MAP_CAPACITY_PERFORMANCE_20261031.md').write_text(header + (raw / 'REPORT_RU.md').read_text(encoding='utf-8'), encoding='utf-8')
print(json.dumps({'archive': index['archive'], 'scales': [
    {'size': s['dataset']['listings'], 'attempts': sum(c['samples'] for c in s['load']),
     'errors': sum(c['failures'] for c in s['load']), 'slo_pass': sum(c['pass'] for c in s['load'])} for s in summary['scales']]}))
