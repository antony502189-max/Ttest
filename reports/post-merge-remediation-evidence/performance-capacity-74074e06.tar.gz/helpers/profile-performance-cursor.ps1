$ErrorActionPreference = 'Stop'
$profileRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $profileRoot
$profileState = Get-Content -Raw (Join-Path $PSScriptRoot 'performance-capacity-run.json') | ConvertFrom-Json
$profileResult = Get-Content -Raw (Join-Path $PSScriptRoot 'performance-capacity-result.json') | ConvertFrom-Json
if ($profileResult.status -ne 'measured' -or $profileResult.source_sha -ne $profileState.source_sha) { throw 'Complete the isolated map experiment first' }
if ((git rev-parse HEAD) -ne $profileState.source_sha -or (git status --porcelain --untracked-files=all)) { throw 'Exact measured clean source required' }
$profileBase = [IO.Path]::GetFullPath($PSScriptRoot).TrimEnd('\') + '\'
$profileSource = Join-Path $profileBase ('cursor-source-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $profileSource | Out-Null
try {
    $profileArchive = Join-Path $profileSource 'source.tar'
    git archive --format=tar --output=$profileArchive $profileState.source_sha
    if ($LASTEXITCODE -ne 0) { throw 'Cannot archive exact measured source' }
    $profileExperiment = Get-Content -Raw (Join-Path $profileState.output 'experiment.json') | ConvertFrom-Json
    if ((Get-FileHash -LiteralPath (Join-Path $profileSource 'source.tar')).Hash.ToLowerInvariant() -ne $profileExperiment.archive_sha256) { throw 'Source archive hash differs' }
    New-Item -ItemType Directory -Path (Join-Path $profileSource 'code') | Out-Null
    tar -xf (Join-Path $profileSource 'source.tar') -C (Join-Path $profileSource 'code')
    if ($LASTEXITCODE -ne 0) { throw 'Cannot extract archived source' }
    docker start $profileState.db
    if ($LASTEXITCODE -ne 0) { throw 'Cannot start owned synthetic DB' }
    for ($profileReadyAttempt=0;$profileReadyAttempt -lt 90;$profileReadyAttempt++) {
      docker exec $profileState.db psql -h 127.0.0.1 -X -U r01 -d r01_synthetic -tAc 'SELECT 1' 2>$null
      if ($LASTEXITCODE -eq 0) { break }
      Start-Sleep -Seconds 1
    }
    if ($LASTEXITCODE -ne 0) { throw 'Own profile DB not ready' }
    $profileDb = (docker inspect $profileState.db | ConvertFrom-Json)[0]
    $profileNetwork = (docker network inspect $profileState.network | ConvertFrom-Json)[0]
    if ($profileDb.Id -ne $profileExperiment.db_container_id -or $profileDb.Image -ne $profileExperiment.db_image_id -or
        $profileDb.Config.Labels.'codex.audit' -ne 'post-merge-remediation' -or -not $profileNetwork.Internal -or
        $profileDb.HostConfig.NanoCpus -ne 8000000000 -or $profileDb.HostConfig.Memory -ne 8589934592 -or
        @($profileDb.HostConfig.PortBindings.PSObject.Properties).Count -ne 0 -or
        @($profileDb.NetworkSettings.Networks.PSObject.Properties).Count -ne 1) { throw 'Unexpected synthetic lab identity/limits' }
    $profileAddress = $profileDb.NetworkSettings.Networks.($profileState.network).IPAddress
    docker run --rm --name ('codex-r01-cursor-' + $profileState.lab_id) --label codex.task=r01-synthetic `
      --network $profileNetwork.Id --add-host "r01-db:$profileAddress" --memory 2g --cpus 2 --read-only --tmpfs /tmp `
      -v "${profileSource}/code:/code:ro" -v "$($profileState.output):/results:ro" -v "${PSScriptRoot}:/diagnostic" -v "${PSScriptRoot}:/profile:ro" `
      -w /code/backend -e PYTHONPATH=/code/backend -e PYTHONDONTWRITEBYTECODE=1 -e R01_DISPOSABLE_LAB=synthetic-only `
      -e R01_CODE_REVISION=$($profileState.source_sha) -e APP_ENV=test `
      -e DATABASE_URL=postgresql+asyncpg://r01:r01-synthetic-only@r01-db:5432/r01_synthetic `
      -e JWT_SECRET=r01-synthetic-secret-at-least-32-characters `
      -e EMAIL_VERIFICATION_HMAC_SECRET=r01-email-synthetic-secret-at-least-32-characters `
      -e REDIS_URL= -e STORAGE_BACKEND=local -e MEDIA_ROOT=/tmp/media -e FRONTEND_ORIGINS=http://127.0.0.1 `
      --entrypoint python $profileExperiment.runner_image_id /profile/profile_performance_cursor.py
    if ($LASTEXITCODE -ne 0) { throw 'Cursor aggregate profile failed' }
} finally {
    docker stop $profileState.db
    $profileResolved = (Resolve-Path -LiteralPath $profileSource).Path
    if (-not $profileResolved.StartsWith($profileBase, [StringComparison]::OrdinalIgnoreCase) -or
        (Split-Path -Leaf $profileResolved) -notmatch '^cursor-source-[0-9a-f]{32}$') { throw 'Refusing cleanup outside own profile directory' }
    Remove-Item -LiteralPath $profileResolved -Recurse -Force
}
