"""Bounded sequential diagnostics; never capacity certification or fixture writes."""
import asyncio
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path

from sqlalchemy import event, text
from sqlalchemy.ext.asyncio import async_sessionmaker

from app.repositories.ai_verified_cards import VerifiedCardSearch
from app.schemas.ai_search_intent import SearchIntent


async def main():
    spec = importlib.util.spec_from_file_location('bench', '/code/scripts/benchmark-ai-map.py')
    bench = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bench)
    fixture = json.loads(Path('/fixture/experiment.json').read_text())
    template = json.loads(Path('/fixture/template.json').read_text())
    db = bench.engine(timeout=5000, pool=1)
    control = bench.engine(timeout=10000, pool=1)
    record = {'kind': 'bounded-sequential-map-diagnostic', 'capacity_certification': False,
              'code_revision': os.environ['R01_CODE_REVISION'], 'fixture': fixture,
              'source_archive_sha256': os.environ['DIAGNOSTIC_ARCHIVE_SHA256'],
              'concurrency': 1, 'maximum_viewport_candidates': 302,
              'source_hash': hashlib.sha256(Path('/code/backend/app/repositories/ai_query_proofs.py').read_bytes()).hexdigest(),
              'records': []}
    try:
        await bench.verify_database_identity(db)
        async with control.begin() as freeze:
            assert await freeze.scalar(text('SELECT pg_try_advisory_xact_lock(401, 1)'))
            tables = list(await freeze.scalars(text("SELECT format('%I.%I', n.nspname, c.relname) "
                "FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace "
                "WHERE n.nspname=current_schema() AND c.relkind IN ('r','p') ORDER BY c.oid")))
            assert tables
            await freeze.execute(text('LOCK TABLE ' + ', '.join(tables) + ' IN SHARE MODE NOWAIT'))
            before = await freeze.scalar(text('SELECT data FROM r01_meta'))
            assert before['synthetic_only'] is True
            assert before['provenance'] == template['provenance']
            assert before['provenance']['db_container_id'] == fixture['db_container_id']
            assert await freeze.scalar(text('SELECT count(*) FROM r01_entities')) == 1000000
            record['generation'] = before['generation']
            factory = async_sessionmaker(db, expire_on_commit=False)
            query = VerifiedCardSearch.__new__(VerifiedCardSearch)
            query.pipeline = bench.pipeline(factory)
            intent = SearchIntent.model_validate_json(json.dumps({'schema_version': 'ai-search.v1', 'taxonomy_version': 'rental.v1',
                'session_id': '00000000-0000-4000-8000-000000000001', 'version': 1,
                'criteria': {'pets': {'strength': 'hard', 'value': [{'species': 'dog', 'size': 'small', 'count': 1}]}}}))
            captured = []
            capture_active = False
            @event.listens_for(db.sync_engine, 'before_cursor_execute')
            def capture(conn, cursor, statement, parameters, context, executemany):
                if capture_active:
                    captured.append((statement, parameters))
            for candidates, zoom in [(0, 8), (300, 13), (302, 13)]:
                case = {'candidates': candidates, 'zoom': zoom, 'samples': []}
                record['records'].append(case)
                for _ in range(2):
                    captured.clear()
                    started = time.perf_counter()
                    try:
                        async with factory() as session, session.begin():
                            await session.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
                            capture_active = True
                            result = await query._map_intent(session, intent, bench.viewport(candidates, 1000000, zoom))
                            capture_active = False
                        items = sorted([item.model_dump(mode='json') for item in result.map.items], key=lambda item: item['id'])
                        sample = {'ok': True, 'count': sum(item.get('count', 1) for item in items), 'items': len(items),
                            'response': items,
                            'response_sha256': hashlib.sha256(json.dumps(items, sort_keys=True).encode()).hexdigest()}
                    except Exception as error:
                        capture_active = False
                        sample = {'ok': False, 'error': type(error).__name__, 'detail': str(error)[:250]}
                    sample['ms'] = (time.perf_counter() - started) * 1000
                    sample['query_count'] = len(captured)
                    case['samples'].append(sample)
                case['plans'] = []
                for statement, parameters in captured:
                    plan = await bench.explain_statement(db, statement, parameters)
                    case['plans'].append({'sql': statement, 'parameters': parameters, **plan})
            record['dataset_stable'] = await freeze.scalar(text('SELECT data FROM r01_meta')) == before
            assert record['dataset_stable']
    finally:
        await db.dispose()
        await control.dispose()
        output = Path('/results') / ('map-proof-' + os.environ['DIAGNOSTIC_VERSION'] + '.json')
        output.write_text(json.dumps(record, indent=2, default=str))
    print(json.dumps({'code_revision': record['code_revision'], 'records': [
        {k: v for k, v in row.items() if k != 'plans'} for row in record['records']]}), flush=True)


asyncio.run(main())
