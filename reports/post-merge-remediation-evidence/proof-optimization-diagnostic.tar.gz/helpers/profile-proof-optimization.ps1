$ErrorActionPreference = 'Stop'
$proofRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $proofRoot
if (git status --porcelain --untracked-files=all) { throw 'Commit exact diagnostic source first' }
$proofNewSha = (git rev-parse HEAD).Trim()
$proofState = Get-Content -Raw (Join-Path $PSScriptRoot 'capacity-run.json') | ConvertFrom-Json
$proofExperiment = Get-Content -Raw (Join-Path $proofState.output 'experiment.json') | ConvertFrom-Json
$proofBase = Join-Path $PSScriptRoot ('proof-diagnostic-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $proofBase | Out-Null
$proofCases = @(@{ name='before'; sha=$proofExperiment.code_revision }, @{name='after'; sha=$proofNewSha})
foreach ($proofCase in $proofCases) {
    $proofSource = Join-Path $proofBase $proofCase.name
    New-Item -ItemType Directory -Path $proofSource | Out-Null
    $proofArchive = Join-Path $proofSource 'source.tar'
    git archive --format=tar --output=$proofArchive $proofCase.sha
    if ($LASTEXITCODE -ne 0) { throw 'Cannot archive source' }
    $proofCase.archive_hash = (Get-FileHash -LiteralPath $proofArchive).Hash.ToLowerInvariant()
    if ($proofCase.name -eq 'before' -and $proofCase.archive_hash -ne $proofExperiment.archive_sha256) { throw 'Old source provenance differs' }
    New-Item -ItemType Directory -Path (Join-Path $proofSource 'code') | Out-Null
    tar -xf $proofArchive -C (Join-Path $proofSource 'code')
    if ($LASTEXITCODE -ne 0) { throw 'Cannot extract source' }
}
$proofDb = (docker inspect $proofState.db | ConvertFrom-Json)[0]
$proofNet = (docker network inspect $proofState.network | ConvertFrom-Json)[0]
if ($proofDb.Id -ne $proofExperiment.db_container_id -or $proofDb.Image -ne $proofExperiment.db_image_id -or
    $proofDb.Config.Labels.'codex.audit' -ne 'post-merge-remediation' -or -not $proofNet.Internal -or
    $proofDb.HostConfig.NanoCpus -ne 8000000000 -or $proofDb.HostConfig.Memory -ne 8589934592 -or
    @($proofDb.HostConfig.PortBindings.PSObject.Properties).Count -ne 0 -or
    @($proofDb.NetworkSettings.Networks.PSObject.Properties).Count -ne 1 -or $proofDb.State.Running) { throw 'Unexpected owned lab identity/limits/state' }
try {
    docker start $proofState.db
    if ($LASTEXITCODE -ne 0) { throw 'Cannot start owned lab' }
    $proofReady = $false
    for ($proofWait=0; $proofWait -lt 30; $proofWait++) {
        docker exec $proofState.db psql -h 127.0.0.1 -X -U r01 -d r01_synthetic -tAc 'SELECT 1' 2>$null
        if ($LASTEXITCODE -eq 0) { $proofReady = $true; break }
        Start-Sleep -Seconds 1
    }
    if (-not $proofReady) { throw 'Lab TCP readiness timed out' }
    $proofDb = (docker inspect $proofState.db | ConvertFrom-Json)[0]
    $proofAddress = $proofDb.NetworkSettings.Networks.($proofState.network).IPAddress
    foreach ($proofCase in $proofCases) {
        $proofCode = Join-Path (Join-Path $proofBase $proofCase.name) 'code'
        docker run --rm --name ('codex-proof-diagnostic-' + $proofCase.name) --label codex.task=r01-synthetic `
            --network $proofNet.Id --add-host "r01-db:$proofAddress" --memory 2g --cpus 2 --read-only --tmpfs /tmp `
            -v "${proofCode}:/code:ro" -v "$($proofState.output):/fixture:ro" -v "${proofBase}:/results" -v "${PSScriptRoot}:/profile:ro" `
            -w /code/backend -e PYTHONPATH=/code/backend -e PYTHONDONTWRITEBYTECODE=1 -e R01_DISPOSABLE_LAB=synthetic-only `
            -e R01_CODE_REVISION=$($proofCase.sha) -e DIAGNOSTIC_VERSION=$($proofCase.name) -e DIAGNOSTIC_ARCHIVE_SHA256=$($proofCase.archive_hash) `
            -e APP_ENV=test -e DATABASE_URL=postgresql+asyncpg://r01:r01-synthetic-only@r01-db:5432/r01_synthetic `
            -e JWT_SECRET=r01-synthetic-secret-at-least-32-characters -e EMAIL_VERIFICATION_HMAC_SECRET=r01-email-synthetic-secret-at-least-32-characters `
            -e REDIS_URL= -e STORAGE_BACKEND=local -e MEDIA_ROOT=/tmp/media -e FRONTEND_ORIGINS=http://127.0.0.1 `
            --entrypoint python $proofExperiment.runner_image_id /profile/profile_proof_optimization.py
        if ($LASTEXITCODE -ne 0) { throw 'Bounded diagnostic failed; preserve all evidence' }
    }
    Write-Output "DIAGNOSTIC_OUTPUT=$proofBase"
} finally {
    docker stop $proofState.db
}
