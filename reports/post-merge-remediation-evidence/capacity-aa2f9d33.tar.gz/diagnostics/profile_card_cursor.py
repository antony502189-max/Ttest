"""Bounded read-only aggregate profile, separate from map capacity attestation."""
import asyncio
import hashlib
import importlib.util
import json
import os
import time
from datetime import UTC, datetime
from pathlib import Path

from sqlalchemy import func, select, text
from sqlalchemy.dialects.postgresql import dialect

from app.models.ai_fact_pipeline import AiFactCatalog
from app.repositories.ai_query_proofs import proof_population_signature


async def main():
    root = Path('/results')
    template = json.loads((root / 'template.json').read_text())
    provenance = template['provenance']
    assert provenance['code_revision'] == os.environ['R01_CODE_REVISION']
    spec = importlib.util.spec_from_file_location('benchmark', '/code/scripts/benchmark-ai-map.py')
    bench = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bench)
    db = bench.engine(timeout=30000)
    rows = []
    try:
        await bench.verify_database_identity(db)
        statements = {
            'fact_catalog_revision': select(func.count(), func.coalesce(func.sum(AiFactCatalog.revision), 0)),
            'proof_population_signature': select(proof_population_signature(
                resolver_version=bench.RESOLVER, vocabulary_hash=template['vocabulary_hash'])),
        }
        for name, statement in statements.items():
            sql = str(statement.compile(dialect=dialect(), compile_kwargs={'literal_binds': True}))
            record = {'name': name, 'sql': sql, 'sql_sha256': hashlib.sha256(sql.encode()).hexdigest(), 'samples': []}
            for _ in range(3):
                started = time.perf_counter()
                try:
                    async with db.connect() as connection:
                        await connection.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
                        result = (await connection.execute(statement)).one()
                    sample = {'ok': True, 'result': list(result)}
                except Exception as error:
                    sample = {'ok': False, 'error': type(error).__name__, 'detail': str(error)[:300]}
                sample['ms'] = (time.perf_counter() - started) * 1000
                record['samples'].append(sample)
            try:
                async with db.connect() as connection:
                    await connection.execute(text('SET TRANSACTION ISOLATION LEVEL REPEATABLE READ, READ ONLY'))
                    record['plan'] = await connection.scalar(text('EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON) ' + sql))
            except Exception as error:
                record['plan_error'] = {'type': type(error).__name__, 'detail': str(error)[:300]}
            rows.append(record)
        async with db.connect() as connection:
            await connection.execute(text('SET TRANSACTION READ ONLY'))
            count = await connection.scalar(text('SELECT count(*) FROM r01_entities'))
        output = {'at': datetime.now(UTC).isoformat(), 'profile': 'sequential-cursor-aggregates-only',
                  'provenance': provenance, 'listings': count, 'concurrency': 1, 'driver_cpu': 2,
                  'driver_memory_gib': 2, 'statement_timeout_ms': 30000, 'records': rows,
                  'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
        (root / 'card-cursor-profile.json').write_text(json.dumps(output, indent=2, default=str))
        print(json.dumps({r['name']: r['samples'] for r in rows}, default=str))
    finally:
        await db.dispose()


asyncio.run(main())
