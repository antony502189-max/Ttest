$ErrorActionPreference = 'Stop'
$capacityRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $capacityRoot
$capacityExperiment = [guid]::NewGuid().ToString('N')
$capacityLab = 'remediation-20261030-' + $capacityExperiment.Substring(0,8)
$capacityNetwork = "codex-r01-$capacityLab"
$capacityDb = "codex-r01-db-$capacityLab"
$capacityImage = 'ttest-main-audit-backend:7d4c1255'
$capacityOutput = Join-Path $capacityRoot "output/r01/$capacityExperiment"
$capacitySha = git rev-parse HEAD
if (git status --porcelain --untracked-files=all) { throw 'Source must be clean before lab creation' }
if ((Get-PSDrive -Name C).Free -lt 100GB) { throw '100 GiB free disk required' }
@{experiment_id=$capacityExperiment;lab_id=$capacityLab;network=$capacityNetwork;db=$capacityDb;source_sha=$capacitySha;
  dependency_image=$capacityImage;output=$capacityOutput;authorized='2026-10-30 explicit owner approval';status='starting'} |
  ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $PSScriptRoot 'capacity-run.json')
docker network create --internal --label codex.task=r01-synthetic $capacityNetwork
if ($LASTEXITCODE -ne 0) { throw 'Fresh network creation failed' }
docker run -d --name $capacityDb --label codex.task=r01-synthetic --label codex.audit=post-merge-remediation `
  --network $capacityNetwork --network-alias r01-db --cpus 8 --memory 8g --shm-size 1g `
  -e POSTGRES_USER=r01 -e POSTGRES_PASSWORD=r01-synthetic-only -e POSTGRES_DB=r01_synthetic `
  'mirror.gcr.io/postgis/postgis:16-3.4@sha256:44126d872ac91993766c341e369c539e8196614321765d36a6f1bab0419a5fa5' `
  postgres -c shared_buffers=1GB -c work_mem=4MB -c max_connections=260 -c track_io_timing=on -c shared_preload_libraries=pg_stat_statements
if ($LASTEXITCODE -ne 0) { throw 'Fresh DB creation failed' }
for ($capacityAttempt=0;$capacityAttempt -lt 90;$capacityAttempt++) {
  docker exec $capacityDb psql -h 127.0.0.1 -X -U r01 -d r01_synthetic -tAc 'SELECT 1' 2>$null
  if ($LASTEXITCODE -eq 0) { break }
  Start-Sleep -Seconds 1
}
if ($LASTEXITCODE -ne 0) { throw 'Disposable DB did not become ready' }
$capacityPs = (Get-Process -Id $PID).Path
try {
  & ./scripts/run-ai-map-benchmark.ps1 -Phase initialize -LabId $capacityLab -DependencyImage $capacityImage -ExperimentId $capacityExperiment
  foreach ($capacityTotal in @(100000,500000,1000000)) {
    & ./scripts/run-ai-map-benchmark.ps1 -Phase seed -Total $capacityTotal -LabId $capacityLab -DependencyImage $capacityImage -ExperimentId $capacityExperiment
    $capacityRun = [guid]::NewGuid().ToString('N')
    $capacityStop = Join-Path $capacityOutput 'monitor.stop'
    if (Test-Path -LiteralPath $capacityStop) { Remove-Item -LiteralPath $capacityStop -Force }
    $capacityMonitorArgs = @('-NoProfile','-File', ('"' + (Join-Path $capacityRoot 'scripts/monitor-ai-map.ps1') + '"'),
      '-OutputDirectory', ('"' + $capacityOutput + '"'), '-RunId',$capacityRun,'-LabId',$capacityLab)
    $capacityMonitor = Start-Process -FilePath $capacityPs -ArgumentList $capacityMonitorArgs -WindowStyle Hidden -PassThru `
      -RedirectStandardOutput (Join-Path $PSScriptRoot "monitor-$capacityTotal.log") `
      -RedirectStandardError (Join-Path $PSScriptRoot "monitor-$capacityTotal.err")
    function Wait-CapacitySample([DateTimeOffset]$after) {
      for ($capacitySampleAttempt=0;$capacitySampleAttempt -lt 40;$capacitySampleAttempt++) {
        if ($capacityMonitor.HasExited) { throw 'Resource monitor exited before acceptance' }
        $capacityResourcePath = Join-Path $capacityOutput 'resources.jsonl'
        if (Test-Path -LiteralPath $capacityResourcePath) {
          $capacityRows = @(Get-Content -LiteralPath $capacityResourcePath -Tail 10 | ForEach-Object { $_ | ConvertFrom-Json })
          if (@($capacityRows | Where-Object { $_.run_id -eq $capacityRun -and $_.kind -eq 'sample' -and [DateTimeOffset]$_.at -ge $after }).Count) { return }
        }
        Start-Sleep -Seconds 1
      }
      throw 'No bracketing resource sample'
    }
    try {
      Wait-CapacitySample ([DateTime]::UtcNow.AddMinutes(-1))
      & ./scripts/run-ai-map-benchmark.ps1 -Phase measure -Total $capacityTotal -Samples 200 -LabId $capacityLab -DependencyImage $capacityImage -ExperimentId $capacityExperiment -RunId $capacityRun
      $capacityFinished = Get-Content -Raw -LiteralPath (Join-Path $capacityOutput "runner-measure-$capacityTotal-$capacityRun.json") | ConvertFrom-Json
      Wait-CapacitySample ([DateTimeOffset]$capacityFinished.ended_at)
    } finally {
      Set-Content -LiteralPath $capacityStop -Value 'stop' -Encoding utf8
      if (-not $capacityMonitor.WaitForExit(30000)) { throw 'Resource monitor did not stop' }
      if ($capacityMonitor.ExitCode -ne 0) { throw 'Resource monitor failed' }
    }
  }
  docker run --rm --network none --read-only --tmpfs /tmp --memory 2g --cpus 2 `
    -v "${capacityRoot}:/code:ro" -v "${capacityOutput}:/results" --entrypoint python $capacityImage /code/scripts/summarize-ai-map-capacity.py /results
  $capacitySummaryExit=$LASTEXITCODE
  docker run --rm --network none --read-only --tmpfs /tmp --memory 2g --cpus 2 `
    -v "${capacityRoot}:/code:ro" -v "${capacityOutput}:/results:ro" --entrypoint python $capacityImage /code/scripts/check-ai-map-capacity.py /results --expected-sha $capacitySha
  $capacityAcceptanceExit=$LASTEXITCODE
  @{summary_exit=$capacitySummaryExit;acceptance_exit=$capacityAcceptanceExit;source_sha=$capacitySha;output=$capacityOutput;status='measured'} |
    ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $PSScriptRoot 'capacity-result.json')
} finally {
  docker stop $capacityDb
}
