$ErrorActionPreference = 'Stop'
$capacityRoot = (Resolve-Path (Join-Path $PSScriptRoot '../..')).Path
Set-Location -LiteralPath $capacityRoot
$capacityState = Get-Content -Raw (Join-Path $PSScriptRoot 'capacity-run.json') | ConvertFrom-Json
$capacityExperiment = $capacityState.experiment_id
$capacityLab = $capacityState.lab_id
$capacityNetwork = $capacityState.network
$capacityDb = $capacityState.db
$capacityImage = $capacityState.dependency_image
$capacityOutput = $capacityState.output
$capacitySha = $capacityState.source_sha
if ((git rev-parse HEAD) -ne $capacitySha -or (git status --porcelain --untracked-files=all)) { throw 'Exact immutable experiment source required' }
docker start $capacityDb
if ($LASTEXITCODE -ne 0) { throw 'Cannot start owned experiment DB' }
for ($capacityAttempt=0;$capacityAttempt -lt 90;$capacityAttempt++) {
    docker exec $capacityDb psql -h 127.0.0.1 -X -U r01 -d r01_synthetic -tAc 'SELECT 1' 2>$null
    if ($LASTEXITCODE -eq 0) { break }
    Start-Sleep -Seconds 1
}
if ($LASTEXITCODE -ne 0) { throw 'DB did not become ready' }

$capacityPs = (Get-Process -Id $PID).Path
try {
  foreach ($capacityTotal in @(500000,1000000)) {
    & ./scripts/run-ai-map-benchmark.ps1 -Phase seed -Total $capacityTotal -LabId $capacityLab -DependencyImage $capacityImage -ExperimentId $capacityExperiment
    $capacityRun = [guid]::NewGuid().ToString('N')
    $capacityStop = Join-Path $capacityOutput 'monitor.stop'
    if (Test-Path -LiteralPath $capacityStop) { Remove-Item -LiteralPath $capacityStop -Force }
    $capacityMonitorArgs = @('-NoProfile','-File', ('"' + (Join-Path $capacityRoot 'scripts/monitor-ai-map.ps1') + '"'),
      '-OutputDirectory', ('"' + $capacityOutput + '"'), '-RunId',$capacityRun,'-LabId',$capacityLab)
    $capacityMonitor = Start-Process -FilePath $capacityPs -ArgumentList $capacityMonitorArgs -WindowStyle Hidden -PassThru `
      -RedirectStandardOutput (Join-Path $PSScriptRoot "monitor-$capacityTotal.log") `
      -RedirectStandardError (Join-Path $PSScriptRoot "monitor-$capacityTotal.err")
    function Wait-CapacitySample([DateTimeOffset]$after) {
      for ($capacitySampleAttempt=0;$capacitySampleAttempt -lt 40;$capacitySampleAttempt++) {
        if ($capacityMonitor.HasExited) { throw 'Resource monitor exited before acceptance' }
        $capacityResourcePath = Join-Path $capacityOutput 'resources.jsonl'
        if (Test-Path -LiteralPath $capacityResourcePath) {
          $capacityRows = @(Get-Content -LiteralPath $capacityResourcePath -Tail 10 | ForEach-Object { $_ | ConvertFrom-Json })
          if (@($capacityRows | Where-Object { $_.run_id -eq $capacityRun -and $_.kind -eq 'sample' -and [DateTimeOffset]$_.at -ge $after }).Count) { return }
        }
        Start-Sleep -Seconds 1
      }
      throw 'No bracketing resource sample'
    }
    try {
      Wait-CapacitySample ([DateTime]::UtcNow.AddMinutes(-1))
      & ./scripts/run-ai-map-benchmark.ps1 -Phase measure -Total $capacityTotal -Samples 200 -LabId $capacityLab -DependencyImage $capacityImage -ExperimentId $capacityExperiment -RunId $capacityRun
      $capacityFinished = Get-Content -Raw -LiteralPath (Join-Path $capacityOutput "runner-measure-$capacityTotal-$capacityRun.json") | ConvertFrom-Json
      Wait-CapacitySample ([DateTimeOffset]$capacityFinished.ended_at)
    } finally {
      Set-Content -LiteralPath $capacityStop -Value 'stop' -Encoding utf8
      if (-not $capacityMonitor.WaitForExit(30000)) { throw 'Resource monitor did not stop' }
      if ($capacityMonitor.ExitCode -ne 0) { throw 'Resource monitor failed' }
    }
  }
  docker run --rm --network none --read-only --tmpfs /tmp --memory 2g --cpus 2 `
    -v "${capacityRoot}:/code:ro" -v "${capacityOutput}:/results" --entrypoint python $capacityImage /code/scripts/summarize-ai-map-capacity.py /results
  $capacitySummaryExit=$LASTEXITCODE
  docker run --rm --network none --read-only --tmpfs /tmp --memory 2g --cpus 2 `
    -v "${capacityRoot}:/code:ro" -v "${capacityOutput}:/results:ro" --entrypoint python $capacityImage /code/scripts/check-ai-map-capacity.py /results --expected-sha $capacitySha
  $capacityAcceptanceExit=$LASTEXITCODE
  @{summary_exit=$capacitySummaryExit;acceptance_exit=$capacityAcceptanceExit;source_sha=$capacitySha;output=$capacityOutput;status='measured'} |
    ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $PSScriptRoot 'capacity-result.json')
} finally {
  docker stop $capacityDb
}